#include <stdio.h>

int main(void) {
  printf("Hello C語言\n");
	printf("這是c語的第一節課\n");
	printf("這是一個線上真人課程\n");
  return 0;
}
