#include <stdio.h>

int main(void) {
	printf("這個值%d是整數值\n",10);
	printf("這個值%.1lf是double\n",10.0);
	printf("這個值%s是字串\n","10.0");
  return 0;
}
