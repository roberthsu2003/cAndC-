#include <stdio.h>

int main(void) {
  printf("2數相加為%d\n",5 + 10);
	printf("%d + %d = %d\n", 5, 10, 5 + 10);
	printf("%.1lf + %.1lf = %.1lf\n", 5.0, 10.0, 5.0 + 10.0);
	printf("%d + %.1lf = %.1lf\n", 5, 10.0, 5 + 10.0);
  return 0;
}
