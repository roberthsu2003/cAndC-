#include <stdio.h>

int main(void) {
  printf("5/3=%d\n", 5 / 3); //整數/整數傳出整數
	printf("5/3=%.2lf", 5 / 3.0); // int/double傳出double
  return 0;
}
