#include <stdio.h>

int main(void) {
  int n;
	n = 10;

	double m = 10.0;

	double x = n + m;

	printf("n=%d\n",n);
	printf("m=%.2lf\n",m);
	printf("2數相加為%.2lf\n",x);
	
  return 0;
}
