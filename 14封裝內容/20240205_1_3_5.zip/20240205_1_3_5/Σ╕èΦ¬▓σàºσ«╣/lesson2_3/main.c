#include <stdio.h>

int main(void) {
	//=的自動轉換型別
  int x = 5.5;
	printf("x內的值是:%d\n",x);

	double n = 10;
	printf("n的值是%.2lf\n",n);
	
  return 0;
}
