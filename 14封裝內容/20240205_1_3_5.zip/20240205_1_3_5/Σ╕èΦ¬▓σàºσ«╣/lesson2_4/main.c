#include <stdio.h>

int main(void) {
	double PI = 3.1415926;
	int radius = 9;
	double area = PI * radius * radius;
	printf("圓面積是%.2lf", area);
  return 0;
}
