#include <stdio.h>

int main(void) {
  char ch = 'a';
  printf("ch=%c\n", ch);
	printf("ch=%d\n",ch);
  return 0;
}
