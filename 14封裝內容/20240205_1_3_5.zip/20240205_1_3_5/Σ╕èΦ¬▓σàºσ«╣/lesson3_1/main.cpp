#include <iostream>
using namespace std;

int main() {
	string name;
	cout << "請輸入姓名:";
	cin >> name;
	cout << "您輸入的姓名是:" << name << endl;
	printf("身高是:%d\n",172);
	printf("BMI:%lf\n",25.17895);
}
