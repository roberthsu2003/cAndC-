#include <iostream>
using namespace std;

int main() {
	int n = 0;
	//單獨使用遞增
	n++;
	cout << "n=" << n << endl;
	++n;
	cout << "n=" << n << endl;
	n--;
	cout << "n=" << n << endl;
	--n;
	cout << "n=" << n << endl;
	
}
