#include <iostream>
using namespace std;

int main() {
	//while迴圈,明確知道執行的次數
	int i = 0;
	while(i<10){
		cout << i << endl;
		i++;
	}
}
