#include <iostream>

using namespace std;

int main() {
  cout << "Hello C++!" << endl;
	cout << "Hello 徐國堂!" << endl;
	cout << "Hello! 這是c++的第一堂課" << endl;
}
