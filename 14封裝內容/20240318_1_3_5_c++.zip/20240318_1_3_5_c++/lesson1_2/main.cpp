#include <iostream>
using namespace std;

int main() {
	//配置記憶體給陣列變數n
  int n[3];
  //儲存元素值
  n[0] = 10;
  n[1] = 20;
  n[2] = 30;

  //取出元素值
  cout << "第1個元素:" << n[0] << endl;
  cout << "第2個元素:" << n[1] << endl;
  cout << "第3個元素:" << n[2] << endl;
}
