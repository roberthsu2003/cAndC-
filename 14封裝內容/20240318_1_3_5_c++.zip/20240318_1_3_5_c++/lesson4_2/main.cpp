#include <iostream>
using namespace std;

int main() {
  const char *name = "robert";
  cout << name << endl;
  name = "徐國堂";
  cout << name << endl;
}
