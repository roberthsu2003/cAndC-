#include <iostream>
#include "people.h"
using namespace std;

int main() {
	People p1;
	p1.name = "正常人阿民";
	p1.height = 171;
	p1.weight = 66;
	p1.profile();
	
	People p2("過瘦阿賢", 180, 50);
	p2.profile();
	
	People *p4 = new People("一個大胖子", 170, 170);
	p4->profile();
}
