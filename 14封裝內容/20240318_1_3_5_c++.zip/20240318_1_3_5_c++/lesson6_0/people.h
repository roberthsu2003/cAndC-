#include <iostream>
#include <math.h>
using namespace std;

/*
依據lesson5_2,請多輸出一行
您必需最少減重xx公斤,才可以至標準,或加重多少,才可以至標準

算式：
// 正常值的BMI * (身高2)公尺   可得此身高正常值的體重
*/

class People {
public:
  string name;
  double weight;
  double height;
  People() {}
  People(string name, double height, double weight) {
    this->name = name;
    this->height = height;
    this->weight = weight;
  }
  void profile() {
    cout << "姓名：" << name << endl;
    cout << "身高：" << height << endl;
    cout << "體重：" << weight << endl;
    cout << "BMI：" << bmi() << endl;
    cout << "狀況：" << status(bmi()) << endl;
    cout << remide(bmi(), weight, height) << endl;
    cout << "＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝" << endl;
  }

  //實體方法(method)
  
  string remide(double bmi, double weight, double height) {
    if (bmi >= 18.5 && bmi < 24) {
      return "很棒，繼續保持！";
    } else if (bmi < 18.5) {
      // 體重過輕
      double normal_weight = 18.5 * pow(height / 100.0, 2);
      double add_weight = normal_weight - weight;
      return "您必需增加多少" + to_string(add_weight) + "公斤";
    } else {
      //體重過重
      double normal_weight = 24 * pow(height / 100.0, 2);
      double decrease_weight = weight - normal_weight;
      return "您必需減少" + to_string(decrease_weight) + "公斤";
    }
	}
   

    double bmi() { return weight / pow(height / 100, 2); }

    string status(double bmi) {
      if (bmi < 18.5) {
        return "體重過輕";
      } else if (bmi < 24) {
        return "正常範圍";
      } else if (bmi < 27) {
        return "過重";
      } else if (bmi < 30) {
        return "輕度肥胖";
      } else if (bmi < 35) {
        return "中度肥胖";
      } else {
        return "重度肥胖";
      }
    }
  };
