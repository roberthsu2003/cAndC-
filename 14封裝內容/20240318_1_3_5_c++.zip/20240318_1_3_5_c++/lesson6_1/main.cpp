#include <iostream>
using namespace std;

class Student {
public:
  string name;
  int chinese;
  int english;
  int math;

  Student(string name, int chinese, int english, int math) {
    this->name = name;
    this->chinese = chinese;
    this->english = english;
    this->math = math;
  }
};

// call by value
void change_name(Student s) {}

// call by address
void change_name1(Student *s) {}


//c++ 才有的,call by reference
void change_name2(Student &s){
	s.name = "XXX";
}

int main() {
  Student stu1("徐國堂", 78, 92, 65); //實體變數
  //change_name(stu1);
  //change_name1(&stu1);
	change_name2(stu1);
	cout << "stu1的姓名是:" << stu1.name << endl;
}
