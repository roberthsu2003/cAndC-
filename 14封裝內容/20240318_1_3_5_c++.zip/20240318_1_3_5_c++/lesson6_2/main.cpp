#include <iostream>
#include <vector>
using namespace std;

class Student {
public:
  string name;
  int chinese;
  int english;
  int math;

  Student(string name, int chinese, int english, int math) {
    this->name = name;
    this->chinese = chinese;
    this->english = english;
    this->math = math;
  }
};

int main() {
  vector<int> vec_a;
  vector<int> vec_b(10);
  vector<int> vec_c(10, 8);
  vector<int> vec_d{10, 20, 30, 40, 50};
  cout << vec_c[9] << endl;

  for (int element : vec_d) {
    cout << element << endl;
  }
}
