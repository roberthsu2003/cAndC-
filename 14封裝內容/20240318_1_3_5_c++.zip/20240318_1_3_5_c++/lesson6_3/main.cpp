#include <iostream>
#include <vector>
using namespace std;

class Student {
public:
  string name;
  int chinese;
  int english;
  int math;

  Student(string name, int chinese, int english, int math) {
    this->name = name;
    this->chinese = chinese;
    this->english = english;
    this->math = math;
  }
};

//function
void print_students(vector<Student> &stus){
	for (Student s : stus) {
		cout << s.name << endl;
		cout << s.chinese << endl;
		cout << s.english << endl;
		cout << s.math << endl;
		cout << "===========" << endl;
	}
}

int main() {
  vector<Student> students;
  students.push_back(Student("stu1", 98, 65, 78));
  students.push_back(Student("stu2", 100, 65, 78));
  students.push_back(Student("stu3", 72, 100, 65));
	//students.pop_back();

	print_students(students);
}
