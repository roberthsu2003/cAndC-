#include <iostream>
#include <time.h>
#include <vector>
using namespace std;

class Student {
public:
  string name;
  int chinese;
  int english;
  int math;

  Student() {}

  Student(string name, int chinese, int english, int math) {
    this->name = name;
    this->chinese = chinese;
    this->english = english;
    this->math = math;
  }

  int total() { return chinese + english + math; }

  double average() { return total() / 3.0; }
};

// function
void add_student(int nums, vector<Student> &stus) {
  //增加學生
  for (int i = 0; i < nums; i++) {
    Student stu;
    stu.name = "stu" + to_string(i + 1);
    stu.chinese = random() % (100 - 50 + 1) + 50;
    stu.english = random() % (100 - 50 + 1) + 50;
    stu.math = random() % (100 - 50 + 1) + 50;
    stus.push_back(stu);
  }
}

// function
void print_students(vector<Student> &stus) {
  for (Student s : stus) {
    cout << "學生姓名:" << s.name << endl;
    cout << "國文:" << s.chinese << endl;
    cout << "英文:" << s.english << endl;
    cout << "數學:" << s.math << endl;
    cout << "總分:" << s.total() << endl;
    // cout << "平均:" << s.average() << endl;
    printf("平均:%.2f\n", s.average());
    cout << "===========" << endl;
  }
}

int main() {
  srandom(time(NULL));
  vector<Student> students;
	add_student(10,students);
  print_students(students);
}
