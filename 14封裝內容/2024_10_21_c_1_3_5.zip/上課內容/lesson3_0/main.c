#include <stdio.h>

int main(void) {
  double kg, lb;
  const double KG_TO_LB = 2.20426;
  printf("公斤轉換為磅\n");
  printf("請輸入公斤數:");
  scanf("%lf", &kg);
  printf("磅數為 : %.4lf 磅\n", kg * KG_TO_LB);

  printf("=====================\n");

  printf("磅轉換為公斤\n");
  printf("請輸入磅數:");
  scanf("%lf",&lb);
  printf("公斤為 : %.4lf 公斤\n",lb/KG_TO_LB);
  return 0;
}
