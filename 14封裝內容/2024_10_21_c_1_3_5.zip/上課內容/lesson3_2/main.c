#include <stdio.h>

int main(void) {
  int n = 20;
  n *= 10;
  printf("n=%d", n);
  return 0;
}
