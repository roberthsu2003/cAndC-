#include <stdio.h>
//請使用者輸入一個任意數，程式會顯示此數的平方值及立方值
int main(void) {
  double num, result;
  printf("請輸入任意數:");
  scanf("%lf", &num);
  result = num;
  result *= num;
  printf("%.2lf的平方是:%.2lf\n", num, result);
  result *= num;
  printf("%.2lf的立方是:%.2lf\n", num, result);
  return 0;
}
