#include <math.h>
#include <stdio.h>

int main(void) {
  double opposite_side, hypotenuse;
  double radian, degree;
  printf("請輸入對邊:");
  scanf("%lf", &opposite_side);
  printf("請輸入斜邊:");
  scanf("%lf", &hypotenuse);
  radian = asin(opposite_side / hypotenuse);
  degree = radian * 180 / M_PI;

  printf("對邊是:%.2lf\n", opposite_side);
  printf("斜邊是:%.2lf\n", hypotenuse);
  printf("弧度是:%.2lf\n", radian);
  printf("角度是:%.2lf\n", degree);

  return 0;
}
