#include <stdio.h>

int main(void) {
  char charA = 'b';
  printf("charA:%c\n", charA);
  printf("charA:%d\n", charA);
  return 0;
}
