#include <stdio.h>

int main(void) {
  int n = 1;
  n++;
  printf("n=%d\n", n);

  n = 1;
  ++n;
  printf("n=%d\n", n);

  n = 1;
  int y = ++n;
  printf("n=%d,y=%d\n", n, y);

  n = 1;
  int x = n++;
  printf("n=%d, x=%d\n", n, x);
  return 0;
}
