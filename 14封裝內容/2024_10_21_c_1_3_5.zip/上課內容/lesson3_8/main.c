#include <stdio.h>

int main(void) {
  printf("5==5轉成整數為:%d\n", 5 == 5);
  printf("5!=5轉成整數為:%d\n", 5 != 5);

  int n = 3 > 5 ? 3 : 5;
  printf("n=%d\n", n);

  //讓使用者輸入三個任意數，程式會顯示三數中的最大數。
  double in1, in2, in3, max;
  printf("請輸入第一個數:");
  scanf("%lf", &in1);
  printf("請輸入第二個數:");
  scanf("%lf", &in2);
  max = in1 > in2 ? in1 : in2;
  printf("請輸入第三個數:");
  scanf("%lf", &in3);
  max = max > in3 ? max : in3;

  printf("3數最大的為:%.2lf\n", max);
  return 0;
}
