#include <stdio.h>
#include <math.h>
//請計算直角三角形的斜邊

int main(void) {
  double opposite_side, hypotenuse, adjacent_side;
  double radian, degree;
  printf("請輸入直角三角形的對邊:");
  scanf("%lf", &opposite_side);
  printf("請輸入直角三角形的鄰邊:");
  scanf("%lf", &adjacent_side);
  printf("============\n");
  hypotenuse = sqrt(pow(opposite_side,2) + pow(adjacent_side,2));
  radian = atan(opposite_side/adjacent_side);
  degree = radian * 180 / M_PI;
  printf("斜邊為:%.2lf\n",hypotenuse);
  printf("角度為:%.2lf\n",degree);
  return 0;
}
