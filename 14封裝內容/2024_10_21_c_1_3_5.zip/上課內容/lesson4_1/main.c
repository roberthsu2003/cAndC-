#include <stdio.h>
//學生符合加分條件就加5%分,如果超過300分,就以300為主。
int main(void) {
  int score;
  int add;
  printf("請輸入學生的分數:");
  scanf("%d", &score);
  printf("學生符合加分條件嗎? yes請輸入1,no請輸入0:");
  scanf("%d", &add);
  //巢狀判斷
  if (add) {
    score *= 1.05;
    if (score > 300) {
      score = 300;
    }
  }
  printf("學生分數是%d\n", score);
  return 0;
}
