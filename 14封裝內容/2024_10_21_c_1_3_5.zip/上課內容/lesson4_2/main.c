#include <stdio.h>
//請使用者輸入成績，若成績大於等於60分，則顯示及格，否則顯示不及格。
int main(void) {
  int score;
  printf("請輸入學生的分數(0~100):");
  scanf("%d", &score);

  if (score >= 60) {
    printf("及格\n");
    if (score >= 80) {
      printf("甲\n");
    } else {
      printf("乙\n");
    }
  } else {
    printf("不及格\n");
    if (score >= 50) {
      printf("丙\n");
    } else {
      printf("丁\n");
    }
  }
  return 0;
}
