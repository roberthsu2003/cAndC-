#include <stdio.h>


int main(void) {
  int score;
  printf("請輸入學生的分數(0~100):");
  scanf("%d", &score);
  //多項選擇
  if(score>=90){
    printf("優\n");
  }else if (score>=80){
    printf("甲\n");
  }else if(score>=70){      
    printf("乙\n");
  }else if(score>=60){
    printf("丙\n");
  }else{
    printf("丁\n");
  }   
  return 0;
}
