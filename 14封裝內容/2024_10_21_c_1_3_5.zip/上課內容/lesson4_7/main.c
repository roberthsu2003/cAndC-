#include <stdio.h>

int main(void) {
  char op;
  int num1 = 20;
  int num2 = 4;
  printf("請輸入要執行的運算(+-*/):");
  scanf("%c", &op);
  switch (op) {
  case '+':
    printf("num1+num2=%d\n", num1 + num2);
    break;

  case '-':
    printf("num1-num2=%d\n", num1 - num2);
    break;

  case '*':
    printf("num1*num2=%d\n", num1 * num2);
    break;

  case '/':
    printf("num1/num2=%d\n", num1 / num2);
    break;

  default:
    printf("不正確的格式\n");
  }
  
  return 0;
}
