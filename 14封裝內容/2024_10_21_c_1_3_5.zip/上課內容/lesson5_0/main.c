#include <math.h>
#include <stdio.h>

int main(void) {
  double cm, kg, m, BMI;
  printf("請輸入身高(cm):");
  scanf("%lf", &cm);
  printf("請輸入體重(kg):");
  scanf("%lf", &kg);
  m = cm / 100;
  BMI = kg / pow(m, 2);
  printf("您的BMI: %.2lf\n", BMI);
  printf("您的體重:");
  if (BMI >= 35) {
    printf("重度肥胖");
  } else if (BMI >= 30) {
    printf("中度肥胖");
  } else if (BMI >= 27) {
    printf("輕度肥胖");
  } else if (BMI >= 24) {
    printf("過重");
  } else if (BMI >= 18.5) {
    printf("正常");
  } else {
    printf("過輕");
  }
  return 0;
}
