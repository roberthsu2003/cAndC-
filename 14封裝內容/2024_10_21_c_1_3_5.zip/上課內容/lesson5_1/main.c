#include <stdio.h>

int main(void) {
  int sum = 0;
  sum += 1;
  sum += 2;
  sum += 3;
  sum += 4;
  sum += 5;
  sum += 6;
  sum += 7;
  sum += 8;
  sum += 9;
  sum += 10;
  printf("%d\n", sum);

  int sum1 = 0;
  for(int i=1; i<=100; i++){
    sum1 += i;
  }
  printf("%d\n", sum1);
  return 0;
}
