#include <stdio.h>
//計算固定中的支出，媽媽每天會將家裡的花費記錄下來，並且計算本週的花費總和
int main(void) {
  int sum = 0;
  for (int day = 1; day < 8; day += 1) {
    int n;
    if(day != 7){
      printf("請輸入星期%d的支出:", day);
    }else{
      printf("請輸入星期日的支出");
    }
    scanf("%d", &n);
    sum += n;
  }
  printf("本星期的支出為:%d元\n", sum);
  return 0;
}
