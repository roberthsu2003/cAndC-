#include <stdio.h>
//while明確知道執行的次數
int main(void) {
  int i = 1;
  int sum = 0;
  while (i <= 10) {
    sum += i;
    i += 1;
  }

  printf("sum=%d", sum);
  return 0;
}
