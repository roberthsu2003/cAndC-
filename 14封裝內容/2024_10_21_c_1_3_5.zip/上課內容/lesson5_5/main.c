#include <stdio.h>
//小明想要存錢買一輛機車,機車每輛30000元，他將每月存的錢輸入，當存款足夠買機車時，就顯示提示訊息告知。
int main(void) {
  int deposit = 0;
  int month = 0;
  int input_value;
  while (deposit < 30000) {
    month += 1;
    printf("請輸入第%d月份的存款:", month);
    scanf("%d", &input_value);
    deposit += input_value;
  }
  printf("存了%d月,共存了%d元", month, deposit);
  return 0;
}
