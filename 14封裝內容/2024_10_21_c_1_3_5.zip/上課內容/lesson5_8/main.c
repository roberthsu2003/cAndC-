#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  //printf("%ld",time(NULL));
  srand(time(NULL));
  int min = 100;
  int max = 103;
  printf("%d", rand() % (max-min+1) + min);
  return 0;
}
