#include <stdio.h>

int main(void) {

  int num, s;
  printf("請輸入一個數值 : ");
  scanf("%d", &num);
  printf("因數為");
  for (int s = 1; s <= num; s++) {
    if (num % s == 0) {
      printf("%d ", s);
    }
  }
  return 0;
}
