#include <stdio.h>

int main(void) {
  int scores[3];
  scores[0] = 70;
  scores[1] = 80;
  scores[2] = 90;
  printf("索引0的值是:%d\n", scores[0]);
  printf("索引1的值是:%d\n", scores[1]);
  printf("索引2的值是:%d\n", scores[2]);
  printf("scores陣列的大小是:%d\n", (int)sizeof(scores));
  printf("scores[0]元素的大小是:%lu\n", sizeof(scores[0]));
  printf("score陣的的元素數量是:%d", (int)(sizeof(scores) / sizeof(scores[0])));
  return 0;
}
