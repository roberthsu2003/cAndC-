#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  srand(time(NULL));
  int max = 100;
  int min = 50;
  int scores[3];
  int ele_count = sizeof(scores) / sizeof(scores[0]);
  int sum;
  scores[0] = rand() % (max - min + 1) + min;
  scores[1] = rand() % (max - min + 1) + min;
  scores[2] = rand() % (max - min + 1) + min;
  sum = scores[0] + scores[1] + scores[2];
  printf("國文的分數是:%d\n", scores[0]);
  printf("英文的分數是:%d\n", scores[1]);
  printf("數學的分數是:%d\n", scores[2]);
  printf("學生總分為:%d\n", sum);
  printf("學生的平均為:%.2lf\n", sum / (double)ele_count);
  return 0;
}
