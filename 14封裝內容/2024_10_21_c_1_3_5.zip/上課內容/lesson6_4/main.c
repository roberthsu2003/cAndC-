#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  srand(time(NULL));
  int max = 100;
  int min = 50;
  int scores[3];
  int ele_count = sizeof(scores) / sizeof(scores[0]);
  int sum = 0;

  for (int index = 0; index < ele_count; index++) {
    scores[index] = rand() % (max - min + 1) + min;
    sum += scores[index];
    printf("第%d科的分數%d\n", index + 1, scores[index]);
  }
  printf("學生總分為:%d\n", sum);
  printf("學生的平均為:%.2lf\n", sum / (double)ele_count);

  return 0;
}
