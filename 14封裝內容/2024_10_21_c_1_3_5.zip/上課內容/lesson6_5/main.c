#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  srand(time(NULL));
  for (int student = 1; student <= 10; student++) {
    int max = 100;
    int min = 50;
    int scores[5];
    int ele_count = sizeof(scores) / sizeof(scores[0]);
    int sum = 0;
    printf("第%d學生的分數:\n", student);
    for (int index = 0; index < ele_count; index++) {
      scores[index] = rand() % (max - min + 1) + min;
      sum += scores[index];
      printf("第%d科的分數%d\n", index + 1, scores[index]);
    }
    printf("學生%d總分為:%d\n", student, sum);
    printf("學生%d的平均為:%.2lf\n", student, sum / (double)ele_count);
    printf("====================\n");
  }

  return 0;
}
