#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  srand(time(NULL));

  int student_count = 2;
  int subject_count = 3;
  int max = 100;
  int min = 50;
  int students[student_count][subject_count];

  for (int i = 0; i < student_count; i++) {
    printf("第%d位學生:\n", i + 1);
    int sum = 0;
    for (int j = 0; j < subject_count; j++) {
      students[i][j] = rand() % (max - min + 1) + min;
      sum += students[i][j];
      printf("第%d科分數:%d\n", j + 1, students[i][j]);
    }
    printf("學生%d總分%d\n", i + 1, sum);
    printf("平均分數是:%.2lf\n", sum / (double)subject_count);
    printf("===============\n");
  }

  return 0;
}
