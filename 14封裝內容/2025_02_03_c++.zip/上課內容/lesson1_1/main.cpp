#include <iostream>

using namespace std;
int main() { 
  printf("Hello! World!\n"); //c的輸出
  cout << "Hello! World!\n"; //c++的輸出
}
