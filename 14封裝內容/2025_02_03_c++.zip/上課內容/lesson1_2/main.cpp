#include <iostream>

using namespace std;
int main() { 
  int english;
  cout << "請輸入您的英文分數:";
  cin >> english;
  cout << "您的英文分數是:" << english << endl;
  
}
