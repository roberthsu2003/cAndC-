#include <iostream>

using namespace std;
int main() {
  string name;
  cout << "請輸入中文姓名:";
  cin >> name;
  cout << "您的姓名是:" << name << endl;
}
