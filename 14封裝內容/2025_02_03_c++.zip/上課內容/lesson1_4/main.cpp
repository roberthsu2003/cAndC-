#include <iostream>

using namespace std;
int main() { 
  int scores[3];
  scores[0] = 86;
  scores[1] = 94;
  scores[2] = 79;
  for(int i=0; i<3; i++){
    cout << scores[i] << " ";
  }
  cout << endl;
}
