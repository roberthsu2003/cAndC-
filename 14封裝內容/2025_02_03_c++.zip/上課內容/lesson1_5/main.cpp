#include <iostream>
#include <time.h>

using namespace std;
int main() {
  // cout << time(NULL) << endl;
  srandom(time(NULL));
  int min = 50;
  int max = 1000;
  
  int nums[100];
  for(int i=0; i<100; i++){
    nums[i] = random() % (max-min+1) + min;
    //cout << nums[i] << endl;
  }

  //大於500的元素有多少個
  //陣列有搜尋的功能
  int n = 0;
  for(int i=0; i<100; i++){
    if(nums[i] >= 500){
      n += 1;
    }
  }

  cout << "大於500的元素數量是:" << n << endl;

  
}
