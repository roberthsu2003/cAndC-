#include <iostream>
#include <time.h>

using namespace std;
int main() {
  // cout << time(NULL) << endl;
  srandom(time(NULL));
  int min = 50;
  int max = 1000;

  int nums[100];
  for (int i = 0; i < 100; i++) {
    nums[i] = random() % (max - min + 1) + min;
    // cout << nums[i] << endl;
  }

  cout << "請輸入中獎號碼:(50~1000)";
  int number;
  cin >> number;
  cout << "有幾位抽到些號碼";
  int get = 0;
  for (int i = 0; i < 100; i++) {
    if (number == nums[i]) {
      get += 1;
    }
  }

  cout << "抽中的人數有:" << get << endl;
}
