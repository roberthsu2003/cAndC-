#include <iostream>

using namespace std;
int main() {
  int array[] = {45, 78, 24, 69};
  int nums = 4;
  for (int i = 0; i < nums - 1; i++) { // i是前面的索引
    cout << "前面的:" << array[i] << endl;
    for (int j = i + 1; j < nums; j++) { // j是後面的
      cout << "後面的:" << array[j] << " ";
      if (array[i] > array[j]) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }
    }
    cout << "\n=============" << endl;
  }

  for (int i = 0; i < nums; i++) {
    cout << array[i] << ",";
  }
}
