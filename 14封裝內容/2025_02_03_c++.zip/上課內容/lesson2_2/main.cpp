#include <iostream>
#include <time.h>

using namespace std;
int main() {
  srandom(time(NULL));
  int min = 1;
  int max = 1000;
  int num = 10;
  int array[num];
  cout << "排序前" << endl;
  for (int i = 0; i < num; i++) {
    array[i] = random() % (max - min + 1) + min;
    cout << array[i] << " ";
  }
  cout << "\n==========";

  //排序
  for (int i = 0; i < num - 1; i++) {   // i是前面的索引
    for (int j = i + 1; j < num; j++) { // j是後面的
      if (array[i] > array[j]) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }
    }
  }

  cout << "\n排序後" << endl;
  for (int i = 0; i < num; i++) {
    cout << array[i] << " ";
  }
  cout << "\n==========\n";

  cout << "前5個" << endl;
  for (int i = 0; i < 5; i++) {
    cout << array[i] << " ";
  }
  cout << "\n==========\n";
  cout << "後5個" << endl;
  for (int i = num - 5; i < num; i++) {
    cout << array[i] << " ";
  }
}
