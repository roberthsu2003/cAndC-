#include <iostream>
#include <time.h>
//自訂的function
using namespace std;

void playgame(){
  int guess;
  int keyin;
  int count = 0;
  int min = 1;
  int max = 99;
  srandom(time(NULL));
  guess = random() % (max - min + 1) + min;
  printf("=========猜數字遊戲===========\n\n");
  printf("%d\n", guess);
  while (1) {
    printf("猜數字範圍%d~%d:", min, max);
    cin >> keyin;
    count++;
    if (keyin >= min && keyin <= 99) {
      if (keyin == guess) {
        printf("賓果!猜對了,答案是%d\n", guess);
        printf("您猜了%d次\n\n", count);
        break;
      } else if (keyin > guess) {
        printf("再小一點\n");
        max = keyin - 1;
      } else if (keyin < guess) {
        printf("再大一點\n");
        min = keyin + 1;
      }
      printf("已經猜了%d次\n\n", count);

    } else {
      printf("請輸入提示範圍內的數字!\n");
      continue;
    }
  }
}
