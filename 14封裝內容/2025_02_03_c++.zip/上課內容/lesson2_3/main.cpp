#include "game.h"
#include <iostream>

using namespace std;

int main() {
  //呼叫function
  while(true){
    playgame();
    int playagain;
    cout << "您還要繼續嗎?(1,0)";
    cin >> playagain;
    if(playagain == 0){
      break;
    }
  }
  
  printf("應用程式結束");
}
