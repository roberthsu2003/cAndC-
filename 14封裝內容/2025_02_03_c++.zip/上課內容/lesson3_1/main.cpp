#include <iostream>
using namespace std;

void sayHello(){ //沒有傳出值和沒有參數的function(函式)
  cout << "歡迎光臨!" << endl;
}

int main() { 
   sayHello();
}
