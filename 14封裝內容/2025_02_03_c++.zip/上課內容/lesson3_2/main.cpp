#include <iostream>
using namespace std;

double temperature(int); //function的原形

int main() {
  int value;
  double result;
  cout << "請輸入攝氏溫度:";
  cin >> value;
  result = temperature(value);
  cout << "華氏溫度=" << result << endl;
}

double temperature(int value) { 
  return 1.8 * value + 32; 
}
