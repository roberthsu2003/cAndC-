#include <iostream>
using namespace std;

int fun1(int);

int main() {
  for (int i = 0; i <= 10; i++) {
    cout << i << " => " << fun1(i) << endl;
  }
}

int fun1(int x) { return x * x + 2 * x + 1; }
