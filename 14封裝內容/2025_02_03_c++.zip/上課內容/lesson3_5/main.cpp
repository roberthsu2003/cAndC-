#include <iostream>

using namespace std;
int main() {
  double m = 5;
  cout << "m變數儲存的值是" << m << endl;
  cout << "m變數所佔的記憶體大小是:" << sizeof(m) << endl;
  cout << "m變數的記憶體位址是:" << &m << endl;
  double *ptr_m = &m;
  cout << "指標變數儲存的的記憶體位址是:" << ptr_m << endl;
}
