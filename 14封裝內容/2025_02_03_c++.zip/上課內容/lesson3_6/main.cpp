#include <iostream>
using namespace std;

int main() { 
  //c++可以使用new 資料類型,建立一個記憶體空間
  int* ptr_n = new int(10); //int*建立指標變數
  cout << ptr_n << endl;
  cout << *ptr_n << endl;//使用取值運算子(*記憶體位址)

  int* ptr_m = new int(15);

  int result = *ptr_n + *ptr_m;
  cout << *ptr_n << "+" << *ptr_m << "=" << result << endl; 
}
