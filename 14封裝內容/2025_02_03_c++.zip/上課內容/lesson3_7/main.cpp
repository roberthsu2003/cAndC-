#include <iostream>
using namespace std;

void swap(int* x, int* y){
  int temp = *x;
  *x = *y;
  *y = temp;
}

int main() {
  int a = 666;
  int b = 888;
  cout << "2數原來的值是\n";
  cout << "a=" << a << " ";
  cout << "b=" << b << endl;
  //呼叫2數對調
  swap(&a, &b);

  cout << "2數對調後的值是\n";
  cout << "a=" << a << " ";
  cout << "b=" << b << endl;
}
