#include <iostream>
using namespace std;

int sum(int x, int y){
  return x + y;
}

int main() {
  int a = 666;
  int b = 888;
  int total;
  total = sum(a,b);
  cout << total << endl;
  
}
