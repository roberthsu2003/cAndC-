#include <iostream>
using namespace std;

int main() { 
  int n[3] = {10, 20, 30};
  cout << "n[0]值:" << n[0] << endl;
  cout << "n[1]值:" << n[1] << endl;
  cout << "n[2]值:" << n[2] << endl;
  cout << "n儲存的值:" << n << endl;
  cout << "n[0]記憶體位址:" << &n[0] << endl;
  cout << "n[1]記憶體位址:" << &n[1] << endl;
  cout << "n[2]記憶體位址:" << &n[2] << endl;
  cout << "n[0]記憶體位址:" << n+0 << endl;
  cout << "n[1]記憶體位址:" << n+1 << endl;
  cout << "n[2]記憶體位址:" << n+2 << endl;

  cout << "n[0]值:" << *(n+0) << endl;
  cout << "n[1]值:" << *(n+1) << endl;
  cout << "n[2]值:" << *(n+2) << endl;
}
