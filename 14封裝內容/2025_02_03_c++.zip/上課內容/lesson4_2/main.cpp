#include <iostream>
using namespace std;

void multiply10(int *array,int nums) {
  //cout << *(array+0) << endl;
  for(int i=0; i< nums; i++){
    array[i] *= 10;
  }
}

int main() {
  int n[3] = {10, 20, 30};
  int nums = sizeof(n) / sizeof(n[0]);
  multiply10(n, nums);

  for(int i=0; i<nums; i++){
    cout << n[i] << endl;
  }
  
  //將陣列的內容,各*10
}
