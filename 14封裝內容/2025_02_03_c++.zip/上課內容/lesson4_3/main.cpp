#include <iostream>
using namespace std;

typedef struct student{
  string name;
  int chinese;
  int math;
  int english;
}Student;

int main() { 
  Student one;
  one.name = "robert";
  one.chinese = 98;
  one.english = 76;
  one.math = 78;

  Student two = {"jenny", 92, 79, 83};
  Student three = {"alice", 95, 65, 83};

  cout << two.name << endl;

  
}
