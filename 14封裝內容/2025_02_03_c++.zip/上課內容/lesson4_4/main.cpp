#include <iostream>
#include <time.h>

using namespace std;

typedef struct student {
  string name;
  int chinese;
  int math;
  int english;
} Student;

void calculat(Student *students, int nums) {
  for(int i=0; i<nums; i++){
    cout << students[i].name << endl;
    int total;
    double average;
    total = students[i].chinese + students[i].english + students[i].math;
    average = total / 3.0;
    cout << "總分:" << total << " 平均:" << average << endl;
    cout << "===============\n" << endl;
  }
}

int main() {
  srandom(time(NULL));
  int min = 50;
  int max = 100;
  Student students[10];
  int nums = sizeof(students) / sizeof(students[0]);
  // cout << sizeof(students[0]);
  for (int i = 0; i < nums; i++) {
    students[i].name = "student" + to_string(i + 1);
    students[i].chinese = random() % (max - min + 1) + min;
    students[i].english = random() % (max - min + 1) + min;
    students[i].math = random() % (max - min + 1) + min;
  }
  calculat(students,nums);
}
