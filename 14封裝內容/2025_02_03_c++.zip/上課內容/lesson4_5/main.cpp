#include <iostream>
using namespace std;
/*
const int NORTH = 0;
const int SOUTH = 1;
const int EAST = 2;
const int WEST = 3;
*/
typedef enum direction { NORTH, SOUTH, EAST, WEST } Direction;

int main() {
  Direction destination = NORTH;

  switch (destination) {
  case NORTH:
    cout << "向北" << endl;
    break;
  case SOUTH:
    cout << "向南" << endl;
    break;
  case EAST:
    cout << "向東" << endl;
    break;
  case WEST:
    cout << "向西" << endl;
    break;
  }
}
