#include <iostream>
#define RATE(x) (x) * 32.78

using namespace std;

int main() {
  int us;
  double nt;
  cout << "請輸入您有多少美金:";
  cin >> us;
  nt = RATE(us);
  cout << "您可以換" << nt << "台幣" << endl;
}
