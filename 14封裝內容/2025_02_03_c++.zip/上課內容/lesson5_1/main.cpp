#include <fstream>
#include <iostream>

using namespace std;

int main() {
  fstream file;
  char buffer[800];
  file.open("readme.txt", ios::in);
  if (file) {
    cout << "有檔案存在" << endl;
    file.read(buffer, sizeof(buffer));
    cout << buffer << endl;
  } else {
    cout << "檔案不存在";
  }
  file.close();
}
