#include <fstream>
#include <iostream>

using namespace std;

int main() {
  fstream file;
  char buffer[200];
  file.open("readme.txt", ios::in);
  if (file) {
    cout << "有檔案存在" << endl;
    while(!file.eof()){
      file.getline(buffer, sizeof(buffer));
      cout << buffer << endl;
    }
    
  } else {
    cout << "檔案不存在";
  }
  file.close();
}
