#include <iostream>
#include <vector>

using namespace std;

int main() { 
  vector<int> vec_a;
  vector<int> vec_b(10);
  vector<int> vec_c(10, 8);
  //cout << vec_b[9] << endl;
  //cout << vec_c[9] << endl;
  for(int i=0; i<10; i++){
    cout << vec_c[i] << endl;
  }

  for(int item:vec_b){
    cout << item << endl;
  }

  
}
