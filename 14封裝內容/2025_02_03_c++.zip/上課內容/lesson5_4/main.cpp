#include <iostream>

using namespace std;
void swap(int& n, int& m){ //call by reference
  int temp = n;
  n = m;
  m = temp;
}

int main() { 
  int a = 666;
  int b = 888;
  swap(a, b);
  cout << "a=" << a << endl;
  cout << "b=" << b << endl;
}
