#include <iostream>
#include <vector>

using namespace std;
int main() { 
  vector<double> vec(3);
  
  cout << "請輸入3個數字:";
  for(double& item :vec){
    cin >> item;
  }
  

  for(double item:vec){
    cout << item << endl;
  }
}
