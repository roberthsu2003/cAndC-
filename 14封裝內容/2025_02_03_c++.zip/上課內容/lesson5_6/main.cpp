#include <iostream>
#include <vector>

using namespace std;
int main() { 
  vector<double> vec;

  while(true){
    double number;
    cout << "請輸入數字:(如果輸入0,結束輸入)";    
    cin >> number;
    if(number == 0){
      break;
    }else{
      vec.push_back(number);
    }
  }
  /*
  for(double item:vec){
    cout << item << endl;
  }
*/
  for(int i=0; i<vec.size(); i++){
    cout << vec[i] << endl;
  }
}
