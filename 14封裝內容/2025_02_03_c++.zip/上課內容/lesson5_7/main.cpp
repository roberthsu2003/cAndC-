#include <iostream>
#include <vector>
using namespace std;


typedef struct student{
  string name;
  int chinese;
  int math;
  int english;
}Student;

void print_student(vector<Student> students){
  for(Student s:students){
    cout << s.name << endl;
    cout << s.math << endl;
    cout << s.chinese << endl;
    cout << s.english << endl;
    cout << "==========" << endl;
  }
}

void input_student(vector<Student>& students){
  Student one;
  one.name = "robert";
  one.chinese = 98;
  one.english = 76;
  one.math = 78;
  Student two = {"jenny", 92, 79, 83};
  Student three = {"alice", 95, 65, 83};

  students.push_back(one);
  students.push_back(two);
  students.push_back(three);
  
}

int main() { 
  vector<Student> students;  
  input_student(students);
  print_student(students);
  
}
