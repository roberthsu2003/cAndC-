#include <iostream>

using namespace std;
class Student{
  public:
    string name;
    int chinese;
    int english;
    int math;
};

int main() { 
  Student stu1;
  stu1.name = "robert";
  stu1.chinese = 78;
  stu1.english = 92;
  stu1.math = 78;

  cout << "學生姓名:" << stu1.name << endl;
  cout << "國文:" << stu1.chinese << endl;
  cout << "英文:" << stu1.english << endl;
  cout << "數學:" << stu1.math << endl;
}
