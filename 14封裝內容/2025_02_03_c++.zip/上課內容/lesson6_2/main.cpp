#include <iostream>

using namespace std;

class Student {
public:
  string name;
  int chinese;
  int english;
  int math;
};

void print_student(Student& s){
  cout << "學生姓名:" << s.name << endl;
  cout << "國文:" << s.chinese << endl;
  cout << "英文:" << s.english << endl;
  cout << "數學:" << s.math << endl;
  int total = s.chinese + s.english + s.math;
  cout << "總分:" << total << endl;
  double average = total / 3.0;
  cout << "平均:" << average << endl;
}

int main() {
  Student stu1;
  stu1.name = "robert";
  stu1.chinese = 78;
  stu1.english = 92;
  stu1.math = 78;
  print_student(stu1);  
}
