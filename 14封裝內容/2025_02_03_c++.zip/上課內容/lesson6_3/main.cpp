#include <iostream>

using namespace std;

class Student {
public:
  string name;
  int chinese;
  int english;
  int math;
};

void print_student(Student &s) {
  cout << "學生姓名:" << s.name << endl;
  cout << "國文:" << s.chinese << endl;
  cout << "英文:" << s.english << endl;
  cout << "數學:" << s.math << endl;
  int total = s.chinese + s.english + s.math;
  cout << "總分:" << total << endl;
  double average = total / 3.0;
  cout << "平均:" << average << endl;
}

Student create_student(string n, int c, int e, int m) {
  Student stu;
  stu.name = n;
  stu.chinese = c;
  stu.english = e;
  stu.math = m;
  return stu;
}

int main() {
  Student stu1 = create_student("robert", 78, 90, 69);
  print_student(stu1);
}
