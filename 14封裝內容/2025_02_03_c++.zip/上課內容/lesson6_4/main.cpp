#include <iostream>

using namespace std;

class Student {
public:
  string name;
  int chinese;
  int english;
  int math;
  //自訂建構式
  Student(string n, int c, int e, int m){
    name = n;
    chinese = c;
    english = e;
    math = m;
  }
};

void print_student(Student &s) {
  cout << "學生姓名:" << s.name << endl;
  cout << "國文:" << s.chinese << endl;
  cout << "英文:" << s.english << endl;
  cout << "數學:" << s.math << endl;
  int total = s.chinese + s.english + s.math;
  cout << "總分:" << total << endl;
  double average = total / 3.0;
  cout << "平均:" << average << endl;
}


int main() {
  Student stu1("robert", 78, 90, 69);
  print_student(stu1);
}
