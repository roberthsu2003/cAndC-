#include <iostream>

using namespace std;

class Student {
public:
  string name;
  int chinese;
  int english;
  int math;
  //自訂建構式
  Student(string n, int c, int e, int m) {
    name = n;
    chinese = c;
    english = e;
    math = m;
  }
  //實體method
  int total() { return chinese + english + math; }
  double average() { return total() / 3.0; }
  void print_student() {
    cout << "學生姓名:" << name << endl;
    cout << "國文:" << chinese << endl;
    cout << "英文:" << english << endl;
    cout << "數學:" << math << endl;
    cout << "總分:" << total() << endl;
    cout << "平均:" << average() << endl;
  }
};

int main() {
  Student stu1("robert", 78, 90, 69);
  cout << "學生姓名:" << stu1.name << endl;
  cout << "總分:" << stu1.total() << endl;
  cout << "平均:" << stu1.average() << endl;
  stu1.print_student();
}
