#include "tools.h"
#include <iostream>

using namespace std;

int main() {
  Student stu1("robert", 78, 90, 69);
  cout << "學生姓名:" << stu1.name << endl;
  cout << "總分:" << stu1.total() << endl;
  cout << "平均:" << stu1.average() << endl;
  stu1.print_student();
}
