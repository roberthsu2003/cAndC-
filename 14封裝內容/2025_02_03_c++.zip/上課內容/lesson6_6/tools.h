#include <iostream>

using namespace std;

class Student {
public:
  string name;
  int chinese;
  int english;
  int math;
  //自訂建構式
  Student(string n, int c, int e, int m);
  //實體method
  int total();
  double average();
  void print_student();
};

void Student::print_student() {
  cout << "學生姓名:" << name << endl;
  cout << "國文:" << chinese << endl;
  cout << "英文:" << english << endl;
  cout << "數學:" << math << endl;
  cout << "總分:" << total() << endl;
  cout << "平均:" << average() << endl;
}

double Student::average() { return total() / 3.0; }

int Student::total() { return chinese + english + math; }

Student::Student(string n, int c, int e, int m) {
  name = n;
  chinese = c;
  english = e;
  math = m;
}
