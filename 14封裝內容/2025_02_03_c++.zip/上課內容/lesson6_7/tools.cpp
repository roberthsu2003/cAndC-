#include "tools.h"

void Student::print_student() {
  cout << "學生姓名:" << name << endl;
  cout << "國文:" << chinese << endl;
  cout << "英文:" << english << endl;
  cout << "數學:" << math << endl;
  cout << "總分:" << total() << endl;
  cout << "平均:" << average() << endl;
}

double Student::average() { return total() / 3.0; }

int Student::total() { return chinese + english + math; }

Student::Student(string n, int c, int e, int m) {
  name = n;
  chinese = c;
  english = e;
  math = m;
}
