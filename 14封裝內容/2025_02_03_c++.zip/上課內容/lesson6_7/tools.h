#ifndef __TOOLS_H__

#define __TOOLS_H__

#include <iostream>

using namespace std;

class Student {
public:
  string name;
  int chinese;
  int english;
  int math;
  //自訂建構式
  Student(string n, int c, int e, int m);
  //實體method
  int total();
  double average();
  void print_student();
};

#endif
