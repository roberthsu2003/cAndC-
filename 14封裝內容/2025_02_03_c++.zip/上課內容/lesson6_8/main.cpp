#include <iostream>
using namespace std;

class Square {
public:
  int width;
  Square(int w) { width = w; }

  virtual int getArea() { return width * width; }
};

class Rectangle : public Square {
  public:
  int height;
  Rectangle(int w, int h):Square(w){
    height = h;
  }
  int getArea()  override{ 
    return width * height; 
  }
};

int main() {
  Square square(10);
  cout << "正方形的面積:" << square.getArea() << endl;

  Rectangle rectangle(8,10);
  cout << "矩形的面積:" << rectangle.getArea() << endl;
}
