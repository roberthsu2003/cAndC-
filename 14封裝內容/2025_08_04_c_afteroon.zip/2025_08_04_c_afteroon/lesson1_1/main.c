#include <stdio.h>

int main(void) {
  printf("Hello World\n");
  printf("這是c語言的第1堂課\n");
  return 0;
}
