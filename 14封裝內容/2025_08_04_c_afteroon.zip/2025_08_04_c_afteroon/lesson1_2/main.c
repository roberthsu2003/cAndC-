#include <stdio.h>

int main(void) {
  printf("這是一個c語言的課程\n");
  printf("我是在'台北家'裏上課\n");
  printf("我是\"第一次\"寫程式\n");
  printf("寫程式很簡單\n");
  printf("我有一個整數:%d\n",10);
  printf("我有一個double:%lf\n",3.1415926);
  return 0;
}
