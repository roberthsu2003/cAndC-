#include <stdio.h>

int main(void) {
  printf("%d + %d = %d\n", 5, 5, 5+5);
  printf("%d * %d = %d\n", 125, 97, 125*97);
  printf("%d / %d = %d\n", 10, 5, 10/5);
  printf("%d / %d = %d\n", 11, 5, 11/5);
  printf("%d + %.2lf = %.2lf\n",5, 5.0, 5+5.0);
  printf("%d / %d = %.2lf\n", 11, 5, 11/5.0);  
  return 0;
}
