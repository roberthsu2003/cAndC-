#include <stdio.h>

int main(void) {
  printf("求梯型面積:(上底+下底) * 高 / 2\n");
  printf("上底:2cm\n");
  printf("下底:3cm\n");
  printf("高:3cm\n");
  printf("面積是%.2lf平方公分",(2 + 3) * 3 / 2.0);
  printf("面積是%.2lf平方公分",(2.0 + 3) * 3 / 2);
  return 0;
}
