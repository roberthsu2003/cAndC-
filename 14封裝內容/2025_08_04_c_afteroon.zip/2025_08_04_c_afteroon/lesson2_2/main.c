#include <stdio.h>

int main(void) {
  printf("求梯型面積(上底+下底) * 高 / 2\n");
  printf("上底:2公分\n");
  printf("下底:3公分\n");
  printf("高:3公分\n");
  int top = 2; //建立變數
  int bottom = 3;
  int height = 3;
  printf("面積是:%.2lf平方公分\n",(top + bottom) * height / 2.0); //自動轉換型別
  printf("面積是:%.2lf平方公分\n",(top + bottom) * height / (double)2); //強制轉換型別
  return 0;
}
