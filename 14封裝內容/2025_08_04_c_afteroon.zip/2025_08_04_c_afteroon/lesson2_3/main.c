#include <stdio.h>

int main(void) {
  int n;
  int m;
  n = 10;
  m = 20;
  printf("n=%d, m=%d\n",n, m);
  n = 100;
  m = 200;
  printf("n=%d, m=%d\n",n, m);

  double dn = 50.0;
  double dn1 = 50;
  printf("dn=%.1lf, dn1=%.2lf\n", dn, dn1);

  n = 10.5;
  m = 20.5;
  printf("n=%d, m=%d\n",n, m);
  return 0;
}
