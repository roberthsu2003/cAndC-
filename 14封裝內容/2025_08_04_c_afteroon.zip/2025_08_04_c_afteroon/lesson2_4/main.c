#include <stdio.h>

int main(void) {
  int top;
  printf("top的記憶體位址是%p\n",&top);
  printf("請輸入top的值:");
  scanf("%d",&top); //輸入
  printf("top內的值是%d\n",top);
  return 0;
}
