#include <stdio.h>

int main(void) {
  printf("求梯型面積(上底+下底) * 高 / 2\n");
  int top, bottom, height;
  printf("請輸入上底:");
  scanf("%d", &top);
  printf("請輸入下底:");
  scanf("%d", &bottom);
  printf("請輸入高:");
  scanf("%d", &height);

  printf("面積是:%.2lf平方公分\n",(top + bottom) * height / 2.0); //自動轉換型別
  return 0;
}
