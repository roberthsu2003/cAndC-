#include <stdio.h>
//運算子的優先順序
int main(void) {
  int result1 = 2 + 3 * 4;
  int result2 = 10 + 5 * 2 - 4;

  printf("result1=%d,result2=%d",result1, result2);
  return 0;
}
