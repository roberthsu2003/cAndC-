#include <stdio.h>

int main(void) {
  int n = 10;
  n = n + 10;
  printf("n=%d\n",n);
  printf("==========\n");

  int m = 10;
  m += 10; //複合指定運算子
  m *= 10;
  printf("m=%d\n",m);
  return 0;
}
