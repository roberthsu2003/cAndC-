#include <stdio.h>
//計算使用者輸入的2個任意數，程式會顯示2數相加的總和。

int main(void) {
  /*
  float n,m;
  printf("請輸入第1個數值:");
  scanf("%f",&n);
  printf("請輸入第2個數值:");
  scanf("%f",&m);
  printf("2數相加%.2f", n + m);
  */
  float n, total = 0; //複合指定運算子的方式來運算
  printf("請輸入第1個數值:");
  scanf("%f", &n);
  total += n;

  printf("請輸入第2個數值:");
  scanf("%f", &n);
  total += n;
  printf("2數相加%.2f", total);
  return 0;
}
