#include <stdio.h>

int main(void) {
  int n = 0;
  ++n;
  n++;
  printf("n=%d\n", n);

  //前置遞增
  int m = 0;
  int m_result = ++m;
  printf("m=%d,m_result=%d\n", m, m_result);

  //後置遞增
  int x = 0;
  int y = x++;
  printf("x=%d,y=%d", x, y);

  return 0;
}
