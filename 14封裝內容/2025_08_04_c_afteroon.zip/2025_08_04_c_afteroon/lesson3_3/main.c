#include <math.h>
#include <stdio.h>

int main(void) {
  double radius, area;
  printf("======計算圓面積======\n");
  printf("請輸入半徑:");
  scanf("%lf", &radius);
  area = pow(radius, 2) * M_PI;
  printf("圓面積:%.2f", area);
  return 0;
}
