
#include <stdio.h>
#include <math.h>

int main(void) {
  double opposite,adjacent,hypotenuse;
  printf("=====畢氏定理========\n");
  printf("請輸入對邊:");
  scanf("%lf", &opposite);
  printf("請輸入鄰邊:");
  scanf("%lf",&adjacent);
  hypotenuse = sqrt(pow(opposite,2) + pow(adjacent,2));
  printf("斜邊為%.2lf", hypotenuse);
  return 0;
}
