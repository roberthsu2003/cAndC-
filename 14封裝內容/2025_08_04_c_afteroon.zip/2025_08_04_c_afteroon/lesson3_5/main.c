#include <stdio.h>

int main(void) {
  unsigned char c = 255;
  printf("c變數的內容值是:%d", c);
  return 0;
}
