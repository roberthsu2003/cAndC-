#include <stdio.h>

int main(void) {
  printf("char的byte數是:%lu\n",sizeof(char)); //sizeof(char)->unsigned long
  printf("char的byte數是:%d\n",(int)sizeof(char)); //強制轉型

  int char_bytes = sizeof(char); //自動轉型
  printf("char的byte數是:%d\n",char_bytes); 
  return 0;
}
