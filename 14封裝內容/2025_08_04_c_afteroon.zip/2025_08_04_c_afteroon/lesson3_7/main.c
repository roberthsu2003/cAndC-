#include <stdio.h>

// c語言沒有bool
//使用1,代表true
//使用0,代表假

int main(void) {
  printf("%d\n", 3 == 3);
  printf("%d\n", 3 != 3);
  return 0;
}
