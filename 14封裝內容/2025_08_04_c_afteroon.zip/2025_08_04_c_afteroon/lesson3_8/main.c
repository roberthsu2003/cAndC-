#include <stdio.h>
//讓使用者輸入三個任意數，程式會顯示三數中的最大數。
int main(void) {
  int in1, in2, in3, max;
  printf("請輸入第1個數:");
  scanf("%d", &in1);

  printf("請輸入第2個數:");
  scanf("%d", &in2);
  max = in1 > in2 ? in1 : in2; //三元運算式

  printf("請輸入第3個數:");
  scanf("%d", &in3);

  max = max > in3 ? max : in3; //三元運算式

  printf("輸入三個數中,最大的數為:%d\n", max);

  return 0;
}
