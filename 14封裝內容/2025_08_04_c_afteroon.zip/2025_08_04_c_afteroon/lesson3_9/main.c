#include <stdio.h>
//判斷是奇數還是偶數

int main(void) {
  int number;
  printf("請輸入一個數值:");
  scanf("%d",&number);

  if (number % 2 == 0){
    printf("%d是偶數",number);
  }else{
    printf("%d的奇數",number);
  }
  
  return 0;
}
