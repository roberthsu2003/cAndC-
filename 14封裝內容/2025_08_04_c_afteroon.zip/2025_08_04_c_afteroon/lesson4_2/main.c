#include <stdio.h>

int main(void) {
  int scores;
  printf("請輸入學生的分數(0~100):");
  scanf("%d", &scores);
  if (scores >= 90) {
    printf("優\n");
  } else {
    if (scores >= 60) {
      printf("及格");
    } else {
      printf("不及格");
    }
  }
  return 0;
}
