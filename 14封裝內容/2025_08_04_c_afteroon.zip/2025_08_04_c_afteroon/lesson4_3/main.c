#include <stdio.h>

int main(void) {
  int scores;
  printf("請輸入學生的分數(0~100):");
  scanf("%d", &scores);
  if (scores >= 90) {
    printf("優\n");
  } else if (scores >= 80) {
    printf("甲\n");
  } else if (scores >= 70) {
    printf("乙\n");
  } else if (scores >= 60) {
    printf("丙\n");
  } else {
    printf("丁\n");
  }
  return 0;
}
