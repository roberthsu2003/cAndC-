#include <math.h>
#include <stdio.h>

int main(void) {
  int height, weight;
  double bmi;
  printf("請輸入身高(cm):");
  scanf("%d", &height);
  printf("請輸入體重(kg):");
  scanf("%d", &weight);

  bmi = weight / pow(height / 100.0, 2);
  printf("BMI:%.2lf\n", bmi);
  return 0;
}
