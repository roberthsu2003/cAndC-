#include <math.h>
#include <stdio.h>

int main(void) {
  int height, weight;
  double bmi;
  printf("請輸入身高(cm):");
  scanf("%d", &height);
  printf("請輸入體重(kg):");
  scanf("%d", &weight);

  bmi = weight / pow(height / 100.0, 2);
  printf("BMI:%.2lf\n", bmi);
  printf("狀態:");
  if (bmi < 18.5) {
    printf("體重過輕\n");
  } else if (bmi < 24) {
    printf("正常範圍\n");
  } else if (bmi < 27) {
    printf("過重\n");
  } else if (bmi < 30) {
    printf("輕度肥胖\n");
  } else if (bmi < 35) {
    printf("中度肥胖\n");
  } else {
    printf("重度肥胖\n");
  }
  return 0;
}
