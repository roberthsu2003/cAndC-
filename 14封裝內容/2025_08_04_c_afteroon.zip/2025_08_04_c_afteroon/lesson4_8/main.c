#include <stdio.h>
//計算目前的年份是否為潤年
int main(void) {
  int year;
  printf("請輸入年份:");
  scanf("%d", &year);
  if(year % 400 == 0 || (year % 4 ==0 && year % 100 != 0)){
    printf("%d是潤年",year);
  }else{
    printf("不是潤年(365日)");
  }
  return 0;
}
