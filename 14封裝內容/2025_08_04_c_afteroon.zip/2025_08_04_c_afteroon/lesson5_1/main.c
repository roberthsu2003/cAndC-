#include <stdio.h>
// 1~10的加總

int main(void) {
  int total = 0;
  int n;
  printf("1加到多少值(不可以<1):");
  scanf("%d", &n);
  for (int i = 1; i <= n; i++) {
    total += i;
  }

  printf("1~%d的加總是:%d\n", n, total);
  return 0;
}
