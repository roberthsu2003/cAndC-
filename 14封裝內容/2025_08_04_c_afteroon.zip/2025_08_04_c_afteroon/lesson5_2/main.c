#include <stdio.h>
//一週七天的總支出

int main(void) {
  int expense, sum = 0;
  for (int day = 1; day <= 7; day++) {
    if (!(day == 7)) {
      printf("請輸入星期%d的支出:", day);
    } else {
      printf("請輸入星期日的支出:");
    }

    scanf("%d", &expense);
    sum += expense;
  }
  printf("本週的總支出為:%d元\n", sum);
  return 0;
}
