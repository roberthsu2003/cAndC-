#include <stdio.h>
//印出直角三角形
//巢狀迴圈

int main(void) {
  for (int i = 1; i <= 5; i++) {
    printf("第%d行:", i);
    for (int j = 1; j <= i; j++) {
      printf("#");
    }
    printf("\n");
  }
  return 0;
}
