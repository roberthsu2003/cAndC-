#include <stdio.h>

int main(void) {
  int choice;
  do {
    printf("\n=== 選單系統 ===\n");
    printf("1. 新增資料\n");
    printf("2. 查詢資料\n");
    printf("3. 修改資料\n");
    printf("4. 刪除資料\n");
    printf("0. 離開系統\n");
    printf("請選擇功能(0-4):");
    scanf("%d", &choice);

    switch (choice) {
    case 1:
      printf("執行新增資料功能\n");
      break;

    case 2:
      printf("執行查詢資料功能\n");
      break;

    case 3:
      printf("執行修改資料功能\n");
      break;

    case 4:
      printf("執行刪除資料功能\n");
      break;

    case 0:
      printf("感謝使用，再見！\n");
      break;

    default:
      printf("無效選擇，請重新輸入");
    }
  } while (choice != 0);
  printf("應用程式結束\n");
  return 0;
}
