#include <stdio.h>
//存錢買機車
//機車30000元
//每個月存剩餘的錢

int main(void) {
  int target = 30000;
  int total = 0; //第1步
  int month = 0;
  int deposit;
  while (1) {
    month += 1;
    printf("請輸入第%d個月的存款:", month);
    scanf("%d", &deposit);
    total += deposit; //第3步
    if (total >= 30000) {
      break;
    }
  }
  printf("恭喜！已經存夠了，存了%d個月的總存款為:%d\n", month, total);
  return 0;
}
