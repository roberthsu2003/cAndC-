#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  // printf("%lu",time(NULL));
  srandom(time(NULL)); //建立亂數種子
  printf("隨機數:%lu\n", random());
  return 0;
}
