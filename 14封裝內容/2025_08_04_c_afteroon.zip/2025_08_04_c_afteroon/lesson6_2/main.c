#include <stdio.h>

int main(void) {
  int scores[3];
  scores[0] = 100;
  scores[1] = 99;
  scores[2] = 98;

  printf("index:%d->%d\n", 0,scores[0]);
  printf("index:%d->%d\n", 1,scores[1]);
  printf("index:%d->%d\n", 2,scores[2]);
  
  return 0;
}
