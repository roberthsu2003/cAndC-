#include <stdio.h>

int main(void) {
  int scores[3] = {100, 99, 98};

  for(int i=0; i<3; i++){ //利用for迴圈,一個一個讀取陣列的值   
    printf("index:%d->%d\n", i,scores[i]);
  }


  return 0;
}
