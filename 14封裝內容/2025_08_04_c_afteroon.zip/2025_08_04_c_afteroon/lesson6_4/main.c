#include <stdio.h>
#include <stdlib.h>

int main(void) {
  int max = 100;
  int min = 50;
  int sum = 0;

  srandom(789);

  int student[5];
  for (int i = 0; i < 5; i++) {
    student[i] = random() % (max - min + 1) + min;
    sum += student[i];
  }

  printf("國文\t英文\t數學\t地理\t歷史\t總分\t平均\n");
  for (int i = 0; i < 5; i++) {
    printf("%d\t", student[i]);
  }
  printf("%d\t%.2f\t", sum, sum / 5.0);
  printf("\n");
  return 0;
}
