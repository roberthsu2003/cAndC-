#include <stdio.h>
#include <stdlib.h>
// 2維陣列
int main(void) {
  srandom(345);
  int min = 50;
  int max = 100;
  int student_num = 50;
  int students[student_num][5];
  printf("國文\t英文\t數學\t地理\t歷史\t總分\t平均\n");
  for (int i = 0; i < student_num; i++) {
    int sum = 0;
    for (int j = 0; j < 5; j++) {
      students[i][j] = random() % (max - min + 1) + min;
      sum += students[i][j];
      printf("%d\t", students[i][j]);
    }
    printf("%d\t%.2f\t", sum, sum / 5.0);
    printf("\n");
  }
  return 0;
}
