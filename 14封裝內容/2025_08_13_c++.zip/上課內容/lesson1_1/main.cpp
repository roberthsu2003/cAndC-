#include <iostream>

int main() { 
  std::cout << "這是c++的輸出的\n";
  printf("這是c-printf()輸出的\n");
}
