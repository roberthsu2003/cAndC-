#include <iostream>
using namespace std;

int main() { 
  int scores = 95;
  cout << "Hello World!\n"; 
  cout << "這是第1節上課" << endl;
  cout << "這是c++語言\n";
  cout << "分數是" << scores << endl;
}
