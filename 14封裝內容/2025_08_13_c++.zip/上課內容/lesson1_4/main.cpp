#include <iomanip>
#include <iostream>
using namespace std;

int main() {
  double pi = 3.14159265359;
  int number = 42;

  //設定小數點位數
  cout << fixed << setprecision(2);
  cout << "圓周率(保留2位小數):" << pi << endl;

  cout << setw(10) << "數字:" << setw(5) << number << endl;
}
