#include <iostream>
using namespace std;

int main() { 
  int age;
  string name;
  double height;

  cout << "請輸入姓名:";
  cin >> name;

  cout << "請輸入年齡:";
  cin >> age;

  cout << "請輸入身高(公尺):";
  cin >> height;

  cout << "\n==== 個人資料 ====" << endl;
  cout << "姓名:" << name << endl;
  cout << "年齡:" << age << "歲" << endl;
  cout << "身高:" << height << "公尺" << endl;
}
