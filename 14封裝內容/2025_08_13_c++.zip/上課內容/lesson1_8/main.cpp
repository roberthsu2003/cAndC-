#include <iostream>
using namespace std;

int main() {
  int scores[3]={100, 99, 98};

  for(int i=0; i<3; i++){
    cout << "元素" << i << ":" << scores[i] << endl;
  }
}
