#include <iostream>
//陣列搜尋
//依靠for迴圈
using namespace std;

int main() {
  srandom(time(NULL));
  int min = 50;
  int max = 100;
  int count = 100;
  int scores[count];
  for (int i = 0; i < count; i++) {
    scores[i] = random() % (max - min + 1) + min;
  }
  //搜尋不及格有多少人
  int less60 = 0;

  for (int i = 0; i < count; i++) {
    if (scores[i] < 60) {
      less60 += 1;
    }
  }

  cout << "不及格的人數有" << less60 << "人" << endl;
}
