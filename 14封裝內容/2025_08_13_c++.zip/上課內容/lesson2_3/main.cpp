#include <iostream>
using namespace std;
int main() {
  //元素數量
  int count = 10;

  //產生亂數值
  srandom(time(NULL));
  int min = 1;
  int max = 100;

  int scores[count];
  for (int i = 0; i < count; i++) {
    scores[i] = random() % (max - min + 1) + min;
  }

  //泡沫排序法
  for (int i = 0; i < count - 1; i++) {
    for (int j = i + 1; j < count; j++) {
      if (scores[i] > scores[j]) {
        // 2數對調
        int temp = scores[i];
        scores[i] = scores[j];
        scores[j] = temp;
      }
    }
  }

  //輸出
  for (int i = 0; i < count; i++) {
    cout << scores[i] << " ";
  }
  cout << endl;
}
