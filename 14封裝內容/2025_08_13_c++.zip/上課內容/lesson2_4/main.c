#include <iostream>
using namespace std;

void play_game(){
  cout << "=====猜數字遊戲======\n\n";
  int min = 1;
  int max = 100;
  int keyin;
  int count = 0;
  int target = random() % (max - min + 1) + min;
  cout << target << endl;

  while (true) {
    cout << "請輸入" << min << "-" << max << "的數字:";
    cin >> keyin;
    count++;
    if (keyin >= min && keyin <= max) {
      if (target == keyin) {
        cout << "恭喜！猜對了！答案是" << target << endl;
        cout << "您總共猜了" << count << "次\n";
        break;
      } else if (keyin > target) {
        cout << "再小一點\n";
        max = keyin - 1;

      } else if (keyin < target) {
        cout << "再大一點\n";
        min = keyin + 1;
      }
      cout << "您已經猜了" << count << "次\n";

    } else {
      cout << "超出範圍,請重新輸入\n";
    }
  }
}

int main(void) {  
  srandom(time(NULL));
  bool play_again;
  while(true){
    play_game();
    cout << "請問還要繼續嗎?(1:yes,0:no)";
    cin >> play_again;
    if(!play_again){
      break;
    }
  }
  
  cout << "遊戲結束\n";
  return 0;
}
