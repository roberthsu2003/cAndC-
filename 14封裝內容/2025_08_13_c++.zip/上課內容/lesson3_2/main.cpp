#include <iostream>
using namespace std;

//輸入攝氏溫度,傳出華氏溫度
float temperature(float celsius){
  return 1.8 * celsius + 32;
}

int main() {
  float celsius;
  cout << "請輸入攝氏溫度:";
  cin >> celsius;
  cout << "華氏是" << temperature(celsius) << endl;
  return 0;
}
