#include <iostream>
#include <math.h>
using namespace std;

int func1(int x){
  return pow(x,2) + 2 * x + 1;
}

int func2(int x, int y){
  return pow(x,3) + 3 * pow(x,2) * y + 3 * x * pow(y, 2) + pow(y,3);
}

int main() {
  cout << "第1題數學題" << endl;
  for(int i=0; i<=10; i++){
    int value = func1(i);
    cout << "x=" << i << ",value=" << value << endl;
  }

  cout << "\n\n第2題數學題" << endl;
  for(int x=1; x<=4; x++){
    for(int y=1; y<=4; y++){
      int result = func2(x, y);
      cout << "x=" << x << ",y=" << y <<"得到的結果是:" << result << endl;
    }
  }
  
}
