#include <iostream>
using namespace std;
// 2數對調

int main() {
  int n = 666, m = 888;
  cout << "對調前:" << endl;
  cout << "n=" << n << ",m=" << m << endl;

  // 2數對調
  int temp = n;
  n = m;
  m = temp;
  cout << "對調後:" << endl;
  cout << "n=" << n << ",m=" << m << endl;
}
