#include <iostream>
using namespace std;

int main() { 
  int n = 10;
  cout << "變數n的值=" << n << endl;
  cout << "變數n的記憶體位址=" << &n << endl;
  cout << "記憶體所佔的bytes=" << sizeof(n) << endl;
}
