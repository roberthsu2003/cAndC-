#include <iostream>
using namespace std;

int main() { 
  int arr[3] = {10, 20, 30};
  cout << "陣列變數arr儲存的記憶體位址:" << arr << endl;
  cout << "===============" << endl;
  //值的存取
  cout << "索引0的元素值是" << arr[0] << endl;
  cout << "===============" << endl;
  //元素的記憶體位址(使用取址運算子)
  cout << "索引0的元素的記憶體位址" << &arr[0] << endl;
  cout << "索引1的元素的記憶體位址" << &arr[1] << endl;
  cout << "索引2的元素的記憶體位址" << &arr[2] << endl;
  cout << "================" << endl;

  //元素的記憶體位址(使用+索引名稱)
  cout << "索引0的元素的記憶體位址" << arr + 0 << endl;
  cout << "索引1的元素的記憶體位址" << arr + 1 << endl;
  cout << "索引2的元素的記憶體位址" << arr + 2 << endl;
  
}
