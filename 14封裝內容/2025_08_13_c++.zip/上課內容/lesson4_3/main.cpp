#include <iostream>
using namespace std;
//指標變數

int main() {
  //建立指標變數
  int *p = new int(10); // new int(10)是動態配置
  double *dp = new double(3.14159);

  cout << "指標變數p儲存的記憶體位址" << p << endl;
  cout << "指標變數db儲存的記憶體位址" << dp << endl;

  cout << "指標變數p指向的值是" << *p << endl;   //取值運算子
  cout << "指標變數db指向的值是" << *dp << endl; //取值運算子

  //刪除動態配置的記憶體
  delete p;
  delete dp;

  return 0;
}
