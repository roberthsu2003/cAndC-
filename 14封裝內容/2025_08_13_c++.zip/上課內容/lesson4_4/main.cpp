#include <iostream>
using namespace std;
//動態配置陣列

int main() { 
  int size=3;
  int *arr = new int[size]; //動態配置

  cout << "請輸入" << size << "個元素值:";
  for (int i=0; i<size; i++){
    cin >> arr[i];
  }

  cout << "陣列元素:";
  for(int i=0; i<size; i++){
    cout << arr[i] << " ";
  }
  cout << endl;
  delete[] arr;
  
  return 0;
}
