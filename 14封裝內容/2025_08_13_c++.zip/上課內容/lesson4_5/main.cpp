#include <iostream>
using namespace std;

//2數相加(使用指標變數)

int main() { 
  int *n = new int(); //動態配置
  int *m = new int(); //動態配置

  cout << "請輸人n的值:";
  cin >> *n; //取值運算子

  cout << "請輸入m的值:";
  cin >> *m; //取值運算子

  int sum = *n + *m;
  cout << "n 和 m的總和為:" << sum << endl;

  delete n;
  delete m;
  return 0;  
}
