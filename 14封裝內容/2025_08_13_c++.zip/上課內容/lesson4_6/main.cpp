#include <iostream>
using namespace std;
int main() {
  int n = 10;
  int *m = new int(20); //動態配置記憶體
  cout << "n=" << n << endl;
  cout << "m=" << *m << endl;
  delete m;
  return 0;
}
