#include <iostream>
using namespace std;
// 2數對調

void swap(int *x, int *y) { // call by address
  int temp = *x;
  *x = *y;
  *y = temp;
}

int main() {
  int n = 666, m = 888;
  cout << "對調前:" << endl;
  cout << "n=" << n << ",m=" << m << endl;
  swap(&n, &m);
  cout << "對調後:" << endl;
  cout << "n=" << n << ",m=" << m << endl;
}
