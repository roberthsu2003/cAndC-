#include <iostream>
using namespace std;

//輸入攝氏溫度,傳出華氏溫度
float *temperature(float *arr, int s) {
  float *result = new float[s];
  for (int i = 0; i < s; i++) {
    result[i] = 1.8 * arr[i] + 32;
  }
  return result;
}

int main() {
  float celsiuses[] = {27.0, 28.0, 29.0, 30.0, 31.0};
  int size = sizeof(celsiuses) / sizeof(celsiuses[0]);
  float *result = temperature(celsiuses, size);

  for (int i = 0; i < size; i++) {
    cout << "攝氏:" << celsiuses[i];
    cout << " 華氏:" << result[i] << endl;
  }
  
  delete[] result;
  return 0;
}
