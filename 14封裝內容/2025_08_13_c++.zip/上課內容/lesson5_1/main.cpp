#include <iostream>
using namespace std;
// typedef->重新定義資料類型的名稱

typedef struct rectangle {
  int width;
  int height;
} Rectangle;

int main() {
  Rectangle rec = {60, 40}; //初始化時,同時給值
  //rec.width = 60;
  //rec.height = 40;

  cout << "矩形寬:" << rec.width << endl;
  cout << "矩形高:" << rec.height << endl;
  cout << "rec的記憶體大小:" << sizeof(rec) << endl;
}
