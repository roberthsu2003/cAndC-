#include <iostream>
using namespace std;

//巢狀結構

typedef struct point {
  float x;
  float y;
} Point;

typedef struct size {
  float width;
  float height;
} Size;

typedef struct rectangle {
  Point p;
  Size s;
} Rectangle;

int main() {
  Rectangle rec1 = {{4.5, 5.6}, {21.5, 18.9}};
  // rec1.p = {4.5, 5.6};
  // rec1.s = {21.5, 18.9};

  cout << "rec1的x座標:" << rec1.p.x << endl;
  cout << "rec1的y座標:" << rec1.p.y << endl;
  cout << "rec1的width:" << rec1.s.width << endl;
  cout << "rec1的height:" << rec1.s.height << endl;
}
