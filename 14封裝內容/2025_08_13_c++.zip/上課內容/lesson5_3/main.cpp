#include <iostream>
using namespace std;

typedef struct student {
  string name;
  int score;
} Student;

int main() {
  srandom(3457);
  int max = 350;
  int min = 250;
  int size = 10;
  Student students[size];
  for (int i = 0; i < size; i++) {
    students[i].name = "stu" + to_string(i + 1);
    students[i].score = random() % (max - min + 1) + min;
  }

  for(int i=0; i<size; i++){
    cout << students[i].name << " ";
    cout << "總分:" << students[i].score << endl;
  }
}
