#include <iostream>
using namespace std;
typedef struct student {
  string name;
  int score;
} Student;

void print_great300(Student *array, int s){
  for(int i=0; i<s; i++){
    if(array[i].score>=300){
      cout << "學生:" << array[i].name << " 分數:" << array[i].score << endl;
    }
  }
}

int main() {
  srandom(3457);
  int max = 350;
  int min = 250;
  int size = 50;
  Student students[size];
  for (int i = 0; i < size; i++) {
    students[i].name = "stu" + to_string(i + 1);
    students[i].score = random() % (max - min + 1) + min;
  }

  cout << "分數大於300分的同學:" << endl;
  print_great300(students, size);
}
