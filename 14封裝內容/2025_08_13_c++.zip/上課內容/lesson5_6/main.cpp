//動態的macro
#include <iostream>
#define SQUARE(x) (x) * (x)

using namespace std;

int main() { 
  int value,result;
  cout << "請輸入數字:";
  cin >> value;
  result = SQUARE(value + 1);
  cout << value << "的平方為:" << result << endl;
}
