#ifndef __GAMES_H__
#define __GAMES_H__

#include <iostream>

#define SQUARE(x) (x) * (x)

using namespace std;

typedef struct student {
  string name;
  int score;
} Student;

void print_great300(Student *array, int s) {
  for (int i = 0; i < s; i++) {
    if (array[i].score >= 300) {
      cout << "學生:" << array[i].name << " 分數:" << array[i].score << endl;
    }
  }
}

void play_game() {
  cout << "=====猜數字遊戲======\n\n";
  int min = 1;
  int max = 100;
  int keyin;
  int count = 0;
  int target = random() % (max - min + 1) + min;
  cout << target << endl;

  while (true) {
    cout << "請輸入" << min << "-" << max << "的數字:";
    cin >> keyin;
    count++;
    if (keyin >= min && keyin <= max) {
      if (target == keyin) {
        cout << "恭喜！猜對了！答案是" << target << endl;
        cout << "您總共猜了" << count << "次\n";
        break;
      } else if (keyin > target) {
        cout << "再小一點\n";
        max = keyin - 1;

      } else if (keyin < target) {
        cout << "再大一點\n";
        min = keyin + 1;
      }
      cout << "您已經猜了" << count << "次\n";

    } else {
      cout << "超出範圍,請重新輸入\n";
    }
  }
}

#endif
