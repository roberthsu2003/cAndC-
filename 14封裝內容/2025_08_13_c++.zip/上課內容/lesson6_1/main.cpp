#include "games.h"
#include "widget.h"
#include <iostream>

using namespace std;

int main(void) {
  srandom(time(NULL));
  bool play_again;
  while (true) {
    play_game();
    cout << "請問還要繼續嗎?(1:yes,0:no)";
    cin >> play_again;
    if (!play_again) {
      break;
    }
  }

  cout << "遊戲結束\n";
  return 0;
}
