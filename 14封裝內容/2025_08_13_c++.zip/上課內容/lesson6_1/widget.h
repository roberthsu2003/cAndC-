#ifndef __WIDGET_H__
#define __WIDGET_H__

#include "games.h"

#endif
