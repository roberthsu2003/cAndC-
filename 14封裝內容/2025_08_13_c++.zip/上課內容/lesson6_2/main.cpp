#include <iostream>
using namespace std;

#define DEBUG_MODE
#define WINDOWS_OS

#ifdef DEBUG_MODE
#define LOG(msg) cout << "[DEBUG] " << msg << endl;
#else
#define LOG(msg)
#endif

int main() {
  LOG("程式開始執行");
  LOG("程式執行完畢");
  return 0;
}
