#include "student.h"
#include <iostream>
using namespace std;

int main() {
  srandom(time(NULL));
  Student students[] = {Student("Robert"),Student("Jenny"),Student("Alice")};
  
  for(int i=0; i<3; i++){
    students[i].show();
    cout << "===============" << endl;
  }
}
