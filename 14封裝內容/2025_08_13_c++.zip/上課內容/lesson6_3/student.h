#ifndef __STUDENT_H__
#define __STUDENT_H__

#include <iostream>
using namespace std;

class Student {
public:
  //自訂field
  string name;
  int chinese = 0;
  int english = 0;
  int math = 0;
  //宣告建構式
  Student(string n);
  Student(string n, int ch, int eng, int mat);
  //宣告實體方法
  void show();
  int sum();
  double average();
};

//實作建構式
Student::Student(string n) {  
  name = n;
  chinese = random() % (100 - 50 + 1) + 50;
  english = random() % (100 - 50 + 1) + 50;
  math = random() % (100 - 50 + 1) + 50;
}

Student::Student(string n, int ch, int eng, int mat) {
  name = n;
  chinese = ch;
  english = eng;
  math = mat;
}

//實作實體方法
void Student::show() {
  cout << "name" << name << endl;
  cout << "chinese:" << chinese << endl;
  cout << "english:" << english << endl;
  cout << "math:" << math << endl;
  cout << "總分" << sum() << endl;
  cout << "平均" << average() << endl;
}

int Student::sum(){
  return chinese + english + math;
}

double Student::average(){
  return sum() / 3.0;
}

#endif
