#include <stdio.h>

int main(void) {
  printf("這是c語言的課程\n");
  printf("Hello! C語言\n");
  return 0;
}
