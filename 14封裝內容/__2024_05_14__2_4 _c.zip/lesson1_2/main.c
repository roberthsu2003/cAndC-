#include <stdio.h>

int main(void) {
  printf("5 + 5 = 10\n");
  printf("%d + 5 = 10\n", 5);
  printf("%d + %d = 30\n", 10, 20);
  printf("%d + %d = %d\n", 10, 20, 30);
  printf("%d + %d = %d\n", 10, 20, 10+20);
  return 0;
}
