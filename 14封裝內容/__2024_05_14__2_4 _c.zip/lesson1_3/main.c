#include <stdio.h>

int main(void) {
  printf("%d * %d = %d\n", 123, 33, 123 * 33);
  printf("%.2lf + %.3lf = %.2lf\n", 5.0, 123.67, 5.0 + 123.67);
  printf("%d + %.2lf = %.2lf\n", 5, 123.67, 5 + 123.67); // int + double 自動轉換
  printf("%d / %d = %lf\n", 5, 3, 5 / 3.0); //自動轉換
  printf("%d / %d = %lf\n", 5, 3, 5 / (double)3); //先手動轉換再自動轉換
  return 0;
}
