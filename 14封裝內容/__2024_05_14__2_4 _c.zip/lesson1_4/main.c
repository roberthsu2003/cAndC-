#include <stdio.h>

int main(void) {
  printf("求梯型面積(上底+下底) * 高 / 2\n");
  printf("上底:2\n");
  printf("下底:3\n");
  printf("高:3\n");
  printf("面積:%.3lf\n",(2 + 3) * 3 / 2.0);
  printf("面積:%.3lf\n",(2 + 3) * (double)3 / 2);
  return 0;
}
