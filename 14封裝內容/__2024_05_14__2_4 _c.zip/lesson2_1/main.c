#include <stdio.h>

int main(void) {
  printf("求梯型面積(上底+下底) * 高 / 2\n");
  //建立變數
  int top = 2;
  int bottom = 3;
  int height = 3;

  //改變變數值
  top = 134;
  bottom = 256;
  height = 123;

  printf("上底:%d\n", top);
  printf("下底:%d\n", bottom);
  printf("高:%d\n", height);
  printf("面積:%.3lf\n", (top + bottom) * height / 2.0);
  printf("面積:%.3lf\n", (top + bottom) * (double)height / 2);
}
