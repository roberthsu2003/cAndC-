#include <stdio.h>

int main(void) {
  const char* name = "徐國堂";  
  printf("您的姓名是:%s",name);
  return 0;
}
