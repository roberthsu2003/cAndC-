#include <stdio.h>

int main(void) {
  int n = 10;
  printf("n變數內的值是%d\n",n);
  printf("n的記憶體位址%p\n",&n);
  return 0;
}
