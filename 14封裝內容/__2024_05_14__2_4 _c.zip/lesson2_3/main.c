#include <stdio.h>

int main(void) {
  printf("求梯型面積(上底+下底) * 高 / 2\n");
  //建立變數
  int top;
  int bottom;
  int height;
  printf("請輸入上底(整數):");
  scanf("%d",&top);

  printf("請輸入下底(整數):");
  scanf("%d",&bottom);

  printf("請輸入高(整數):");
  scanf("%d",&height);

  

  printf("上底:%d\n", top);
  printf("下底:%d\n", bottom);
  printf("高:%d\n", height);
  printf("面積:%.3lf\n", (top + bottom) * height / 2.0);
  printf("面積:%.3lf\n", (top + bottom) * (double)height / 2);
}
