#include <stdio.h>

int main(void) {
  unsigned char n = 100;
  printf("n=%d\n", n);
  short m = -20000;
  printf("m=%d\n", m);
  long l = 2100000;
  printf("l=%ld\n",l);
  long long l_long = 3456789012345;
  printf("l_long=%lld\n",l_long);

  float pi = 3.14;
  printf("pi=%.2f\n",pi);

  double pi1 = 3.1415926;
  printf("pi1=%lf\n",pi1);
  return 0;
}
