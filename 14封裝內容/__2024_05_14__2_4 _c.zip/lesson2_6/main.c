/*
輸入出生「民國年份」後，求取對應「西元年份」及「現在年齡」。
公式
西元年份 = 民國年份xx + 1911
年齡 = 現在年份-西元年份

顯示==================================
出生民國年份:69
對應西元年份:1980，今年39歲
*/

#include <stdio.h>

int main(void) {
  int year, westernYear, age;
  printf("出生民國年份:");
  scanf("%d", &year);
  westernYear = year + 1911;
  age = 2024 - westernYear;
  printf("對應西元年份:%d，今年%d歲", westernYear, age);
  return 0;
}
