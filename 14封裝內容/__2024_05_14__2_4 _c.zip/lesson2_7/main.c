/*
同步登錄「國文、英文、數學」學測成績， 進行三科「總分、平均」計算報告。
提示．將「總分、平均」求取項目結果值後，輸出。

顯示====================================
科目:國文,英文,數學
請輸入:92 85 73

---計算學測分數----
三科總分:250
三科平均:83.3
*/
#include <stdio.h>

int main(void) {
  int chinese, english, math, total;
  double average;
  printf("科目:國文,英文,數學\n");
  printf("請輸入:國文 英文 數學:");
  scanf("%d %d %d",&chinese, &english, &math);
  total = chinese + english + math;
  average = total / 3.0;
  printf("\n---計算學測分數----\n");
  printf("三科總分:%d\n",total);
  printf("三科平均:%.2lf\n",average);
  return 0;
}
