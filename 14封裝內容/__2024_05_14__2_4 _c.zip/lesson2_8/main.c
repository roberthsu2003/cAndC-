#include <stdio.h>

int main(void) {
  char myChar = 'z';
  printf("myChar:%c\n",myChar);
  printf("myChar(ASCII):%d\n",myChar);
  return 0;
}
