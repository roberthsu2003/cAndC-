#include <stdio.h>

int main(void) {
  printf("姓名\t座號\t電話\n");
  printf("李振聲\t11\t\t0229435437\n");
  printf("王振凱\t13\t\t0229435437\n");
  return 0;
}
