#include <stdio.h>

int main(void) {
  double height, weight, BMI;
  printf("請輸入身高(公分):");
  scanf("%lf", &height);
  printf("請輸入體重(公斤):");
  scanf("%lf", &weight);
  height = height/100;
  BMI = weight/(height*height);
  printf("BMI值為:%.3lf\n", BMI);
  return 0;
}
