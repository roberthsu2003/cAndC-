#include <stdio.h>

int main(void) {
  double radius;
  radius = 10.0;
  const double PI = 3.14159;
  printf("面積是%.2lf\n",radius * radius * PI);
  return 0;
}
