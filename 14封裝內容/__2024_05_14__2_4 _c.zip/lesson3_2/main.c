#include <stdio.h>

int main(void) {
  int n = 0;
  //n++; //1行程式,最後才加1
  ++n;//1行程式,1開始就加1
  printf("n=%d", n);
  return 0;
}
