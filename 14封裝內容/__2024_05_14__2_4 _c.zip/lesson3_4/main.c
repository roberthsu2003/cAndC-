#include <stdio.h>
//複合指定運算子
int main(void) {
  int n = 10;
  n += 10;
  printf("n=%d\n",n);
  n *= 5;
  printf("n=%d\n",n);
  return 0;
}
