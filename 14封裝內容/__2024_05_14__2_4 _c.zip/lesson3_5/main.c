#include <stdio.h>

//讓用者輸入三個任意數，程式會顯示3數相加的總和(double)

int main(void) {
  double x;
  double total = 0;
  printf("請輸入第1個數:");
  scanf("%lf",&x);
  total += x;
  
  printf("請輸入第2個數:");
  scanf("%lf",&x);
  total += x;
  
  printf("請輸入第3個數:");
  scanf("%lf",&x);
  total += x;
  
  printf("total=%lf\n",total);
  return 0;
}
