//學生總分為300分
//檢查輸入,超過300分,顯示錯誤訊息
//學生符合加分條件就加5%分
//符合加分條件,並且超過300分,以300計算
#include <stdio.h>

int main(void) {
  int scores;
  int add;
  printf("請輸入學生的分數:");
  scanf("%d",&scores);
  if(scores <= 300){
    if(scores>=0){
      printf("學生符合加分條件嗎? yes請輸入1,no請輸入0:");
      scanf("%d", &add);
      //單項選擇,有可能執行,有可能不執行
      if(add){
        scores *= 1.05;
        if(scores > 300){ //巢狀判斷
          scores = 300;
        }
      }

      printf("學生分數是:%d\n",scores);
    }else{
      printf("不可以小於0\n");
    }
    
  }else{
    printf("超過輸出範圍\n");
  }

  printf("應用程式結束\n");
  
  
  return 0;
}
