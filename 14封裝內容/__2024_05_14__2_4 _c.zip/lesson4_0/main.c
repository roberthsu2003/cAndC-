#include <stdio.h>

int main(void) {
  double num1;
  double sum = 0;
  printf("Please enter a value：");
  scanf("%lf", &num1);
  sum = num1;
  num1 *= num1;
  sum *= num1;
  printf("The square value is %.2lf\n", num1);
  printf("The cube value is %.2lf\n", sum);
  return 0;
}
