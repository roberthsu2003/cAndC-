#include <stdio.h>

int main(void) {
  int scores;
  printf("請輸入學生的分數:");
  scanf("%d", &scores);
  if(scores < 0 || scores > 300){
    printf("<0 或者 >300");    
  }else{
    printf("您的數值是0~300");
  }
  return 0;
}
