//讓使用者輸入加、減、乘、除運算子, 就會顯示運算結果
#include <stdio.h>

int main(void) {
  int num1=20,num2=4;
  char op;
  printf("num1=%d,num2=%d\n",num1,num2);
  printf("請輸入要執行的運算(+-*/):");
  scanf("%c",&op);

  switch(op){
    case '+':
    printf("num1+num2=%d\n",num1+num2);
    break;

    case '-':
    printf("num1-num2=%d\n",num1-num2);
    break;

    case '*':
    printf("num1*num2=%d\n",num1*num2);
    break;

    case '/':
    printf("num1/num2=%d\n",num1/num2);
    break;

    default:
    printf("無法執行運算!\n");
  }
  
  return 0;
}
