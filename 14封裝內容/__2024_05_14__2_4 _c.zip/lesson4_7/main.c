#include <stdio.h>

int main(void) {
  int total = 0;
  int n;
  printf("相加1~n的值,n:");
  scanf("%d", &n);
  for(int i=1;i<=n;i++){
    total += i;
  }
  printf("1~%d相加:%d\n",n,total);
  return 0;
}
