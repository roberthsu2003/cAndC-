//計算固定中的支出，媽媽每天會將家裡的花費記錄下來，並且計算本週的花費總和
#include <stdio.h>

int main(void) {
  int n;
  int total = 0;
  for(int i=1; i<=7; i++){
    if(i==7){
      printf("請輸入星期日的支出:");
    }else{
      printf("請輸入星期%d的支出:",i);
    }
    
    scanf("%d",&n);
    total += n;
  }
  printf("本星期的支出為:%d\n",total);
  return 0;
}
