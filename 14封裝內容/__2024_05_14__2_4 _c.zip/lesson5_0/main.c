#include <stdio.h>

int main(void) {
  double height, weight, BMI;
  const char* message;

  printf("請輸入身高(公分):");
  scanf("%lf", &height);
  printf("請輸入體重(公斤):");
  scanf("%lf", &weight);
  BMI = weight / ((height / 100) * (height / 100));
  printf("您的BMI=%.2f\n", BMI);

  if (BMI >=35) 
    {
      message = "您的體重屬於重度肥胖";
    }
  else if (BMI >=30)
    {
      message = "您的體重屬於中度肥胖";
    }
  else if (BMI >=27)
    {
      message = "您的體重屬於輕度肥胖";
    }
  else if (BMI >=24)
    {
      message = "您的體重過重";
    }
  else if (BMI >=18.5)
    {
      message = "您的體重屬於正常範圍";
    }
  else
    {
      message = "您的體重過輕";
    }
  printf("%s\n",message);
  return 0;
}
