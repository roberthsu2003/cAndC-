#include <stdio.h>

int main(void) {
  int total = 0;
  for (int i = 1; i <= 10; i++) {
    total += i;
  }
  printf("total:%d\n", total);

  // while,明確知道執行的次數
  int i = 1, sum = 0;
  while (i <= 10) {
    sum += i;
    i++;
  }
  printf("sum:%d\n", sum);
  return 0;
}
