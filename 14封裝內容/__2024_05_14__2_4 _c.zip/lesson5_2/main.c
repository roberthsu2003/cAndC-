#include <stdio.h>
//小明想要存錢買一輛機車,機車每輛30000元，他將每月存的錢輸入，當存款足夠買機車時，就顯示提示訊息告知。
int main(void) {
  int deposit = 0, num = 0;
  int input_money;
  while (deposit < 30000) {
    printf("請輸入第%d個月份的存款:", ++num);
    scanf("%d", &input_money);
    deposit += input_money;
  }
  printf("恭喜!已經存了%d個月,總存款為:%d\n", num, deposit);
  return 0;
}
