//預設的密碼為5678，使用者若輸入的密碼錯誤，將不斷出現輸入密碼訊息，直到輸入的密碼正確才顯示正確訊息
#include <stdio.h>

int main(void) {
  int password;
  while(1){
    printf("請輸入密碼:");
    scanf("%d",&password);
    if(password==5678){
      break;
    }else{
      printf("密碼輸入錯誤\n");
    }
  }
  printf("密碼輸入正確\n");
  return 0;
}
