//請設計一個程式，讓使用者輸入數值，只有加總正偶數值，不加總正奇數值，如果輸入負數，結束程式。
#include <stdio.h>

int main(void) {
  int num=0;
  int input_value;
  int sum = 0;
  while(1){
    printf("請輸入第%d個數:",++num);
    scanf("%d", &input_value);
    if(input_value < 0){
      break;
    }else if(input_value % 2 == 1){
      continue;
    }
    sum += input_value;
  }
  printf("所有輸入的正偶數的加總是:%d",sum);
  return 0;
}
