#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  // printf("%ld",time(NULL));
  srandom(time(NULL));
  //0~9
  int target = random() % 10;
  printf("%d\n", target);
  //1~10
  int target1 = (random() % 10) + 1;
  printf("%d\n", target1);
  //亂數 % (max-min+1) + min
  int max=45;
  int min=40;
  int target2 = random() % (max-min+1) + min;
  printf("%d\n", target2);
  return 0;
}
