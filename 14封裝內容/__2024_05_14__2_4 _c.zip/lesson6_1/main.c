#include <stdio.h>

int main(void) {
  int inputValue1,inputValue2;
  int min,max;
  int maxResult,minResult;
  printf("請輸入第一個整數:");
  scanf("%d",&inputValue1);
  printf("請輸入第二個整數:");
  scanf("%d",&inputValue2);
  min = inputValue1 < inputValue2 ? inputValue1 : inputValue2;
  max = inputValue1 > inputValue2 ? inputValue1 : inputValue2;
  for(int i=1; i<=min; i++){
    if((min % i == 0) && (max % i == 0)){
      maxResult = i;
    }
  }

  minResult = (inputValue1 / maxResult) * (inputValue2 / maxResult) * maxResult;
  printf("%d和%d的最大公因數:%d\n",inputValue1,inputValue2,maxResult);
  printf("%d和%d的最小公倍數:%d\n",inputValue1,inputValue2,minResult);
    
  
  return 0;
}
