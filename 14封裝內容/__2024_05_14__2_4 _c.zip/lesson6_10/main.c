#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(void) {
  srandom(time(NULL));
  int min=50;
  int max=100;
  int subject = 5;
  int scores[3][subject]; 
  
  for(int j=0;j<3;j++){
    int sum = 0;
    double average;
    for (int i = 0; i < subject; i++) {
      scores[j][i] = random() % (max-min+1) + min;
      printf("第%d科:%d\n",i+1,scores[j][i]);
      sum += scores[j][i];
    }
    average = sum / (double)subject;
    printf("學生總分是:%d\n", sum);
    printf("學生平均是:%.2lf\n",average);
    printf("===================\n");
    
  }
  
  return 0;
}
