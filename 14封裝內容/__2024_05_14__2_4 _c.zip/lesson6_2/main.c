#include <stdio.h>

int get_maxResult(int value1, int value2) {
  int min, max;
  int maxResult;
  min = value1 < value2 ? value1 : value2;
  max = value1 > value2 ? value1 : value2;
  for (int i = 1; i <= min; i++) {
    if ((min % i == 0) && (max % i == 0)) {
      maxResult = i;
    }
  }
  return maxResult;
}

int get_minResult(int value1, int value2){  
  int maxResult,minResult;
  maxResult = get_maxResult(value1,value2);
  minResult = (value1 / maxResult) * (value2 / maxResult) * maxResult;
  return minResult;
}

int main(void) {
  int inputValue1, inputValue2;
  int maxResult, minResult;
  printf("請輸入第一個整數:");
  scanf("%d", &inputValue1);
  printf("請輸入第二個整數:");
  scanf("%d", &inputValue2);
  maxResult = get_maxResult(inputValue1, inputValue2);
  minResult = get_minResult(inputValue1, inputValue2);
  printf("%d和%d的最大公因數:%d\n", inputValue1, inputValue2, maxResult);
  printf("%d和%d的最小公倍數:%d\n",inputValue1,inputValue2,minResult);
  return 0;
}
