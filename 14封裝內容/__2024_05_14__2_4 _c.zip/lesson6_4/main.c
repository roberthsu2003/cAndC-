#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "game.h"

int main(void) {
  int again;
  srandom(time(NULL));
  while(1){
    play_game();
    printf("\n還要再玩嗎?(yes請按1,no請按0)");
    scanf("%d",&again);
    if(again == 0){
      break;
    }
  }

  printf("遊戲結束\n");
  return 0;
}
