#include <stdio.h>

int main(void) {
  int scores[3];
  scores[0] = 70;
  scores[1] = 80;
  scores[2] = 90;
  printf("%d,%d,%d\n",scores[0],scores[1],scores[2]);
  return 0;
}
