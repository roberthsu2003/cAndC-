#include <stdio.h>

int main(void) {
  const int nums = 3;
  int scores[] = {70, 80, 90};
  for (int i = 0; i < nums; i++) {
    printf("scores[%d]=%d\n", i, scores[i]);
  }
  return 0;
}
