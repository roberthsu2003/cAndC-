#include <stdio.h>
int main(void) {
  int subject = 5;
  int scores[subject];
  int sum = 0;
  double average;
  printf("請輸入學生的5科分數(國文,英文,數學,地王,歷史):");
  scanf("%d,%d,%d,%d,%d", &scores[0], &scores[1], &scores[2], &scores[3],
        &scores[4]);
  for (int i = 0; i < subject; i++) {
    sum += scores[i];
  }
  average = sum / (double)subject;
  printf("學生總分是:%d\n", sum);
  printf("學生平均是:%.2lf\n",average);
  return 0;
}
