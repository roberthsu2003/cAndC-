#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(void) {
  srandom(time(NULL));
  int min=50;
  int max=100;
  int subject = 5;
  int scores[subject];
  int sum = 0;
  double average;
  
  for (int i = 0; i < subject; i++) {
    scores[i] = random() % (max-min+1) + min;
    printf("第%d科:%d\n",i+1,scores[i]);
    sum += scores[i];
  }
  average = sum / (double)subject;
  printf("學生總分是:%d\n", sum);
  printf("學生平均是:%.2lf\n",average);
  return 0;
}
