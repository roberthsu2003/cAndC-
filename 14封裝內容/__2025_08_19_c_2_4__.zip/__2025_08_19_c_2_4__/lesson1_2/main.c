#include <stdio.h>

int main(void) {
  printf("這是c語言的第1堂課!\n");
  printf("這是int:%d\n",5);
  printf("這是double:%lf\n",5.0);
  printf("int:%d,double:%.7lf\n",10,3.1415926);
  return 0;
}
