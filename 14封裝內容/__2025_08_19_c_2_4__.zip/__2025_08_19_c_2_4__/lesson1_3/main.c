#include <stdio.h>

int main(void) {
  printf("%d + %d = %d\n",312,65,312+65);
  printf("%d * %d = %d\n",45,92,45*92);
  printf("%d / %d = %d\n",45,4,45/4);
  printf("%d - %d = %d\n",123,567,123-567);

  printf("==============\n");
  printf("%.2lf + %.2lf = %.2lf\n",312.0,65.0,312.0+65.0);
  printf("%.2lf * %.2lf = %.2lf\n",45.0,92.0,45.0*92.0);
  printf("%.2lf / %.2lf = %.2lf\n",45.0,4.0,45.0/4.0);
  printf("%.2lf - %.2lf = %.2lf\n",123.0,567.0,123.0-567.0);
  return 0;
}
