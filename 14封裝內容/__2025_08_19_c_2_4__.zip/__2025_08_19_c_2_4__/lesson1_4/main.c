#include <stdio.h>

int main(void) {
  printf("%d + %.2lf = %.2lf\n",312,65.0,312+65.0);
  printf("%d * %.2lf = %.2lf\n",45,92.0,45*92.0);
  printf("%d / %.2lf = %.2lf\n",45,4.0,45/4.0);
  printf("%d - %.2lf = %.2lf\n",123,567.0,123-567.0);
  return 0;
}
