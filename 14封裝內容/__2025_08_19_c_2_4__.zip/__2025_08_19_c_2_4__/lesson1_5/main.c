#include <stdio.h>

int main(void) {
  printf("計算矩形面積\n");
  printf("矩形寬:%d\n",15);
  printf("矩形高:%.2lf\n",7.8);
  printf("矩形面積:%.2lf\n",15*7.8);
  printf("矩形周長是%.2lf",(15 + 7.8) * 2);
  return 0;
}
