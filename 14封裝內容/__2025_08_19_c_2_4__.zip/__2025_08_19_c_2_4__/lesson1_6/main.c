#include <stdio.h>

int main(void) {
  //建立變數
  int width = 30;
  double height = 3.5;
  printf("計算矩形面積\n");
  printf("矩形寬:%d\n",width);
  printf("矩形高:%.2lf\n",height);
  printf("矩形面積:%.2lf\n",width * height);
  printf("矩形周長是%.2lf",(width + height) * 2);
  return 0;
}
