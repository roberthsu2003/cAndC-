#include <stdio.h>

int main(void) {
  int n;
  n = 9.2;                                  //自動轉換
  int m = 2.2;                              //自動轉換
  printf("9 / 2 = %.2lf\n", n / (double)m); //強制轉換->自動轉換
  return 0;
}
