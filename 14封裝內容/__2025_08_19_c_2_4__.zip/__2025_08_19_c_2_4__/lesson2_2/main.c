#include <stdio.h>
/*
*實作：梯形面積
*公式：(上底 + 下底) * 高 / 2
*/
int main(void) {
  int top = 2;
  int bottom = 3;
  int height = 3;
  printf("梯形面積\n");
  printf("上底:%d,下底:%d,高:%d\n",top, bottom, height);
  printf("面積是:%.2lf\n",(top + bottom) * height / 2.0); //自動轉換
  printf("面積是:%.2lf\n",(top + bottom) * (double)height / 2); //強制轉換
  return 0;
}
