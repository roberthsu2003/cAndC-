#include <stdio.h>

int main(void) {
  int width;
  //輸入
  printf("請輸入寬:");
  scanf("%d", &width);
  printf("寬:%d\n", width);
  printf("width的記憶體位址:%p\n", &width);
  return 0;
}
