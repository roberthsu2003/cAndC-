#include <stdio.h>

int main(void) {
  int result1 = 2 + 3 * 4;
  printf("2 + 3 * 4 = %d\n", result1);
  int a = 10, b = 5, c = 2;
  int result2 = a + b * c - 4;
  printf("%d + %d * %d - 4 = %d \n", a, b, c, result2);
  return 0;
}
