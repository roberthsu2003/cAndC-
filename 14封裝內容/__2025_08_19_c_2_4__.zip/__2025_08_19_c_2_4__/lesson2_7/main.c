#include <stdio.h>
#include <math.h>
/*
讓使用者輸入圓柱體的半徑及高，程式會計算圓柱體的體積(圓柱體體積的公式為「圓週率乘以半徑平方再乘以高)。

顯示========
請輸入圓柱體的半徑(公分):10
請輸入圓柱體的高(公分):5
圓柱體的體積:xxxx立方公分
*/

int main(void) {
  double radius, height, area; //變數
  const double PI = 3.1415926; //常數
  printf("請輸入圓柱體的半徑(公分):");
  scanf("%lf", &radius);
  printf("請輸入圓柱體的高(公分)");
  scanf("%lf", &height);
  area = pow(radius, 2) * PI * height;
  printf("圓柱體的體積:%.2lf立方公分\n", area);
  return 0;
}
