#include <stdio.h>
//讓用者輸入三個任意數，程式會顯示3數相加的總和(float)
int main(void) {
  float value1, value2, value3;
  double sum;

  printf("請輸入第一個數:");
  scanf("%f", &value1);

  printf("請輸入第二個數:");
  scanf("%f", &value2);

  printf("請輸入第三個數:");
  scanf("%f", &value3);

  sum = value1 + value2 + value3;
  printf("3數總合是:%.2lf\n", sum);

  return 0;
}
