#include <stdio.h>
//讓用者輸入三個任意數，程式會顯示3數相加的總和(float)
//使用複合指定運算子

int main(void) {
  float value;
  double sum = 0;

  printf("請輸入第一個數:");
  scanf("%f", &value);
  sum += value;

  printf("請輸入第二個數:");
  scanf("%f", &value);
  sum += value;

  printf("請輸入第三個數:");
  scanf("%f", &value);

  sum += value;

  printf("3數總合是:%.2lf\n", sum);

  return 0;
}
