#include <stdio.h>
//遞增,遞減運算子

int main(void) {
  int n = 10;
  int m = ++n; //先加1,再執行=
  printf("n=%d,m=%d\n", n, m);

  int x = 10;
  int y = x++; //執行=完後再加1
  printf("x=%d,y=%d\n", x, y);
  return 0;
}
