#include <stdio.h>

int main(void) {
  unsigned char ch = 255;
  printf("ch=%u\n", ch);


  char c = 'F';
  printf("c=%c\n",c);

  float pi = 3.1415926;
  printf("pi=%f\n", pi);

  double pi1 = 3.1415926;
  printf("pi1=%.8lf\n", pi1);

  printf("pi1=%e\n", pi1);
  return 0;
}
