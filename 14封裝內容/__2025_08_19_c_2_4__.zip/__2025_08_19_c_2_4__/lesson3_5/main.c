#include <stdio.h>

int main(void) {
  printf("5>3是%d\n",5>3);
  printf("3>3是%d\n",3>3);
  return 0;
}
