#include <stdio.h>
//奇偶數判斷

int main(void) {
  int number;
  printf("請輸入一個整數:");
  scanf("%d", &number);

  if (number % 2 == 0) { // 2個程式區段只會執行1個
    printf("%d是偶數/n", number);
  } else {
    printf("%d是奇數/n", number);
  }
  return 0;
}
