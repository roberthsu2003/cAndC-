#include <stdio.h>

int main(void) {
  int score;
  int hasBonus;
  printf("請輸入學生的分數:");
  scanf("%d", &score);
  printf("學生符合加分條件嗎?(1=是, 0=否):");
  scanf("%d", &hasBonus);
  if (hasBonus) {  //單項選擇
    score *= 1.05; // 加%5
  }
  printf("學生最終分數是:%d\n", score);
  return 0;
}
