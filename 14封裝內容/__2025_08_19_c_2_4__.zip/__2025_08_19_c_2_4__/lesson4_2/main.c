#include <stdio.h>

int main(void) {
  int scores;
  printf("請輸入學生分數(0~100):");
  scanf("%d", &scores);
  if (scores >= 90) {
    printf("%s\n", "優等");
  } else if (scores >= 60) {
    // scores < 90
    printf("%s\n", "一般");
  } else {
    // scores < 60
    printf("%s\n", "不及格");
  }

  return 0;
}
