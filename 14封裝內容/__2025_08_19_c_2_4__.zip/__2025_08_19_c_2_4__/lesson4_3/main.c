#include <stdio.h>
/*
>= 90 優等 ->1個條件
>= 80 甲等 ->2個條件
>= 70 乙等 ->2個條件
>= 60 丙等 -> 2個條件
<60   丁等 -> 1個條件
*/

int main(void) {
  int scores;
  printf("請輸入學生分數(0~100):");
  scanf("%d", &scores);
  if(scores>=90){
    printf("%s\n","優等");
  }else if(scores >= 80){
    printf("%s\n","甲等");
  }else if(scores >= 70){
    printf("%s\n","乙等");
  }else if(scores >= 60){
    printf("%s\n","丙等");
  }else{
    printf("%s\n","丁等");
  }
  
  return 0;
}
