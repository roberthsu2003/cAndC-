#include <stdio.h>
/*
age 22~30 外勤業務員
age 31~45 內勤文書
age 46~55 倉庫管理員
age >65 強迫退休
*/

int main(void) {
  int age;
  printf("請輸入您的年齡:");
  scanf("%d", &age);
  if (age >= 22 && age <= 30) {
    printf("您的職務是:%s\n", "外勤業務員");
  } else if (age >= 32 && age <= 45) {
    printf("您的職務是:%s\n", "內勤文書");
  } else if (age >= 46 && age <= 55) {
    printf("您的職務是:%s\n", "倉庫管理員");
  } else if (age >= 56) {
    printf("強迫退休\n");
  } else {
    printf("年齡不符合工作條件\n");
  }
  return 0;
}
