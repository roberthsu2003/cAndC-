#include <stdio.h>

int main(void) {
  int year;
  printf("請輸入年份:");
  scanf("%d", &year);

  if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
    printf("%d是潤年\n", year);
  } else {
    printf("%d不是潤年\n", year);
  }
  return 0;
}
