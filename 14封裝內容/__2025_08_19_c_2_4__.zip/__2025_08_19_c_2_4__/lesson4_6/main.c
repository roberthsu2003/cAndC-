#include <stdio.h>

int main(void) {
  int choice;

  printf("=== 問候語翻譯 ===\n");
  printf("1. 您好嗎？\n");
  printf("2. 晚安\n");
  printf("3. 早安\n");
  printf("請選擇中文的選項 (1-3):");
  scanf("%d", &choice);

  switch (choice) {
  case 1:
    printf("英文是: How are you?\n");
    break;

  case 2:
    printf("英文是: Good evening\n");
    break;

  case 3:
    printf("英文是: Good morning\n");
    break;

  default:
    printf("無效的選項！\n");
  }
  return 0;
}
