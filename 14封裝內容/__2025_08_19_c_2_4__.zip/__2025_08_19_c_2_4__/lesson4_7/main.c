#include <stdio.h>
// 1加到10是多少
int main(void) {
  int sum = 0;
  int end;
  printf("請輸入加總到最後的值是:");
  scanf("%d", &end);
  for (int i = 1; i <= end; i++) {
    sum += i;
    printf("第%d次迴圈,目前總和為:%d\n",i,sum);
  }

  printf("1~%d的加總是:%d\n",end ,sum);
  return 0;
}
