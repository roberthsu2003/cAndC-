#include <stdio.h>

//計算1週的總消費

int main(void) {
  int sum = 0;
  int expense;
  for (int day = 1; day <= 7; day++) {
    if (day == 7) {
      printf("請輸入星期日的支出:");
    } else {
      printf("請輸入星期%d的支出:", day);
    }

    scanf("%d", &expense);
    sum += expense;
  }
  printf("本週的總支出為:%d元\n", sum);
  return 0;
}
