#include <stdio.h>
//巢狀迴圈
int main(void) {
  printf("====九九乘法表======\n\n");
  for (int i = 1; i <= 9; i++) {
    for (int j = 1; j <= 9; j++) {
      printf("%d*%d=%d\t", i, j, i*j);
    }
    printf("\n");
  }
  return 0;
}
