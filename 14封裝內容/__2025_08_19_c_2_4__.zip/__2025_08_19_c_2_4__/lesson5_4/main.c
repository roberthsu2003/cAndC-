#include <stdio.h>

int main(void) {
  int target = 10000; //目標金額
  int total = 0;      //總存款
  int deposit;        //每月存款
  int month = 0;
  while (total < target) {
    printf("第%d月份的存款是:", ++month);
    scanf("%d", &deposit);
    total += deposit;
  }
  printf("共花%d個月存款已經足夠,共存了%d元\n", month, total);
  return 0;
}
