#include <stdbool.h>
#include <stdio.h>

//目的：學習使用 while 迴圈進行輸入驗證，確保資料正確性
int main(void) {
  int score;
  printf("請輸入一個 0-100 之間的成績：\n");
  while (true) {
    printf("請輸入成績:");
    scanf("%d", &score);
    if (score >= 0 && score <= 100) {
      break; //強制跳出迴圈
    } else {
      printf("輸入錯誤！成績必須在 0-100 之間，請重新輸入。\n");
    }
  }

  printf("您輸的成績是%d分\n", score);
  if (score >= 60) {
    printf("恭喜及格！\n");
  } else {
    printf("需要加油喔！\n");
  }

  return 0;
}
