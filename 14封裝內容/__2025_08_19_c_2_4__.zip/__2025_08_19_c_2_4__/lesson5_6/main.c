#include <stdio.h>

//目的：學習建立完整的選單驅動程式

int main(void) {
  int choice;
  int balance = 1000; //帳啟餘額
  int amount; 
  printf("====ATM 系統===\n");
  printf("歡迎使用！您的初始餘額為: %d 元\n", balance);
  do {
    printf("\n=== 主選單 ===\n");
    printf("1. 查詢餘額\n");
    printf("2. 存款\n");
    printf("3. 提款\n");
    printf("0. 離開系統\n");
    printf("請選擇功能 (0-3): ");
    scanf("%d", &choice);
    switch (choice) {
    case 1:
      printf("您的帳戶餘額是:%d元\n", balance);
      break;

    case 2:
      printf("請輸入存款金額:");
      scanf("%d",&amount);
      if(amount > 0){
        balance += amount;
        printf("存款成功!目前餘額:%d元\n",balance);
      }else{
        printf("存款金額必需大於0!\n");
      }
      break;

    case 3:
      printf("請輸入提款金額:");
      scanf("%d",&amount);
      if(amount > 0 && amount <= balance){
        balance -= amount;
        printf("提款成功!目前餘額:%d元\n",balance);
      }else if (amount > balance){
        printf("餘額不足!目前餘額:%d元\n",balance);
      }else{
        printf("提款金額金額必須大於0!\n");
      }
      break;

    case 0:
      printf("感謝使用ATM系統,再見!\n");
      break;

    default:
      printf("無效的選擇,請重新輸入!\n");
    }
  } while (choice != 0);
  printf("離開ATM系統\n");
  return 0;
}
