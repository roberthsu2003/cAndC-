#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//建立隨機數

int main(void) {
  // printf("1970至現在的秒數是:%ld",time(NULL));
  srandom(time(NULL));
  int random_num = random() % 10;
  printf("隨機數:%d\n", random_num + 1); //1~10的隨機數
  return 0;
}
