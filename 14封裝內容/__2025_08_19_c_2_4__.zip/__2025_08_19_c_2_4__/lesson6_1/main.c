#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//建立隨機數

int main(void) {
  // printf("1970至現在的秒數是:%ld",time(NULL));
  srandom(time(NULL));
  int min = 1;
  int max = 99;
  int guess;
  int attempts = 0;
  int target = random() % (max - min + 1) + min;
  // printf("隨機數:%d\n", random_num);
  printf("我已經想好一個%d到%d之間的數字\n", min, max);
  printf("========猜數字遊戲開始=======\n");
  while (true) {
    printf("\n請輸入%d到%d之間的數字:", min, max);
    scanf("%d", &guess);
    attempts++;

    if (guess < min || guess > max) {
      printf("超出範圍!請輸入%d到%d之間的數字\n", min, max);
      attempts--;
      continue;
    }

    if (guess == target) {
      printf("🎖️ 恭喜！猜對了！答案就是%d\n",target);
      printf("您總共猜了%d次\n",attempts);

      if(attempts <=3){
        printf("太厲害了！您是猜數字高手！\n");
      }else if(attempts <= 7){
        printf("不錯的表現！\n");
      }else{
        printf("多多練習就會進步!\n");
      }
      break;

    } else if (guess > target) {
      printf("太大了!再小一點\n");
      max = guess - 1;
    } else if (guess < target) {
      printf("太小了!再大一點\n");
      min = guess + 1;
    }
    printf("您已經猜了%d次\n", attempts);
    printf("提示:答案在%d到%d之間\n", min, max);
  }
  printf("遊戲結束\n");
  return 0;
}
