#include <stdio.h>
//建立陣列變數
int main(void) {
  int numbers[3];
  numbers[0] = 96;
  numbers[1] = 101;
  numbers[2] = 202;

  printf("numbers[0]=%d\n", numbers[0]);
  printf("numbers[1]=%d\n", numbers[1]);
  printf("numbers[2]=%d\n", numbers[2]);
  return 0;
}
