#include <stdio.h>
//建立陣列變數
int main(void) {
  int numbers[3];
  numbers[0] = 96;
  numbers[1] = 101;
  numbers[2] = 202;

  //利用for迴圈的重覆執行,取出所有陣列的元素;
  for (int i = 0; i < 3; i++) {
    printf("numbers[%d]=%d\n", i, numbers[i]);
  }
  return 0;
}
