#include <stdio.h>
//建立陣列變數
int main(void) {
  //配置記憶體的當下,同時給值
  // int numbers[3] = {96,101,202};

  //配置記憶體
  int numbers[3];
  for (int i = 0; i < 3; i++) {
    printf("請輸入第%d個值:", i + 1);
    scanf("%d", &numbers[i]);
  }

  //利用for迴圈的重覆執行,取出所有陣列的元素;
  for (int i = 0; i < 3; i++) {
    printf("numbers[%d]=%d\n", i, numbers[i]);
  }
  return 0;
}
