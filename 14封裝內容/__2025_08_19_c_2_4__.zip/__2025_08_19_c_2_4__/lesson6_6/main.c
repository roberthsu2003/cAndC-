#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//建立一個學生的5個分數
//使用隨機數

int main(void) {
  srandom(time(NULL));
  int min = 50;
  int max = 100;
  int n = 5;
  int scores[n];

  for (int i = 0; i < n; i++) {
    scores[i] = random() % (max - min + 1) + min;
  }

  printf("學生分數是:");
  for (int i = 0; i < n; i++) {
    printf("%d ", scores[i]);
  }
  printf("\n");
  return 0;
}
