#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//建立50個學生
//建立一個學生的5個分數
//使用隨機數
//使用2維陣列

int main(void) {
  srandom(time(NULL));
  int min = 50;
  int max = 100;
  int n = 5;
  int scores[50][n];
  for (int j = 0; j < 50; j++) {
    for (int i = 0; i < n; i++) {
      scores[j][i] = random() % (max - min + 1) + min;
    }
  }

  for (int j = 0; j < 50; j++) {
    printf("第%d學生分數是:", j + 1);
    for (int i = 0; i < n; i++) {
      printf("%d ", scores[j][i]);
    }
    printf("\n");
  }

  return 0;
}
