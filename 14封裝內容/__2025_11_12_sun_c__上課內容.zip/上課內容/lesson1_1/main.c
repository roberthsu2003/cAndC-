#include <stdio.h>

int main(void) {
  printf("Hello World\n");
  printf("這是c語言的第1個範例\n");
  printf("這是c語言的第2個範例");
  return 0;
}
