#include <stdio.h>

int main(void) {
  printf("這是一個整數:%d\n",5);
  printf("請是一個double數值:%.2lf\n",5.0);
  printf("5 * 119=%d\n",5 * 119);
  return 0;
}
