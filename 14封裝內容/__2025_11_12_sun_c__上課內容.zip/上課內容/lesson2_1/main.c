#include <stdio.h>

int main(void) {
  printf("Hello World\n");
  printf("這是一個整數值:%d\n",450);
  printf("請是一個雙精準浮點數:%.2lf\n",3.1465926);
  printf("567 * 789 = %d\n",567 * 789);
  printf("567 * 78.9 = %lf\n", 567 * 78.9); //自動轉換
  printf("5 / 3 = %d\n",5 / 3);
  printf("5 / 3 = %.2lf\n", 5 / 3.0); //自動轉換
  printf("5 / 3 = %.2lf\n", (double)5 / 3); //手動轉換
  printf("5 / 3 = %.2lf\n", 5 / (double)3); //手動轉換
  printf("5 / 3 = %.2lf\n", (double)5 / (double)3); //手動轉換
  return 0;
}
