#include <stdio.h>

int main(void) {
  printf("%d - %d = %d\n", 5, 3, 5-3);
  printf("%d + %d = %d\n", 5, 3, 5+3);
  printf("%d * %d = %d\n", 5, 3, 5*3);
  printf("%d / %d = %.2lf\n", 5, 3, 5 / 3.0); //自動轉換
  printf("%d / %d = %.2lf\n", 5, 3, (double)5 / 3); //自動轉換
  return 0;
}
