#include <stdio.h>

int main(void) {
  //矩形面積的運算
  double width;  //建立變數同時給值
  double height; //建立變數同時給值
  printf("請輸入矩形的寬:");
  scanf("%lf",&width);
  printf("請輸入矩形的高:");
  scanf("%lf",&height);
  
  double area = width * height;

  printf("寬=%.1lf,高=%.1lf,計算面積是?\n", width, height);
  printf("%.1lf * %.1lf = %.2lf\n", width, height, area);

  return 0;
}
