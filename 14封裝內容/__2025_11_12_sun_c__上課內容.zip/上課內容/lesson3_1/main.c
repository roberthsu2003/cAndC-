#include <stdio.h>
// 單行註解
/*----------計算梯形面積--------
求梯型面積(上底+下底) * 高 / 2
建立變數上底->top
建立變數下底->bottom
建立變數高->height
--------------------*/

int main(void) {
  int top,bottom,height;
  double area;
  printf("計算梯形面積\n");
  printf("請輸入上底:");
  scanf("%d",&top);
  printf("請輸入下底:");
  scanf("%d",&bottom);
  printf("請輸入高:");
  scanf("%d",&height);
  printf("上底:%d,下底:%d,高:%d\n",top,bottom,height);
  //area = (top + bottom) * height / 2.0; //2.0
  area = (top + bottom) * (double)height / 2;
  printf("梯形面積是%.2lf\n",area);
  return 0;
}
