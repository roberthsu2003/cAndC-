#include <stdio.h>

int main(void) {
  char chrA = 'A';
  char chrA1 = 65;
  printf("字元A:%d\n", chrA);
  printf("字元A1:%c\n", chrA1);

  unsigned char uchrA = 200;
  printf("uchrA:%u\n", uchrA);

  long long myLong = 9223372036854;
  printf("myLong:%lld\n", myLong);
  return 0;
}
