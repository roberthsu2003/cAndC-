#include <math.h>
#include <stdio.h>

/*------------
使用畢氏定理求出斜邊長度
a=>對邊
b=>鄰邊
c=>斜邊
-------------*/

int main(void) {
  double a, b, c;
  printf("請輸入對邊:");
  scanf("%lf", &a);
  printf("請輸入鄰邊:");
  scanf("%lf", &b);
  c = sqrt(pow(a, 2) + pow(b, 2));
  printf("對邊:%.2lf,鄰邊:%.2lf,斜邊是%.2lf\n", a, b, c);
  return 0;
}
