#include <stdio.h>

int main(void) {
  int i = 1;
  i++; //直接將i的內容+1
  --i; //直接將i的內容-1
  printf("i=%d",i);
  return 0;
}
