#include <stdio.h>

int main(void) {
  int n = 0;
  n += 10; //複合指定運算子
  n *= 10; //複合指定運算子
  //n++;
  n += 1;
  //--n;
  n -= 1;
  printf("n=%d\n", n);
  return 0;
}
