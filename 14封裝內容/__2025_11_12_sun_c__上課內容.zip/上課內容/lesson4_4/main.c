#include <stdio.h>
//比較運算子

int main(void) {
  int m=5, n=5;
  printf("(5==5)>%d\n(5!=5)>%d\n",m==n,m!=n);
  printf("============================\n");
  //讓使用者輸入三個任意數，程式會顯示三數中的最大數。
  float in1, in2, in3, max;
  printf("請輸入第一個數:");
  scanf("%f",&in1);
  printf("請輸入第二個數:");
  scanf("%f",&in2);
  printf("請輸入第三個數:");
  scanf("%f",&in3);

  max = in1 > in2 ? in1 : in2;

  max = max > in3 ? max : in3;

  printf("最大的數為%.2f\n",max);
  return 0;
}
