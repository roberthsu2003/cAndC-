#include <stdio.h>

int main(void) {
  int age;
  printf("請輸入您的age:");
  scanf("%d",&age);
  if (age >= 18){
    printf("您有投票權\n");
  }else{
    printf("您沒有投票權\n");
  }
  return 0;
}
