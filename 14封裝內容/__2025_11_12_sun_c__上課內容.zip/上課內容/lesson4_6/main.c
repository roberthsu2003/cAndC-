#include <stdio.h>

/*--------------------
學生總分為300分
學生如果符合條件,可以加5% ==>第1個條件
如果加分後,分數超過300,以300分計算 ===第2個條件
如果使用者,輸入的分數,大於300分,顯示輸入分數錯誤
---------------------*/

int main(void) {
  int score;
  int hasBonus;
  
  printf("請輸入學生分數:");
  scanf("%d",&score);  

  if (score > 300){
    printf("輸入錯誤,請重新輸入.\n");
  }else{
    printf("學生符合加分條件嗎?(1=是, 0=否):");
    scanf("%d", &hasBonus);
    
    if(hasBonus == 1){ //單項選擇
      score *= 1.05;
      if(score > 300){ //巢狀判斷
        score = 300;
      }
    }
    printf("學生最終分數是:%d\n", score);
  }
  return 0;
}
