#include <stdio.h>

int main(void) {
  int score;
  printf("請輸入學生分數(0~100):");
  scanf("%d", &score);
  if (score >= 80) { //多項選擇
    printf("優\n");
  } else if (score >= 60) {
    printf("及格\n");
  } else {
    printf("不及格\n");
  }
  return 0;
}
