#include <stdio.h>

int main(void) {
  int score;
  printf("請輸入學生分數(0~100):");
  scanf("%d", &score);
  if(score<60){
    printf("不及格(丁)\n");
  }else if(score<70){
    printf("丙\n");
  }else if(score<80){
    printf("乙\n");
  }else if(score<90){
    printf("甲\n");
  }else{
    printf("優\n");
  }
  return 0;
}
