#include <stdio.h>
//購物折扣計算

int main(void) {
  int purchaseAmount;
  int finalAmount;
  
  printf("請輸入購買金額:");
  scanf("%d",&purchaseAmount);

  if(purchaseAmount >= 100000){
    finalAmount = purchaseAmount * 0.8;
  }else if(purchaseAmount >= 50000){
    finalAmount = purchaseAmount * 0.85;
  }else if (purchaseAmount >= 30000){
    finalAmount = purchaseAmount * 0.9;
  }else if (purchaseAmount >= 10000){
    finalAmount = purchaseAmount * 0.95;
  }else{
    finalAmount = purchaseAmount;
  }

  printf("實付金額是:%d元\n", finalAmount);

  
  
  return 0;
}
