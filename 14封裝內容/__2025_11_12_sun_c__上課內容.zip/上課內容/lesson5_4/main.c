#include <stdio.h>
//獎金計算（巢狀方式）


int main(void) {
  int chinese,math;
  int bonus=0;
  printf("請輸入國文成績和數學成績 (國文,數學):");
  scanf("%d,%d",&chinese,&math);
  printf("國文分數是:%d,數學分數是:%d\n",chinese,math);

  if(chinese==100){
    //chinese是100
    if(math == 100){
      //math是100
      bonus = 1000;
    }else{
      //math不是100
      bonus = 500;
    }
  }else if(math == 100){
    //chinese不是100    
    //math是100
    bonus = 500;
    
  }

  printf("獎金是:%d元\n", bonus);
  
  return 0;
}
