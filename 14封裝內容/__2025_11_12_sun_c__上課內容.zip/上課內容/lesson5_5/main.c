#include <stdio.h>
//邏輯運算子

int main(void) {
  int chinese,math;
  int bonus=0;
  printf("請輸入國文成績和數學成績 (國文,數學):");
  scanf("%d,%d",&chinese,&math);
  printf("國文分數是:%d,數學分數是:%d\n",chinese,math);

  if(chinese==100 && math==100){
    bonus = 1000;
  }else if(chinese==100 || math==100){
    //2科沒有同時100  
    bonus = 500;
  }
  printf("獎金是:%d元\n", bonus);
  return 0;
}
