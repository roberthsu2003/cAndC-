#include <stdio.h>

int main(void) {
  int score=70;
  if(!(score>=60)){
    printf("不及格");
  }else{
    printf("及格");    
  }
  return 0;
}
