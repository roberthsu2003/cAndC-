#include <stdio.h>
//季節判斷

int main(void) {
  int season;
  printf("請輸入現在是第幾季 (1-4):");
  scanf("%d",&season);

  switch(season){
    case 1:
    printf("現在是春天!\n");
    break;

    case 2:
    printf("現在是夏天!\n");
    break;

    case 3:
    printf("現在是秋天!\n");
    break;

    case 4:
    printf("現在是冬天!\n");
    break;

    default:
    printf("無效的季節代碼！\n");
  }
  return 0;
}
