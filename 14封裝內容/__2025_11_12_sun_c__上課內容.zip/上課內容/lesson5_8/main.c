#include <stdio.h>
// 1~10的加總
int main(void) {
  int end, total = 0;
  printf("請輸入1~多少的數值:");
  scanf("%d", &end);

  for (int i = 1; i <= end; i++) { // for迴圈
    total += i;
  }

  printf("1~%d的加總是:%d\n", end, total);
  return 0;
}
