#include <stdio.h>

//學習在迴圈中處理使用者輸入，計算一週支出

int main(void) {
  int expense,sum=0;
  printf("請輸入一週七天的支出：\n");
  
  for(int day=1; day<=7; day++){
    printf("請輸入第%d天的支出:",day);
    scanf("%d",&expense);
    sum += expense;
  }

  printf("本週的總支出為:%d元\n",sum);
  printf("平均繁日支出為:%d元\n", sum/7);
  return 0;
}
