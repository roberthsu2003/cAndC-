#include <stdio.h>

int main(void) {
  int target=30000; //目標
  int total = 0;   //總存款
  int deposit;  //每月存款
  int month = 0; //月份
  printf("目標:存到%d元買新手機!\n",target);
  
  while(total < target){
    month++;
    printf("請輸入第%d個份的存款:",month);
    scanf("%d",&deposit);
    total += deposit; //改變total的值
  }
  printf("恭喜！已經存夠了！\n");
  printf("總共存了%d個月,總存款為:%d\n",month,total);
  return 0;
}
