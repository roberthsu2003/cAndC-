#include <stdio.h>

int main(void) {
  int score;
  printf("請輸入1個0~100之間的成績:\n");
  while(1){    
    printf("請輸入成績:");
    scanf("%d", &score);
    if(score >=0 && score <=100){
      break;
    }else{
      printf("輸入錯誤！成績必須在 0-100 之間，請重新輸入。\n");
    }
  }

  printf("您輸入的成績是:%d分\n", score);
  if(score >= 60){
    printf("及格\n");
  }else{
    printf("需要加油!\n");
  }
  
  return 0;
}
