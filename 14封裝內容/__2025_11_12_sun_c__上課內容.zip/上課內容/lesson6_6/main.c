#include <stdio.h>
//陣列
int main(void) {
  int arr[3];
  arr[0] = 10;
  arr[1] = 20;
  arr[2] = 30;
  printf("索引編號0的值是:%d\n", arr[0]);
  printf("索引編號1的值是:%d\n", arr[1]);
  printf("索引編號2的值是:%d\n", arr[2]);
  return 0;
}
