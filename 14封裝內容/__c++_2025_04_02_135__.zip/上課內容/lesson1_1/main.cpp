#include <iostream>
int i = 10;

int main() {
  //在c++內可以使用所有c語言的語法
  printf("i=%d\n", i);
  
}
