#include <iostream>

using namespace std;

int main() { 
  int scores[4]; //建立陣列變數
  scores[0] = 10;
  printf("index0:%d\n",scores[0]); //c語言的輸出
  cout << "index0:" << scores[0] << endl; //c++的輸出

  //c++的輸入,輸出
  cout << "請輸入索引1的值:";
  cin >> scores[1];
  cout << "index1:" << scores[1] << endl; //c++的輸出
}
