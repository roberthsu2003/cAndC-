#include <iostream>
using namespace std;
int main() { 
  int scores[5];
  int sum = 0;
  for(int index=0; index<5; index++){
    cout << "請輸入第" << index+1 << "科分數:";
    cin >> scores[index];
    sum += scores[index];
  }
  for(int index=0; index<5; index++){
    cout << "第" << index+1 << "科分數:" << scores[index] << endl; 
  }
  cout << "總分:" << sum << endl;
  //cout << "平均:" << sum / 5.0 << endl;
  printf("平均:%.2lf\n", sum/5.0);
}
