#include <iostream>

using namespace std;

int main() {
  srandom(time(NULL));
  int n = 100;
  int numbers[n];
  for(int i=0; i<n; i++){
    numbers[i] = random() % 10 + 1;
  }
  cout << "總共有" << n << "元素" << endl;
  //執行搜尋的動作,元素是1~10的總數量是
  for(int value = 1; value<=10; value++){
    int count = 0;
    for(int i=0; i<n; i++){    
      if(numbers[i] == value){
        count += 1;
      }
    }
    cout << value << "出現" << count << endl;
  }
  cout << "=====================" << endl;
  //執行搜尋的動作,元素是1~10的第1次出現的索引編號
  for(int value = 1; value<=10; value++){
    int index = 0;
    for(int i=0; i<n; i++){    
      if(numbers[i] == value){
        index = i;
        break;
      }
    }
    cout << value << "第1次出現的索引編號是" << index << endl;
  }
  

  
}
