#include <iostream>
using namespace std;

//泡沫排序法
int main() {
  int min = 1;
  int max = 100;
  int nums = 4;
  int array[nums];
  // srandom(time(NULL));
  srandom(5678);
  for (int i = 0; i < nums; i++) {
    array[i] = random() % (max - min + 1) + min;
  }
  cout << "排序前:" << endl;
  for (int i = 0; i < nums; i++) {
    cout << array[i] << " ";
  }
  cout << endl;

  //由大到小排序
  for (int i = 0; i < nums - 1; i++) {
    // cout << "前面的: " << i << " 後面的:";
    for (int j = i + 1; j < nums; j++) {
      // cout << j << " ";
      if (array[i] < array[j]) {
        // 2數對調
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }
    }
    // cout << endl;
  }

  cout << "大至小排序後:" << endl;
  for (int i = 0; i < nums; i++) {
    cout << array[i] << " ";
  }
  cout << endl;

  //由小到大排序
  for (int i = 0; i < nums - 1; i++) {
    // cout << "前面的: " << i << " 後面的:";
    for (int j = i + 1; j < nums; j++) {
      // cout << j << " ";
      if (array[i] > array[j]) {
        // 2數對調
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }
    }
    // cout << endl;
  }

  cout << "小至大排序後:" << endl;
  for (int i = 0; i < nums; i++) {
    cout << array[i] << " ";
  }
  cout << endl;
}
