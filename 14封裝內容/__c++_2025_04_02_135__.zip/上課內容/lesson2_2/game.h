#include <iostream>
using namespace std;
//定義play_game()的function
void play_game(){
  int min = 1;
  int max = 99;
  int guess = random() % (max-min+1) + min;
  int keyin;
  int count = 0;
  printf("要猜的數字是:%d\n",guess);
  printf("=========猜數字遊戲============\n\n");
  while(1){
    printf("猜數字範圍%d~%d:",min,max);
    cin >> keyin;
    count += 1;
    if(keyin>=min && keyin<=max){
      if(keyin == guess){
        printf("賓果!猜對了!答案是:%d\n",guess);
        printf("您猜了%d次\n",count);
        break;
      }else if(keyin > guess){
        printf("再小一點\n");
        max = keyin - 1;
      }else if(keyin < guess){
        printf("再大一點\n");
        min = keyin + 1;
      }
      printf("您已經猜了%d次\n",count);
    }else{
      printf("請輸入提示範圍內的數字!\n");
    }
  }
}
