#include <iostream>
#include "game.h"

using namespace std;

int main() {
  bool play_again;
  srandom(time(NULL));
  while(true){
    play_game(); //呼叫function
    cout << "請問還要繼續嗎(yes:1, no:0)?";
    cin >> play_again;
    if(play_again == false){
      break;
    }
  }
  printf("猜數字遊戲結束!");
}
