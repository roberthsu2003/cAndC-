#include <iostream>
using namespace std;

//攝氏轉華氏的funciton
double temperature(int value){
  return value * 1.8 + 32;
}

int main() {
  int celsius;
  double result;
  cout << "請輸入攝氏溫度:";
  cin >> celsius;
  result = temperature(celsius); //呼叫function
  cout << "攝氏:" << celsius << endl;
  cout << "華氏:" << result << endl;
}
