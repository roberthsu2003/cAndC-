#include <iostream>
using namespace std;
//使用for迴圈解決n!(階層問題)
int main() {
  int n;
  double total=1;
  cout << "請輸入1個數字(小於100大於0):";
  cin >> n;
  for(int x=n; x>=1; x--){
    total *= x;    
  }
  cout << total << endl;
  
}
