#include <iostream>
using namespace std;

//使用遞迴(recursive)解決n!(階層問題)
double factorial(int n){
  if(n==1){
    return 1;
  }else{
    return n * factorial(n-1);
  }
}

int main() {
  int n;
  double total=1;
  cout << "請輸入1個數字(小於100大於0):";
  cin >> n;
  total = factorial(n);
  cout << total << endl;

}
