#include <iostream>
using namespace std;
int main() {
  //建立一般變數
  int n = 10;
  cout << "n的值:" << n << endl;
  cout << "n的記憶體位址是" << &n << endl;

  //建立指標變數
  int *ptr_n;
  ptr_n = &n;
  cout << "ptr_n指標變數儲存的記憶體位址:" << ptr_n << endl;
}
