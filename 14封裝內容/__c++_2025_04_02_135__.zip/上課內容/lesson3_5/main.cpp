#include <iostream>
using namespace std;

int main() { 
  int *ptr_n = new int(10); //建立指標變數
  cout << ptr_n << endl;
  cout << *ptr_n << endl; //使用取值運算子取得值
  *ptr_n = 100; //使用取值運算子給值
   cout << *ptr_n << endl;
}
