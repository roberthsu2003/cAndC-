#include <iostream>
using namespace std;

void swap_value(int *ptr_n, int *ptr_m){
  int temp = *ptr_n;
  *ptr_n = *ptr_m;
  *ptr_m = temp;
}

int main() { 
  int n = 666;
  int m = 888;
  cout << "2數對調前:" << endl;
  cout << "n=" << n << endl;
  cout << "m=" << m << "\n\n";
  swap_value(&n,&m);
  cout << "2數對調後:" << endl;
  cout << "n=" << n << endl;
  cout << "m=" << m << "\n\n";
}
