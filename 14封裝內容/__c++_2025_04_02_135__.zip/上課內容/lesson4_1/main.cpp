#include <iostream>
using namespace std;

int main() {
  int array[3] = {10, 20, 30};
  int *array_ptr = array;
  cout << array << endl;
  cout << &array[0] << endl;
  cout << &array[1] << endl;
  cout << &array[2] << endl;
  cout << "============" << endl;
  cout << (array+0) << endl;
  cout << (array+1) << endl;
  cout << (array+2) << endl;
  cout << "============" << endl;
  cout << *(array+0) << endl;
  cout << *(array+1) << endl;
  cout << *(array+2) << endl;
  cout << "=========" << endl;
  cout << array_ptr[0] << endl;
  cout << array_ptr[1] << endl;
  cout << array_ptr[2] << endl;
  
}
