#include <iostream>
using namespace std;

void multiply10(int *ptr_array, int n){
  for(int i=0; i<n; i++){
    ptr_array[i] *= 10;
  }
}

int main() { 
  int array[] = {10, 20, 30};
  int nums = sizeof(array) / sizeof(array[0]);
  cout << "元素數量" << nums << endl;
  multiply10(array,nums);
  for(int i=0; i<nums; i++){
    cout << array[i] << endl;
  }
}
