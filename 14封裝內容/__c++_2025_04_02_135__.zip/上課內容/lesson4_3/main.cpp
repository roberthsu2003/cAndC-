#include <iostream>
using namespace std;

typedef struct rectangle{
  double width;
  double height;
}Rectangle;

int main() { 
  Rectangle rec1;
  rec1.width = 12.5;
  rec1.height = 19.7;
  cout << "rec1的面積是" << rec1.width * rec1.height << endl;

  Rectangle rec2 = {32.5, 29.8};
  cout << "rec2的面積是" << rec2.width * rec2.height << endl;

  //建立3個元素,每個元素是Rectangle的實體
  Rectangle recs[3];
  recs[0].width = 45.7;
  recs[0].height = 32.9;
  
  recs[1].width = 35.9;
  recs[1].height = 21.2;
  
  recs[2].width = 65.3;
  recs[2].height = 92.5;

  for(int i=0; i<3; i++){
    cout << "第" << i << "元素 面積是";
    cout << recs[i].width * recs[i].height << endl;
  }
  
}
