#include <iostream>
using namespace std;

typedef struct student {
  string id;
  int chinese;
  int math;
  int english;
} Student;

void configure_value(Student *s, int n) {
  //配置值
  for (int i = 0; i < n; i++) {
    s[i].id = "student" + to_string(i + 1);
    s[i].chinese = random() % (100 - 50 + 1) + 50;
    s[i].english = random() % (100 - 50 + 1) + 50;
    s[i].math = random() % (100 - 50 + 1) + 50;
  }
}

void sorted(Student *s, int n){
  //由大到小的排序
  for(int i=0; i < n-1; i++){
    for(int j=i+1; j < n; j++){
      int first = s[i].chinese + s[i].english + s[i].math;
      int second = s[j].chinese + s[j].english + s[j].math;
      if (first < second){
        Student temp = s[i];
        s[i] = s[j];
        s[j] = temp;
      }
    }
  }

}
