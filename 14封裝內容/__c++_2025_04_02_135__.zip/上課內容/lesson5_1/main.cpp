#include <iostream>
using namespace std;
//定義4個常數
/**
const int NORTH = 1;
const int SOUTH = 2;
const int EAST = 3;
const int WESE = 4;
**/

//列舉
typedef enum direction { NORTH = 1, SOUTH, EAST, WEST } Direction;

int main() {
  Direction point = WEST;

  //檢查列舉變數內儲存的值
  // switch
  switch (point) {
  case NORTH:
    cout << "北" << endl;
    break;

  case SOUTH:
    cout << "南" << endl;
    break;

  case EAST:
    cout << "東" << endl;
    break;

  case WEST:
    cout << "西" << endl;
    break;

  default:
    cout << "?" << endl;
  }
}
