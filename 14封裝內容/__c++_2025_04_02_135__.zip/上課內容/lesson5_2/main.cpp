#include <iostream>
//marco,巨集
#define RATE 32.78

using namespace std;

int main() { 
  double us,nt;
  cout << "請輸入您有多少美金:";
  cin >> us;
  nt = us * RATE;
  cout << "您可以換成" << nt << "台幣" << endl;
}
