#include <iostream>

#define MAC

#ifndef MAC

int main() { 
  std::cout << "我是windows"; 
}

#else

int main() { 
  std::cout << "我是mac"; 
}

#endif
