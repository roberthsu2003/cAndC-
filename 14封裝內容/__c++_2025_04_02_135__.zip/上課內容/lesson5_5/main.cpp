#include <iostream>
#include "tools.h"
#include "tools.h"

using namespace std;


int main() {
  int nums = 50;
  Student students[nums];
  configure_value(students, nums);
  sorted(students,nums);
  cout << "前5名是:" << endl;
  for (int i = 0; i < 5; i++) {
    cout << "第" << i+1 << "名:";
    cout << students[i].id << endl;
    cout << "總分:" << students[i].chinese + students[i].english + students[i].math << "\n\n";

  }
}
