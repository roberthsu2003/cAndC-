#include <iostream>
#include "person.h"
using namespace std;



int main() { 
  Person p1;
  p1.name = "robert";
  p1.height = 178;
  p1.weight = 74;

  cout << p1.name << endl;
  cout << p1.height << endl;
  cout << p1.weight << endl;
  cout << p1.bmi() << endl;
  cout << p1.status() << endl;

  cout << "===========" << endl;
  
  Person p2;
  p2.name = "David";
  p2.height = 183;
  p2.weight = 81;
  cout << p2.name << endl;
  cout << p2.height << endl;
  cout << p2.weight << endl;
  cout << p2.bmi() << endl;
  cout << p2.status() << endl;
}
