#include "person.h"
#include <iostream>
using namespace std;

//實體方法實作移至class的外部
double Person::bmi(void) {
  return weight / ((height / 100.0) * (height / 100.0));
}

string Person::status(void){
  double value = bmi();
  if(value < 18.5){
    return "體重過輕";
  }else if (value < 24){
    return "正常範圍";
  }else{
    return "異常範圍";
  }
}
