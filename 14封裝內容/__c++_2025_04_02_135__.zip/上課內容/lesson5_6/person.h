#ifndef __PERSON_H__
#define __PERSON_H__

#include <iostream>
using namespace std;

class Person {
public:
  // field
  string name;
  int height;
  int weight;
  // method()
  double bmi(void);
  string status(void);
};


#endif
