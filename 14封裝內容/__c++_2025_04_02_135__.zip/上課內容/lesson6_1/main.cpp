#include <iostream>
using namespace std;

class Student {
public:
  //欄位
  string name;
  int chinese;
  int math;
  int english;
  //自訂的建構式
  Student(string n, int ch, int ma, int eng);
};

Student::Student(string n, int ch, int ma, int eng) {
  name = n;
  chinese = ch;
  math = ma;
  english = eng;
}

//建立function,列印學生的資料
void print_student(Student stu){ //call by value
  cout << "name:" << stu.name << endl;
  cout << "國文:" << stu.chinese << endl;
  cout << "英文:" << stu.english << endl;
  cout << "數學:" << stu.math << endl;
  stu.math = 100;
}

int main() {
  Student stu1("Robert", 87, 92, 67);
  print_student(stu1);
  cout << "更改分數後" << endl;
  cout << stu1.math << endl;
}
