#include <iostream>
using namespace std;

void swap_value(int &x, int &y){ //call by refernece
  int temp = x;
  x = y;
  y = temp;
}

int main() { 
  int n = 666;
  int m = 888;
  swap_value(n, m);

  cout << "n=" << n << endl;
  cout << "m=" << m << endl;
  
}
