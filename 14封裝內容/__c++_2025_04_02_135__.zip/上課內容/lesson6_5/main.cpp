#include <iostream>
#include <vector>
using namespace std;

int main() { 
  vector<int> vec_a;
  vector<int> vec_b(10);
  vector<int> vec_c(10, 8);
  vector<int> vec_d{10, 20, 30, 40, 50};
  cout << vec_d[0] << endl;
  cout << vec_d[1] << endl;
  cout << vec_d[2] << endl;
  cout << vec_d[3] << endl;
  cout << vec_d[4] << endl;
  
}
