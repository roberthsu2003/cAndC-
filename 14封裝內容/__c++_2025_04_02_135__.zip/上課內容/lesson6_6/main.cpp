#include <iostream>
#include <vector>

using namespace std;

int main() {
  //vector有內建的實體方法,push_back(),pop_back(),size()
  vector<int> list;
  list.push_back(10);
  list.push_back(20);
  list.push_back(30);
  list.push_back(40);
  list.push_back(50);
  list.pop_back();
  list.pop_back();
  /*
  for(int i=0; i<list.size(); i++){
    cout << list[i] << endl;
  }
  */
  for(int element:list){
    cout << element << endl;    
  }
  
}
