#include <iostream>
#include "student.h"

int main() { 
  Student stu1("Robert", 87, 92, 67);
  Student stu2("Alan",89,98,68);
  cout << stu1.name << "的總分是:" << stu1.sum();
  cout << ",平均是" << stu1.average() << endl;
  
  cout << stu2.name << "的總分是:" << stu2.sum();
  cout << ",平均是" << stu2.average() << endl;
  
}
