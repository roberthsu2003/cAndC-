#include "student.h"

Student::Student(string name, int chinese, int math, int english) {
  this->name = name;
  this->chinese = chinese;
  this->math = math;
  this->english = english;
}

int Student::sum(){
  return chinese + english + math;
}

double Student::average(){
  return sum() / 3.0;
}
