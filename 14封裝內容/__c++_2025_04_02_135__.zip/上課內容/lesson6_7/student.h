#ifndef __STUDENT_H__
#define __STUDENT_H__

#include <iostream>
using namespace std;

class Student {
public:
  //欄位
  string name;
  int chinese;
  int math;
  int english;
  //自訂的建構式
  Student(string name, int chinese, int math, int english);
  //自訂實體方法
  int sum();
  double average();
};

#endif
