#include <iostream>
#include <vector>
#include "student.h"

using namespace std;

int main() { 
  vector<Student> students;
  students.push_back(Student("Robert", 78, 92, 65));
  students.push_back(Student("Alan",89, 92, 79));

  for(Student item:students){
    cout << item.name << "總分是:" << item.sum();
    cout << ",平均是:" << item.average() << endl;
  }
}
