#include <stdio.h>

int main(void) {
  printf("這是c語言的第一堂課\n");
  printf("我們正在學習輸出的技巧!\n");
  return 0;
}
