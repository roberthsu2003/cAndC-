#include <stdio.h>

int main(void) {
  printf("這是整數%d\n",5);
  printf("整數:%d,雙精準浮點數:%.2lf\n",10,10.0);
  printf("%d\n",5);
  printf("%.2lf\n",20.0);
  return 0;
}
