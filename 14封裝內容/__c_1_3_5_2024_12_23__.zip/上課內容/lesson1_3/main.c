#include <stdio.h>

int main(void) {
  printf("%d+%d=%d\n",156,96,156+96);//int + int
  printf("%d*%d=%d\n",156,96,156*96);// int * int
  printf("%d*%d=%.2lf\n",156,96,156.0+96.0);//double + double
  printf("%d+%d=%.2lf\n",156,96,156+96.0);// int + double,自動轉換 double+double
  printf("%d+%d=%d\n",156,96,156 + (int)96.0); // int + double,手動轉換 int + int
  return 0;
}
