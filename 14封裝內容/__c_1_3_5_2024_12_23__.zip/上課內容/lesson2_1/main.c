#include <stdio.h>

int main(void) {
  //建立變數
  int english;  //配置記憶體空間
  english = 60; //指定值
  int chinese;
  chinese = 75;
  printf("英文分數是:%d\n", english); //取出值
  printf("國文分數是:%d\n", chinese);
  return 0;
}
