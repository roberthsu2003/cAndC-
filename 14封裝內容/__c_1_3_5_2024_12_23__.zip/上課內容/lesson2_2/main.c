#include <stdio.h>

int main(void) {
  int chinese = 99;
  int english = 100;
  int math = 100;
  int sum = chinese + english + math;
  // double average = sum / 3; //錯誤的
  // double average = (double)sum / 3; //手動轉換
  double average = sum / 3.0; //自動轉換
  printf("學生總分:%d,平均:%.2lf\n", sum, average);
  printf("===========\n");

  /*=====多行註解======
  double number = 10;
  printf("%.2lf\n",number);
  int number = 10.3;
  printf("%d\n",number);
  int number = 10;
  printf("%d\n",number / 3);
  */

  return 0;
}
