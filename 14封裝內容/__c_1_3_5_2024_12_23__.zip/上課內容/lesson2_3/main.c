#include <stdio.h>

int main(void) {
  int numbers = 10.0;
  printf("numbers的值是%d\n",numbers);
  printf("numbers的記憶體位址是%p",&numbers);
  return 0;
}
