#include <stdio.h>

int main(void) {
  int chinese, english, math;
  /*
  printf("請輸入國文分數:");
  scanf("%d", &chinese);
  printf("請輸入英文分數:");
  scanf("%d", &english);
  printf("請輸入數學分數:");
  scanf("%d", &math);
  */
  printf("請輸入學生分數(國文,英文,數學):");
  scanf("%d,%d,%d",&chinese,&english,&math);
  int sum = chinese + english + math;
  printf("學生總分是:%d\n", sum);
  double average = sum / 3.0;
  printf("學生平均:%.2lf\n",average);
  return 0;
}
