#include <stdio.h>

int main(void) {
  //小學數學
  double radius;
  const double PI = 3.1415926; //常數
  printf("請輸入半徑:");
  scanf("%lf", &radius);
  printf("圓面積是%.2lf\n", PI * radius * radius);
  printf("圓周長:%.2lf\n", 2 * PI * radius);
  return 0;
}
