#include <math.h>
#include <stdio.h>

int main(void) {
  double a, b, c;
  printf("請輸入a,b:");
  scanf("%lf,%lf", &a, &b);
  c = sqrt(a * a + b * b);
  printf("c=%.2lf", c);
  return 0;
}
