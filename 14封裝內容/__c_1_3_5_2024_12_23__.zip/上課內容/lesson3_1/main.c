#include <stdio.h>

int main(void) {
  //各種型別所佔記憶體的大小
  int n;
  float f;
  double d;
  printf("%lu\n",sizeof(n));
  printf("%lu\n",sizeof(f));
  printf("%lu\n",sizeof(d));
  return 0;
}
