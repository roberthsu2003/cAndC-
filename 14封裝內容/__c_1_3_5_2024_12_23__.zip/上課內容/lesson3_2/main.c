#include <stdio.h>

int main(void) {
  char c = 'a';
  printf("%c\n", c);
  printf("%d\n", c);

  unsigned char uc = 150;
  printf("%u\n", uc);
  return 0;
}
