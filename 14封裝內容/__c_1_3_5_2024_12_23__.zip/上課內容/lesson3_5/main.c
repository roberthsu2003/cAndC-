#include <stdio.h>

int main(void) {
  int n = 10;
  n = n + 20;
  printf("n=%d\n",n);
  return 0;
}
