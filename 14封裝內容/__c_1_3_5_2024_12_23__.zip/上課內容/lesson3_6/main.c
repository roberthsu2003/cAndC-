#include <stdio.h>
//請使用(複合指定運算子)讓用者輸入三個任意數，程式會顯示3數相加的總和(float)
int main(void) {
  float input, total = 0;
  printf("請輸入第一個數:");
  scanf("%f", &input);
  total += input;

  printf("請輸入第二個數:");
  scanf("%f", &input);
  total += input;

  printf("請輸入第三個數:");
  scanf("%f", &input);
  total += input;

  printf("3數相加總合為:%.2f\n", total);
  return 0;
}
