#include <stdio.h>

int main(void) {
  int n = 1;
  int m = n++;

  printf("n=%d, m=%d\n", n, m);

  int x = 1;
  int y = ++x;
  printf("x=%d, y=%d", x, y);

  return 0;
}
