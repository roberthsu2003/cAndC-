#include <stdio.h>
//讓使用者輸入三個任意數，程式會顯示三數中的最大數。

int main(void) {
  int n1,n2,n3,max;
  printf("請輸入第1個數:");
  scanf("%d",&n1);
  printf("請輸入第2個數:");
  scanf("%d",&n2);
  max = n1 > n2 ? n1 : n2;
  printf("請輸入第3個數:");
  scanf("%d",&n3);
  max = max > n3 ? max : n3;
  printf("3數最大的值是:%d\n",max);
  return 0;
}
