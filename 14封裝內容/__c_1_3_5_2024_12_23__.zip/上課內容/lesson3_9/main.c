#include <math.h>
#include <stdio.h>

int main(void) {
  int side, another_side;
  double radian, degree;
  const double PI = 3.1415926;
  printf("請輸入對邊:");
  scanf("%d", &side);
  printf("請輸入斜邊:");
  scanf("%d", &another_side);
  radian = asin(side / (double)another_side);
  degree = radian * 180 / PI;
  printf("對邊:%d\n", side);
  printf("斜邊:%d\n", another_side);
  printf("角度:%.2lf\n", degree);
  return 0;
}
