#include <stdio.h>
//奇偶數的判斷
//雙向選擇
int main(void) {
  int number;
  printf("請輸一個整數值:");
  scanf("%d", &number);

  if (number % 2 == 0) {
    printf("%d是偶數.", number);
  } else {
    printf("%d是奇數.", number);
  }

  return 0;
}
