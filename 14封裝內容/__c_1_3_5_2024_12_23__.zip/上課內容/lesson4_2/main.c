#include <stdio.h>
//總分是300分學生符合加分條件就加5%分
//如果有加分,不可以超過300

int main(void) {
  int scores;
  unsigned char add;
  printf("請輸入學生分數:");
  scanf("%d", &scores);
  printf("學生符合加分條件嗎? yes請輸入1,no請輸入0:");
  scanf("%hhu", &add);
  //單向選擇
  if (add) {
    //加分
    scores *= 1.05;
    if (scores > 300) {
      scores = 300;
    }
  }
  printf("學生分數是:%d\n", scores);
  return 0;
}
