#include <stdio.h>

int main(void) {
  int scores;
  printf("請輸入成績(0-100):");
  scanf("%d", &scores);

  //多項選擇
  if (scores >= 90) {
    printf("優等\n");
  }else if (scores >= 80) {
    printf("甲等\n");
  }else if (scores >= 70) {
    printf("乙等\n");
  }else if(scores >= 60){        
    printf("丙等");
  }else{
    printf("不及格");      
  }
  return 0;
}
