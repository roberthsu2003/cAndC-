#include <stdio.h>
///國文100同時數學100,獎金1000
//國文100或者數學100,獎金500
//利用巢狀判斷
int main(void) {
  int chinese, math, bonus;
  printf("請輸入國文成績和數學成績(國文,數學):");
  scanf("%d,%d", &chinese, &math);
  if (chinese == 100) {
    //國文100
    if (math == 100) {
      //數學100
      bonus = 1000;
    } else {
      bonus = 500;
    }
  } else if (math == 100) {
    bonus = 500;
  } else {
    bonus = 0;
  }
  printf("獎金是:%d\n", bonus);
  return 0;
}
