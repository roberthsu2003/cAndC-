#include <stdio.h>

int main(void) {
  int year;
  printf("請輸入西元:");
  scanf("%d", &year);

  if (!((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)) {
    printf("%d年不是潤年\n", year);
  } else {
    printf("%d年是潤年\n", year);    
  }
  return 0;
}
