#include <stdio.h>
//讓使用者輸入加、減、乘、除運算子, 就會顯示運算結果

int main(void) {
  char operator;
  int num1, num2;
  printf("請輸入運算子(+,-,*,/):");
  scanf("%c",&operator);
  printf("請輸入2個數值:(num1,num2)");
  scanf("%d,%d",&num1, &num2);
  switch(operator){
    case '+':
      printf("2數相加為%d\n", num1 + num2);
      break;
    case '-':
      printf("2數相減為%d\n", num1 - num2);
      break;
    case '*':
      printf("2數相乘為%d\n", num1 * num2);
      break;
    case '/':
      printf("2數相除為%.2lf\n", num1 / (double)num2);
      break;
    default:
      printf("輸入的運算子有問題!\n");
  }
    
  
  return 0;
}
