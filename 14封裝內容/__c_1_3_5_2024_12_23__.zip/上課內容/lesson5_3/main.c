#include <stdio.h>
//1加到100的總和
int main(void) {
  int total = 0;
  //明確知道執行次數的迴圈
  for(int i=1; i < 101; i++){
    total += i;
  }
  printf("1加到100是%d\n", total);
  return 0;
}
