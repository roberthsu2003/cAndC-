#include <stdio.h>
//1加到100的總和
//1加到100的偶數總和
//1加到100的奇數總和
int main(void) {
  int total = 0;
  int odd_total = 0;
  int even_total = 0;
  //明確知道執行次數的迴圈
  for(int i=1; i < 101; i++){
    total += i;
    if(i % 2 == 0){
      even_total += i;
    }else{
      odd_total += i;
    }
  }
  printf("1加到100是%d\n", total);
  printf("1加到100的偶數是%d\n",even_total);
  printf("1加到100的奇數是%d\n",odd_total);
  return 0;
}
