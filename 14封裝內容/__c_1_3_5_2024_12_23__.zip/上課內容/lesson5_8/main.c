#include <stdio.h>
//請設計一個程式，讓使用者輸入數值，只有加總正偶數值，不加總正奇數值，如果輸入負數，結束程式。
int main(void) {
  int inputNum;
  int even_total = 0;
  int num = 0;
  while (1) {    
    printf("請輸入第%d個數值:", num+1);
    scanf("%d", &inputNum);
    if (inputNum < 0) {
      break;
    } else if (inputNum % 2 == 0) {
      even_total += inputNum;
    }
    num++;
  }

  printf("應用程式結束\n");
  printf("總共輸入的數值次數為:%d\n", num);
  printf("正偶數的總和為%d\n", even_total);
  return 0;
}
