#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  srandom(time(NULL));
  printf("亂數是:%ld\n", random());
  return 0;
}
