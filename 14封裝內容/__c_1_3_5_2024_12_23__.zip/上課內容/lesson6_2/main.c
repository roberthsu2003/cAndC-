#include <stdio.h>

int main(void) {
  int scores[5]; //建立陣列
  printf("scores配置的記憶體大小是%ld\n",sizeof(scores));
  scores[0] = 67; //設定元素值
  scores[1] = 97;
  scores[2] = 68;
  scores[3] = 75;
  scores[4] = 92;

  for(int i=0;i<5;i++){ //取出元素值
    printf("索引:%d=%d\n",i,scores[i]);
  }
  return 0;
}
