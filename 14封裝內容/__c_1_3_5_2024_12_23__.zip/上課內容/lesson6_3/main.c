#include <stdio.h>

int main(void) {
  int scores[] = {78, 68, 92, 87, 60}; //建立陣列同時給值
  printf("scores配置的記憶體大小是%ld\n",sizeof(scores));

  for(int i=0;i<5;i++){ //取出元素值
    printf("索引:%d=%d\n",i,scores[i]);
  }
  return 0;
}
