#include <stdio.h>

int main(void) {
  int scores[5];
  int total=0;
  for (int i = 0; i < 5; i++) {
    printf("請輸入第%d科的分數:", i + 1);
    scanf("%d", &scores[i]);
  }

  for (int i = 0; i < 5; i++) { //取出元素值
    printf("索引:%d=%d\n", i, scores[i]);
    total += scores[i];
  }
  printf("學生總分是:%d\n", total);
  printf("平均是%.2lf\n", total / 5.0);
  return 0;
}
