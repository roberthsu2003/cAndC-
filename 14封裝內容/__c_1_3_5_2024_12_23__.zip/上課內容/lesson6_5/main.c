#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  srandom(time(NULL));
  int num = 5;
  int scores[num];
  int total = 0;
  int min = 50;
  int max = 100;

  for (int i = 0; i < num; i++) {
    scores[i] = random() % (max-min+1) + min;
  }

  for (int i = 0; i < num; i++) { //取出元素值
    printf("第%d科:%d\n",i+1, scores[i]);
    total += scores[i];
  }
  printf("學生總分是:%d\n", total);
  printf("平均是%.2lf\n", total / (double)num);
  return 0;
}
