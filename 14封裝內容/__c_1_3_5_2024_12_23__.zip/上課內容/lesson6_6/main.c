#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  srandom(time(NULL));
  int student_num;
  int scores_num;
  printf("請輸入學生數:");
  scanf("%d", &student_num);
  printf("請輸入科目數:");
  scanf("%d", &scores_num);
  int students[student_num][scores_num];

  for (int i = 0; i < student_num; i++) {
    printf("第%d位學生\n分數:", i + 1);
    int total = 0;
    for (int j = 0; j < scores_num; j++) {
      students[i][j] = random() % (100 - 50 + 1) + 50;
      total += students[i][j];
      printf("%d\t", students[i][j]);
    }
    printf("\n");
    printf("學生總分:%d:\n", total);
    printf("學生平均:%.2lf\n", total / (double)scores_num);
    printf("\n\n");
  }
  return 0;
}
