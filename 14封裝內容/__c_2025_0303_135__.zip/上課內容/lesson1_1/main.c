#include <stdio.h>

int main(void) {
  printf("這是c語言的第一節課\n");
  printf("這是個replit的編輯器\n");
  return 0;
}
