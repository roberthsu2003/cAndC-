#include <stdio.h>

int main(void) {
  printf("我有2個數值\n我有整數值%d\n我有小數點值%lf\n",10,3.14159);
  printf("===============\n");
  printf("123*456=%d\n",123*456);
  printf("56789-34567=%d\n",56789-34567);
  return 0;
}
