#include <stdio.h>

int main(void) {
  printf("1. %d\n", 10 + 10);
  printf("2. %.2lf\n", 10.0 + 10.0);
  printf("3. %.3lf\n", 10 + 10.0);
  return 0;
}
