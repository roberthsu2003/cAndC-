#include <stdio.h>

int main(void) {
  //建立n,m的變數
  int n;
  n = 78;
  int m;
  m = 100;

  printf("n=%d\n",n);
  printf("m=%d\n",m);
  return 0;
}
