#include <stdio.h>
//讓使用者輸入梯形的上底、下底及高，程式會計算梯形的面積(上底加下底乘以高除以2)
int main(void) {
  double top, bottom, height, area;
  printf("請輸梯形:(上底,下底,高)");
  scanf("%lf,%lf,%lf", &top, &bottom, &height);
  area = (top + bottom) * height / 2;
  printf("梯形的面積是:%.2lf\n", area);
  return 0;
}
