#include <stdio.h>

int main(void) {
  //建立n,m的變數
  int n = 78;
  int m = 100;

  printf("%d + %d = %d\n", n, m, n + m);
  printf("%d * %d = %d\n", n, m, n * m);
  return 0;
}
