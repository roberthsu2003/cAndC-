#include <stdio.h>

int main(void) {
  //建立n,m的變數
  int n = 78;
  int m = 100;
  int x = n + m;
  int y = n * m;

  printf("%d + %d = %d\n", n, m, x);
  printf("%d * %d = %d\n", n, m, y);
  return 0;
}
