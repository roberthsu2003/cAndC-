#include <stdio.h>

int main(void) {
  //建立n,m的變數
  int n = 78;
  int m = 100;
  double x = n + m;
  double y = n * m;

  printf("%d + %d = %.2lf\n", n, m, x);
  printf("%d * %d = %.2f\n", n, m, y);
  return 0;
}
