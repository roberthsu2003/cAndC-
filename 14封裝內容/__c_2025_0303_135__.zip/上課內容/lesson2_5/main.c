#include <stdio.h>

int main(void) {
  //建立n,m的變數
  double n = 78.6;
  double m = 92.8;
  int x = n + m; // x沒有小數點
  int y = n * m; // y沒有小數點

  //因為自動轉換,運算出現問題
  printf("%.2lf + %.2lf = %d\n", n, m, x);
  printf("%.2lf * %.2lf = %d\n", n, m, y);
  return 0;
}
