#include <stdio.h>

int main(void) {
  //建立n,m的變數
  int n = 3;
  double m = 2.5;
  int x = n * m; // x沒有小數點
  double y = n * m;
  printf("x=%d\n",x);
  printf("y=%.2lf\n",y);  
  return 0;
}
