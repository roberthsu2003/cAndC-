#include <stdio.h>

int main(void) {
  int chinese = 99;
  int english = 100;
  int math = 100;
  int total = chinese + english + math;
  //double average = (double)total / 3; //強制轉換
  double average = total / 3.0;
  printf("3科總分為%d\n", total);
  printf("平均為%.2lf\n", average);
  return 0;
}
