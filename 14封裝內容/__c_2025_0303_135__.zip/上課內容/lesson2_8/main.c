#include <stdio.h>

int main(void) {
  int chinese;
  int math;
  printf("chinese的記憶體位址是:%p\n",&chinese);
  printf("math的記憶體位址是:%p\n",&math);
  printf("請輸入國文分數:");
  scanf("%d",&chinese);
  printf("請輸入數學分數:");
  scanf("%d",&math);
  printf("國文分數是:%d\n",chinese);
  printf("數學分數是:%d\n",math);
  return 0;
}
