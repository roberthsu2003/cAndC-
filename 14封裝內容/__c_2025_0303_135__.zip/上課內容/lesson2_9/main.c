#include <stdio.h>

int main(void) {
  int chinese, math, english, total;
  double average;
  printf("請輸入分數(國文,數學,英文):");
  scanf("%d,%d,%d",&chinese,&math,&english);
  printf("國文:%d,英文:%d,數學:%d\n",chinese, english, math);
  total = chinese + english + math;
  average = (double)total / 3;
  printf("總分:%d, 平均:%.2lf\n", total, average);
  return 0;
}
