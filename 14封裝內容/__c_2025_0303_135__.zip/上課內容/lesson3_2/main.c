#include <stdio.h>

int main(void) {
  int n = 1;
  n += 10;
  n *= 10;
  printf("n=%d\n", n);
  return 0;
}
