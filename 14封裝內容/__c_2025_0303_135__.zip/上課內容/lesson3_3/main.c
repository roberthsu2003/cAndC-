#include <stdio.h>
//請以(複合指定運算子)設計程式,讓用者輸入三個任意數，程式會顯示3數相加的總和
int main(void) {
  double value,total=0;
  printf("請輸入第一個數:");
  scanf("%lf",&value);
  total += value;
  printf("請輸入第二個數:");
  scanf("%lf",&value);
  total += value;
  printf("請輸入第三個數:");
  scanf("%lf",&value);
  total += value;
  printf("3數加總的總合為:%.2f\n", total);
  return 0;
}
