#include <stdio.h>
//請使用者輸入一個任意數，程式會顯示此數的平方值及立方值

int main(void) {
  double value,result;
  printf("請輸入任意數:");
  scanf("%lf",&value);
  result = value;
  result *= value;
  printf("此數平方值是:%.2lf\n", result);
  result *= value;
  printf("此數立方值是:%.2lf\n", result);
  return 0;
}
