#include <stdio.h>
#include <math.h>
//請使用者輸入一個任意數，程式會顯示此數的平方值及立方值

int main(void) {
  double value,result;
  printf("請輸入任意數:");
  scanf("%lf",&value);
  result = pow(value,2);  
  printf("此數平方值是:%.2lf\n", result);
  result = pow(value,3);
  printf("此數立方值是:%.2lf\n", result);
  return 0;
}
