#include <math.h>
#include <stdio.h>

int main(void) {
  double side, another_side, result;
  printf("請輸入直角三角形(鄰邊,對邊):");
  scanf("%lf,%lf", &side, &another_side);
  //result = sqrt(pow(side, 2) + pow(another_side, 2));
  result = hypot(side, another_side);
  printf("斜邊為:%.lf\n", result);
  return 0;
}
