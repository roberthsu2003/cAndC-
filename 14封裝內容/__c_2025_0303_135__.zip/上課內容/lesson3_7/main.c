#include <stdio.h>

int main(void) {
  int n;
  double m;
  short s;
  char c;
  unsigned char uc;
  float f;
  long long ll;
  //整數型別
  printf("long long ll 的大小是:%lu\n",sizeof(ll));
  printf("int n的大小是:%lu\n",sizeof(n));  
  printf("short s的大小是:%lu\n",sizeof(s));
  printf("char c的大小是:%lu\n",sizeof(c));

  //unsigned
  printf("unsigned char uc的大小是:%lu\n",sizeof(uc));

  //浮點數型別
  printf("double m的大小是:%lu\n",sizeof(m));
  printf("float f的大小是:%lu\n",sizeof(f));
  
  return 0;
}
