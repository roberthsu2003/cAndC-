#include <stdio.h>

int main(void) {
  char character='A';
  //printf("character的值是:%d\n",character);
  printf("character的字元是是:%c\n",character);
  unsigned char value = 120;
  printf("value=%d\n",value);
  return 0;
}
