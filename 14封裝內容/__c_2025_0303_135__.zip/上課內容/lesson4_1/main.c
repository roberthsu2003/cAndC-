#include <stdio.h>

int main(void) {
  int n = 0;
  n++;
  printf("n=%d\n",n);
  ++n;
  printf("n=%d\n",n);

  int m = 10;
  m--;
  printf("m=%d\n",m);
  --m;
  printf("m=%d\n",m);
  return 0;
}
