#include <stdio.h>

int main(void) {
  int pressure;
  printf("請輸入血壓:");
  scanf("%d", &pressure);
  if(pressure >= 80){
    if(pressure <= 110){
      printf("正常\n");
    }else{
      printf("不正常");
    }
  }else{
    printf("不正常\n");
  }
  return 0;
}
