#include <stdio.h>

int main(void) {
  int chinese;
  printf("請輸入國文分數:");
  scanf("%d",&chinese);
  if(chinese>=60){ //雙項選擇,2程式區塊,一定只執行1個
    printf("及格\n");
  }else{
    printf("不及格\n");
  }
  return 0;
}
