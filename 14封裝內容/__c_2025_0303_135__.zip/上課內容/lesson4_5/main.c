#include <stdio.h>
//學生符合加分條件就加5%分
//總分300分
//如果加分後,分數大於300分,以300分計
int main(void) {
  int score, add;
  printf("請輸入學生分數:");
  scanf("%d", &score);
  printf("學生符合加分條件嗎? yes請輸入1,no請輸入0:");
  scanf("%d", &add);
  if (add) {
    score *= 1.05;    
  }
  
  if (score > 300) {
    score = 300;
  }
  printf("學生分數是:%d", score);
  return 0;
}
