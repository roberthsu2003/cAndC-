#include <stdio.h>

int main(void) {
  int chinese;
  printf("請輸入國文分數:");
  scanf("%d",&chinese);
  if(chinese >= 80){
    printf("優");
  }else{
    if(chinese >= 60){
      printf("及格");
    }else{
      printf("不及格");
    }
  }
  return 0;
}
