#include <stdio.h>

int main(void) {
  int chinese;
  printf("請輸入國文分數:");
  scanf("%d",&chinese);
  if(chinese >= 90){
    printf("優\n");
  }else if(chinese >= 80){
     printf("甲\n");
  }else if(chinese >= 70){
    printf("乙\n");
  }else if(chinese >= 60){
    printf("丙\n");
  }else{
    printf("丁\n");
  }
  return 0;
}
