#include <stdio.h>

int main(void) {
  int money,paymoney;
  printf ("輸入購買金額");
  scanf("%d",&money);
  if(money>=100000){
    paymoney=money*0.8;
  }else if(money>=50000){
    paymoney=money*0.85;
  }else if(money>=30000){
    paymoney=money*0.9;
  }else if(money>=10000){
    paymoney=money*0.95;
  }else{
    paymoney = money;
  }
  printf("實付金額是%d元",paymoney);

  return 0;
}
