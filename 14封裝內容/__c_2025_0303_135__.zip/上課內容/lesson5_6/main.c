#include <stdio.h>

int main(void) {
  int deposite=0;
  int value;
  int num = 0;
  while(1){
    printf("請輸入第%d月份的存款:",++num);
    scanf("%d", &value);
    deposite+=value;
    if(deposite>=30000){
      break;
    }
  }
  printf("恭喜!已經存夠了,共存了%d個月,總存款為%d元\n",num,deposite);
  return 0;
}
