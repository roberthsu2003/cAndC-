#include <stdio.h>
//請設計一個程式，讓使用者輸入數值，只有加總正偶數值，不加總正奇數值，如果輸入負數，結束程式。
int main(void) {
  int num=0;
  int value;
  int sum = 0;
  while(1){    
    printf("請輸入第%d個數值:",++num);
    scanf("%d", &value);
    if(value<0){
      break;
    }else if(value %2 == 1){
      continue;
    }else{
      sum += value;
    }    
  }

  printf("所有正偶數的加總是:%d\2",sum);
  return 0;
}
