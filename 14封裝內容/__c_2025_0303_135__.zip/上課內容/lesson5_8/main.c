#include <stdio.h>
#include <stdlib.h>

int main(void) {
  srand(45); //亂數種子
  printf("亂數是:%ld\n", random());
  return 0;
}
