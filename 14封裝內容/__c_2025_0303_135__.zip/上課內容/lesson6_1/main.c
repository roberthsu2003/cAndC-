#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  // printf("%ld\n",time(NULL));
  srandom(time(NULL));
  int max=52, min=50;
  int random_value = random() % (max-min+1) + min;
  printf("亂數:%d\n", random_value);

  return 0;
}
