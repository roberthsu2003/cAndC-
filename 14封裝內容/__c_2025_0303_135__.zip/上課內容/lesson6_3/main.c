#include <stdio.h>

int main(void) {
  int scores[3];
  printf("scores的大小是%lu\n", sizeof(scores));
  scores[0] = 78;
  scores[1] = 85;
  scores[2] = 96;
  printf("國文分數%d\n", scores[0]);
  printf("英文分數%d\n", scores[1]);
  printf("數文分數%d\n", scores[2]);
  return 0;
}
