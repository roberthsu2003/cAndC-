#include "stdio.h"

int main(void) {
  int scores[3] = {78, 85, 96};
  printf("scores的大小是%lu\n", sizeof(scores));
  for(int index=0;index<3;index++){
    switch(index){
      case 0:
      printf("國文分數%d\n", scores[index]);
      break;
      case 1:
      printf("英文分數%d\n", scores[index]);
      break;
      case 2:
      printf("數學文分數%d\n", scores[index]);
      }    
  }
  
  return 0;
}
