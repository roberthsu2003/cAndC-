#include "stdio.h"
#include "stdlib.h"
#include "time.h"

int main(void) {
  srandom(time(NULL));
  int scores[3];
  int min = 50;
  int max = 100;
  int total = 0;
  for(int index=0;index<3;index++){
    scores[index] = random() % (max-min+1) + min;
    total += scores[index];
    switch(index){
      case 0:
      printf("國文分數%d\n", scores[index]);
      break;
      case 1:
      printf("英文分數%d\n", scores[index]);
      break;
      case 2:
      printf("數學分數%d\n", scores[index]);
      }    
  }

  printf("總分是:%d\n",total);
  printf("平均是:%.2lf\n",total/3.0);
  

  return 0;
}
