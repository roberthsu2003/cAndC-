#include "stdio.h"
#include "stdlib.h"
#include "time.h"

int main(void) {
  srandom(time(NULL));
  int student_nums = 50;
  int subject_nums = 5; //5個科目
  int scores[student_nums][subject_nums]; //5個元素
  int min = 50;
  int max = 100;  
  for(int i=0;i<student_nums;i++){
    int total = 0;
    for(int index=0;index<subject_nums;index++){
      scores[i][index] = random() % (max-min+1) + min;
      total += scores[i][index];
      switch(index){
        case 0:
        printf("國文分數%d\n", scores[i][index]);
        break;
        case 1:
        printf("英文分數%d\n", scores[i][index]);
        break;
        case 2:
        printf("數學分數%d\n", scores[i][index]);
        break;
        case 3:
        printf("社會分數%d\n", scores[i][index]);
        break;
        case 4:
        printf("心理分數%d\n", scores[i][index]);
        }    
    }
    printf("總分是:%d\n",total);
    printf("平均是:%.2lf\n",(double)total/subject_nums);
    printf("===================\n");
  }

  return 0;
}
