#include <stdio.h>

int main(void) {
  printf("這是c語的第1節課\n");
  printf("今天是星期一晚上7:00\n");
  return 0;
}
