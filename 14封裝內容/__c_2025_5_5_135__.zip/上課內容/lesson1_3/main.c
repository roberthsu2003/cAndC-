#include <stdio.h>

int main(void) {
  //自動轉換
  printf("int+int=%d\n",6+5);
  printf("double+double=%.2lf\n",6.0+5.0);
  printf("int + double:%.2lf(自動轉換)\n",5 + 10.0);
  printf("7/3:%d(整數/整數,傳出整數)\n", 7/3);
  printf("7/3:%.2lf(自動轉換)\n", 7/3.0);
  
  return 0;
}
