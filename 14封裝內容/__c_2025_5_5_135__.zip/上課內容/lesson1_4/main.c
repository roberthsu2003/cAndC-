#include <stdio.h>

int main(void) {  
  int n; //建立變數
  n = 10; //將10給變數
  int m;
  m = 15;
  printf("n=%d\n",n); //取出變數的值
  printf("m=%d\n",m);
  printf("================\n");
  n = 100;
  m = 150;
  printf("n=%d(改變後)\n",n); //取出變數的值
  printf("m=%d(改變後)\n",m);
  return 0;
}
