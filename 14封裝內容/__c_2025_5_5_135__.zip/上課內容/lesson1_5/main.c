#include <stdio.h>

int main(void) {
  int n;
  n = 13; //自動轉換
  printf("n=%d\n",n);
  double m;
  m = n * 10.1;
  printf("m=%.2lf\n",m);
  return 0;
}
