#include <stdio.h>

int main(void) {
  //=運算子是建立敘述式,不會傳出值
  int n = 7;
  int m = 3;
  double value = n / (double)m;//強制轉換,做2件事
  printf("7/3=%.2lf\n", value); 
  return 0;
}
