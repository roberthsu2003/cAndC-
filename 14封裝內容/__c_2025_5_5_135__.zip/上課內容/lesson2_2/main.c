#include <stdio.h>

int main(void) {
  printf("矩形寬:%d\n",46);
  printf("矩形高:%.3lf\n",75.4);
  return 0;
}
