#include <stdio.h>
//數學運算子的優先順序
int main(void) {
  printf("%d\n", 2 * 3 + 4);
  printf("%d\n", 2 * (3 + 4));
  return 0;
}
