#include <stdio.h>
//使用者輸入值
//取址運算子 -> &變數名稱
//scanf()->輸入
int main(void) {
  int n;
  printf("n的記憶體位址是:%p\n",&n); //取址運算子
  printf("請輸入n的數值:"); 
  scanf("%d",&n);
  printf("n儲存的數值是:%d\n", n);
  return 0;
}
