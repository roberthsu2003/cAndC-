#include <stdio.h>
//計算矩形的面積
int main(void) {
  double width, height, area;
  printf("請輸入矩形的寬:");
  scanf("%lf", &width);
  printf("請輸入矩形的高:");
  scanf("%lf",&height);
  area = width * height;
  printf("矩形的面積是%.2lf\n",area);
  return 0;
}
