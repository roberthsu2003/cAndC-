#include <stdio.h>

int main(void) {
  double radius,area,result;
  const double PI = 3.1415926; //建立常數
  printf("請輸入圓半徑:");
  scanf("%lf",&radius);
  area = PI * radius * radius;
  result = 2 * PI * radius;
  printf("圓面積是:%.2lf\n",area);
  printf("圓周率是%.2lf\n",result);
  return 0;
}
