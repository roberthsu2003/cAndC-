#include <stdio.h>
#include <math.h>
//使用數學函式庫
int main(void) {
  double opposite_side,side,hypotenuse;
  printf("請輸入對邊:");
  scanf("%lf",&opposite_side);
  printf("請輸入鄰邊:");
  scanf("%lf",&side);
  hypotenuse = sqrt(pow(opposite_side,2) + pow(side,2));
  printf("斜邊為:%.2lf\n",hypotenuse);
  return 0;
}
