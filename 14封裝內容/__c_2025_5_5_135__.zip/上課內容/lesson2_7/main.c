#include <stdio.h>
#include <math.h>
//求直角三角形的角度

int main(void) {
  double opposite_side,hypotenuse,radian,degree;
  const double PI = 3.1415926;
  printf("請輸入對邊:");
  scanf("%lf", &opposite_side);
  printf("請輸入斜邊:");
  scanf("%lf",&hypotenuse);
  radian = asin(opposite_side / hypotenuse);
  degree = 180 / PI * radian;
  printf("弧度是:%.2lf\n", radian);
  printf("角度是:%.2lf\n", degree);
  
  return 0;
}
