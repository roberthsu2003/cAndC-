#include <stdio.h>

int main(void) {
  int n = 10;
  int n_size = sizeof(n);
  printf("n變數配置的記憶體大小:%d\n", n_size);

  double m = 10.0;
  int m_size = sizeof(m);
  printf("m變數配置的記憶體大小:%d\n", m_size);
  return 0;
}
