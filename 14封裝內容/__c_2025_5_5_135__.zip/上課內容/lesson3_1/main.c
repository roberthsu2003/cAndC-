#include <stdio.h>

int main(void) {
  char characterA; //字元
  characterA = 'A';
  printf("characterA=%c\n",characterA);
  printf("characterA=%d\n",characterA);

  //unsigned char->整數值
  unsigned char n = 255;
  printf("n=%d\n",n);
  return 0;
}
