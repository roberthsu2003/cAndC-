#include <stdio.h>
//學生符合加分條件就加5%分,如果超過300分,就以300為主。

int main(void) {
  int scores;
  int add;
  printf("請輸入學生分數:");
  scanf("%d", &scores);
  printf("學生符合加分條件嗎?(y=1,n=0):");
  scanf("%d", &add);
  if(add){
    scores *= 1.05;
    if(scores > 300){
      scores = 300;
    }
  }
  printf("學生分數是:%d", scores);
  return 0;
}
