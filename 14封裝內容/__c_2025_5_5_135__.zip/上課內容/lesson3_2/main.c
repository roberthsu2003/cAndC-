#include <stdio.h>
#include <math.h>

int main(void) {
  float value = 314.567890123;
  printf("%.9f\n",value);
  double value1 = 314.567890123;
  printf("%.9lf\n",value1);

  double result = pow(99, 99);
  printf("%e\n",result);
  
  return 0;
}
