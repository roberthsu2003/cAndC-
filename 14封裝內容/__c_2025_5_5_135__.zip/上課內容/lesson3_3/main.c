#include <stdio.h>
//特殊字元
int main(void) {
  printf("姓名\t\t座號\t電話\n");
  printf("\'李振聲\'\t11\t029567894\n");
  printf("\"李振聲\"\t12\t029567894\n");
  return 0;
}
