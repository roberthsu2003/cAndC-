#include <stdio.h>
//請以(複合指定運算子)設計程式,讓用者輸入三個任意數，程式會顯示3數相加的總和(float)

int main(void) {
  float input_value;
  double result=0;
  printf("請輸入第1個數:");
  scanf("%f",&input_value);
  result += input_value;

  printf("請輸入第2個數:");
  scanf("%f",&input_value);
  result += input_value;

  printf("請輸入第3個數:");
  scanf("%f",&input_value);
  result += input_value;

  printf("3數加總的總合是:%.2lf\n", result);
  return 0;
}
