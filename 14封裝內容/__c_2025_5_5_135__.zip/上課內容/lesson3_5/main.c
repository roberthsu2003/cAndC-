#include <stdio.h>
//遞增,遞增
int main(void) {
  int n=0;
  n++;
  printf("n=%d\n",n);
  ++n;
  printf("n=%d\n",n);

  printf("===========\n");
  int x = 1;
  int y = ++x;
  printf("x=%d\n",x);
  printf("y=%d\n",y);

  printf("============\n");
  int i = 1;
  int j = i++;
  printf("i=%d\n",i);
  printf("j=%d\n",j);
  return 0;
}
