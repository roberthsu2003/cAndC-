#include <stdio.h>

int main(void) {
  printf("5==5傳出的值:%d\n",5 == 5);
  printf("5!=5傳出的值:%d\n",5 != 5);
  return 0;
}
