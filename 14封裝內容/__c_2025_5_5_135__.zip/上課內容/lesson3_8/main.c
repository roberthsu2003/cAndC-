#include <stdio.h>

int main(void) {
  int age;
  printf("請輸入age:");
  scanf("%d",&age);
  
  if(age >= 18){
    printf("可以考駕照!\n");
  }else{
    printf("不可以考駕照!\n");
  }
  return 0;
}
