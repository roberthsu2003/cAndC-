#include <stdio.h>
//判斷使用者輸入的數值是奇數還是偶數

int main(void) {
  int number;
  printf("請輸入1個數值:");
  scanf("%d", &number);

  if(number % 2 == 0){
    printf("%d是偶數",number);
  }else{
    printf("%d是奇數\n",number);
  }
  return 0;
}
