#include <stdio.h>

int main(void) {
  int scores;
  printf("請輸入學生分數:");
  scanf("%d",&scores);
  if(scores>=80){
    printf("優\n");
  }else if(scores>=60){
     printf("甲\n");
  }else{
    printf("不及格\n");
  }
  return 0;
}
