#include <stdio.h>

int main(void) {
  int scores;
  printf("請輸入學生分數:");
  scanf("%d",&scores);
  if(scores>=90){
    printf("優");
  }else if(scores>=80){
    printf("甲");
  }else if(scores >= 70){
    printf("乙");
  }else if(scores >= 60){
    printf("丙");
  }else{
    printf("丁");
  }
  return 0;
}
