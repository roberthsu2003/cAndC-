#include <stdio.h>
#include <math.h>

int main(void) {
  int weight,height;
  double bmi;
  printf("請輸入體重(kg):");
  scanf("%d",&weight);
  printf("請輸入身高(公分):");
  scanf("%d",&height);
  bmi = weight/pow(height/100.0,2);
  printf("bmi:%.2lf\n", bmi);

  if(bmi<18.5){
    printf("體重過輕\n");
  }else if(bmi < 24){
    printf("正常範圍\n");
  }else if(bmi<27){
    printf("過重\n");
  }else if(bmi<30){
    printf("輕度肥胖\n");
  }else if(bmi<35){
    printf("中度肥胖\n");
  }else{
    printf("重度肥胖\n");
  }
  
  
  return 0;
}
