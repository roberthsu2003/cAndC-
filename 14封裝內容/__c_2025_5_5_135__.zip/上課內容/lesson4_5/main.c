#include <stdio.h>
//國文100同時數學100,獎金1000
//國文100或者數學100,獎金500
int main(void) {
  int chinese,math;
  int bouns;
  printf("請輸入國文成績和數學成績(國文,數學):");
  scanf("%d,%d",&chinese,&math);
  if(chinese == 100 && math == 100){
    bouns = 1000;
  }else if(chinese == 100 || math == 100){
    bouns = 500;
  }else{
    bouns = 0;
  }
  printf("獎金:%d\n", bouns);
  return 0;
}
