#include <stdio.h>
// 1~10相加?
int main(void) {

  int total = 0;
  /*
  total += 1;
  total += 2;
  total += 3;
  total += 4;
  total += 5;
  total += 6;
  total += 7;
  total += 8;
  total += 9;
  total += 10;
  printf("1~10相加:%d\n",total);
  */

  for (int i = 1; i <= 100; i++){
    total += i;
  }
  printf("1~100相加:%d\n",total);
  return 0;
}
