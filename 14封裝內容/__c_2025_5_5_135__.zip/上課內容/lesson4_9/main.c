#include <stdio.h>

int main(void) {
  int total = 0;
  int i = 1; //step1
  while(i<101){ //step2
    total += i;
    i++; //step3,如果每次增加的值不一定
  }
  printf("total=%d\n",total);
  return 0;
}
