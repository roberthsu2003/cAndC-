#include <stdio.h>
//小明想要存錢買一輛機車,機車每輛30000元，他將每月存的錢輸入，當存款足夠買機車時，就顯示提示訊息告知。
int main(void) {
  int deposite = 0;
  int money;
  int month = 0;
  while(deposite < 30000){
    printf("請輸入第%d月份的存款:",++month);
    scanf("%d", &money);
    deposite += money;
  }
  printf("恭喜!已經存夠了,存了%d個月共存了%d元\n",month,deposite);
  return 0;
}
