#include <stdio.h>

int main(void) {
  int value;
  do{
    printf("請輸入1個數值:(0:離開)");
    scanf("%d",&value);
    printf("您輸入的值是%d\n",value);
  }while(value != 0);

  printf("應用程式結束");
  return 0;
}
