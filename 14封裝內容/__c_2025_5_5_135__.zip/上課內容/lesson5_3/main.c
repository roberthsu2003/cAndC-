#include <stdio.h>

int main(void) {
  int value;
  while (1) {
    printf("請輸入1個數值:(0:離開)");
    scanf("%d", &value);
    if (value == 0) {
      break;
    }
    printf("您輸入的值是%d\n", value);
  };

  printf("應用程式結束");
  return 0;
}
