#include <stdio.h>
//請設計一個程式，讓使用者輸入數值，只有加總正偶數值，不加總正奇數值，如果輸入負數，結束程式。
int main(void) {
  int input_value;
  int total = 0;
  while(1){
    printf("請輸入1個數值:(負數結束程式)");
    scanf("%d", &input_value);
    if(input_value<0){
      break;
    }else if(input_value % 2 == 1){
      continue;
    }else{
      total += input_value;
    }
  }
  printf("total:%d\n",total);
  return 0;
}
