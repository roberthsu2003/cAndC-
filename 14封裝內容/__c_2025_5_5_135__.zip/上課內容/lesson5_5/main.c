#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//建立亂數
// random,srandom
//猜數字遊戲

int main(void) {
  // printf("%ld\n",time(NULL)); // 1970至現在的秒數
  int guess;
  srandom(time(NULL));
  int min = 1;
  int max = 99;
  int keyin;
  int count = 0;
  guess = random() % (max - min + 1) + min;
  //printf("%d\n", guess);
  printf("=======猜數字遊戲=======\n\n");
  while(1){
    printf("猜數字範圍%d~%d:", min, max);
    scanf("%d", &keyin);
    count++;
    if(keyin >= min && keyin <=max){
      if(keyin == guess){
        printf("賓果!猜對了,答案是%d\n",guess);
        printf("您猜了%d次\n",count);
        break;
      }else if(keyin > guess){
        printf("再小一點\n");
        max = keyin - 1;
      }else if(keyin < guess){
        printf("再大一點\n");
        min = keyin + 1;
      }
      printf("您已經猜了%d次\n\n", count);
      
    }else{
      printf("請輸入提示範圍內的數字!\n");
    }
    
  }
  printf("遊戲結束\n");
  return 0;
}
