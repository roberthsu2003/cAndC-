#include <stdio.h>

//自訂沒有傳出值,也沒有參數的function()
void fun1(){
  printf("這是執行func1\n");
}

void fun2(){
  printf("這是執行func2\n");
}

int main(void) {
  printf("現在執行main\n");
  fun1();
  printf("還是執行main\n");
  fun2();
  printf("還是執行main\n");
  return 0;
}
