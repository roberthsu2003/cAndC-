#include <stdio.h>
#include <math.h>

//定義function,有2個參數,有1個傳出值
double bmi_generator(int h,int w){
  return w / pow(h / 100.0,2);
}

int main(void) {
  int height,weight;
  double bmi;
  printf("請輸入身高cm:");
  scanf("%d",&height);
  printf("請輸入體重kg:");
  scanf("%d",&weight);
  bmi = bmi_generator(height, weight); //呼叫function
  printf("bmi值是:%.2lf\n", bmi);
  
  return 0;
}
