#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tools.h"
//建立亂數
// random,srandom
//猜數字遊戲

int main(void) {
  int play_again;
  srandom(time(NULL));
  while(1){
    play_game();
    printf("您還要繼續嗎?(y:1,n:0):");
    scanf("%d",&play_again);
    if(play_again == 0){
      break;
    }
  }
  printf("遊戲結束\n");
  return 0;
}
