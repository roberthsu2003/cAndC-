#include <stdio.h>

int main(void) {
  int scores[3];
  //printf("%lu\n",sizeof(scores));
  scores[0] = 78;
  scores[1] = 92;
  scores[2] = 85;
  /*
  printf("元素0:%d\n",scores[0]);
  printf("元素1:%d\n",scores[1]);
  printf("元素2:%d\n",scores[2]);
  */
  for(int i=0; i<3; i++){
    printf("元素%d:%d\n",i,scores[i]);
  }
  return 0;
}
