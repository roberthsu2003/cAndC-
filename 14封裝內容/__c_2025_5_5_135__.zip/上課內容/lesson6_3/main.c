#include <stdio.h>

int main(void) {
  int scores[5];
  int total = 0;
  double average;
  for(int i=0; i<5; i++){
    printf("請輸入第%d科分數:",i+1);
    scanf("%d",&scores[i]);
  }

  for(int i=0; i<5; i++){
    total += scores[i];
  }

  average = total / 5.0;

  printf("總分是:%d,平均是:%.2lf\n", total, average);
  
  return 0;
}
