#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int get_scores(){
  int min = 50;
  int max = 100;
  return random() % (max-min+1) + min;
}

void score_generator(int s[], int n){
  for(int i=0; i<n; i++){
    s[i] = get_scores();
  }
}

int main(void) {
  srandom(time(NULL));
  int num = 5;
  int scores[num];
  score_generator(scores,num);
  for(int i=0; i<num; i++){
    printf("scores[%d]=%d\n",i, scores[i]);
  }
  return 0;
}
