#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int get_scores(){
  int min = 50;
  int max = 100;
  return random() % (max-min+1) + min;
}

int main(void) {
  srandom(time(NULL));
  int number = 50;
  int subjects = 5;
  int students[number][subjects];

  for(int i=0; i<number; i++){
    printf("學生%d:",i);
    int sum = 0;
    for(int j=0; j<subjects; j++){
      students[i][j] = get_scores();
      printf("%d ", students[i][j]);
      sum += students[i][j];
    }
    printf("%d %.2lf\n",sum,sum/5.0);
    
  }
  return 0;
}
