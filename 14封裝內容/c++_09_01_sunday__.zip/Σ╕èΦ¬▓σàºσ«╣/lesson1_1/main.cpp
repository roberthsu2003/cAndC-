#include <iostream>
using namespace std;
// c++內使用c的語法
int main() {
  int englishScore = 78;
  cout << "請輸入英文分數:";
  cin >> englishScore;
  cout << "英文分數是" << englishScore << endl;
  return 0;
}
