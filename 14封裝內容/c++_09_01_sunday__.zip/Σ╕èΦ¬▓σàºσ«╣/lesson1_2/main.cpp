#include <iostream>
using namespace std;
int main() {
  int englishScore;
  string name;
  cout << "請輸入姓名:";
  cin >> name;
  cout << "請輸入英文分數:";
  cin >> englishScore;
  cout << name << "的英文分數是" << englishScore << endl;
  return 0;
}
