#include <iostream>
using namespace std;
int main() {
  int scores[3];
  scores[0] = 89;
  scores[1] = 78;
  scores[2] = 99;
  cout << "第1個元素:" << scores[0] << endl; 
  cout << "第2個元素:" << scores[1] << endl; 
  cout << "第3個元素:" << scores[2] << endl; 
}
