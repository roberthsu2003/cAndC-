#include <iostream>
using namespace std;
int main() {
  int sum = 0;
  int n = 3;
  int scores[n];
  for(int i=0;i<n;i++){
    cout << "請輸入第" << i+1 << "個元素:";
    cin >> scores[i];
    sum += scores[i];
  }

  for(int i=0;i<n ; ++i){
    cout << "第" << i+1 << "個元素:";
    cout << scores[i] << endl;
  }
  cout << "總分為:" << sum << endl;
  //cout << "平均是:" << sum / (double)n << endl;
  printf("平均是:%.2lf\n",sum / (double)n);
}
