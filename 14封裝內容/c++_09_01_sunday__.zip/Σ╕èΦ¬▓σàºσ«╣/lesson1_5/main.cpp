#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

int main() {
  int min = 95;
  int max = 100;
  srand(time(NULL));
  cout << rand() % (max-min+1) + min << endl;  
}
