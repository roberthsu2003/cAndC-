#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;
int main() {
  int min = 50;
  int max = 100;
  srand(time(NULL));
  int sum = 0;
  int n = 5;
  int scores[n];
  
  for(int i=0;i<n;i++){
    scores[i] = rand() % (max-min+1) + min;
    sum += scores[i];
  }

  for(int i=0;i<n ; ++i){
    cout << "第" << i+1 << "個元素:";
    cout << scores[i] << endl;
  }
  cout << "總分為:" << sum << endl;
  //cout << "平均是:" << sum / (double)n << endl;
  printf("平均是:%.2lf\n",sum / (double)n);
}
