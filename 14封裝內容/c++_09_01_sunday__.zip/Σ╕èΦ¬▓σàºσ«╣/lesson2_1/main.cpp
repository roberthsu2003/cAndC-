#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;

int main() {
  int min = 50;
  int max = 100;
  srand(time(NULL));
  //一維陣列
  string names[4] = {"周華見", "劉得華", "張學有", "梁朝為"};
  // cout << "names陣列大小為" << sizeof(names) << endl;
  //  2維陣列
  int scores[4][5];
  for (int i = 0; i < 4; i++) {
    //列的索引編號
    for (int j = 0; j < 5; j++) {
      scores[i][j] = rand() % (max - min + 1) + min;
    }
  }

  for (int i = 0; i < 4; i++) {
    cout << names[i] << endl;
    int sum = 0;
    
    for (int j = 0; j < 5; j++) {
      cout << scores[i][j] << " ";
      sum += scores[i][j];
    }
    cout << endl;
    cout << "總分:" << sum << endl;
    printf("平均:%.2lf\n\n", sum / 5.0);
    
  }
}
