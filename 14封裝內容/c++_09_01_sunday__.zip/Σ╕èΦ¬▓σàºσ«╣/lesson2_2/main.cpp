#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

int main() {
  int nums;
  int min = 1;
  int max = 100;
  srand(time(NULL));
  cout << "請輸入要排序的數值個數:";
  cin >> nums;
  float array[nums], temp;
  for (int i = 0; i < nums; i++) {
    array[i] = rand() % (max - min + 1) + min;
  }
  
  cout << "排序前:\n";
  for (int i = 0; i < nums; i++) {
    cout << array[i] << " ";
  }
  cout << endl;

  
  //泡沫排序法
  for(int i=0; i<nums-1; i++){
    for(int j=i+1; j<nums; j++){
      if (array[i] < array[j]){
        //2數對調
        temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }
    }
    
  }
  cout << "排序後:\n";
  for (int i = 0; i < nums; i++) {
    cout << array[i] << " ";
  }
  cout << endl;
}
