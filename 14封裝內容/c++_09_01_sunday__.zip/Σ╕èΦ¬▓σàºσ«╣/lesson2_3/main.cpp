#include <iostream>
using namespace std;

//定義結構
typedef struct rectangle {
  int width;
  int height;
} Rectangle;

int main() {
  Rectangle recs[2]; //建立結構陣列
  
  recs[0].width = 56;
  recs[0].height = 92;

  recs[1].width = 92;
  recs[1].height = 193;
  
  cout << "矩型1面積:" << recs[0].width * recs[0].height << endl;
  cout << "矩型2面積:" << recs[1].width * recs[1].height << endl;
}
