#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

typedef struct student {
  string name;
  int chinese;
  int english;
  int math;
} Student;

int main() {
  int min = 50;
  int max = 100;
  srand(time(NULL));
  int nums = 50;
  Student students[nums];
  for (int i = 0; i < nums; i++) {
    students[i].name = "學生" + to_string(i+1);
    students[i].chinese = rand() % (max - min + 1) + min;
    students[i].english = rand() % (max - min + 1) + min;
    students[i].math = rand() % (max - min + 1) + min;
  }

  for (int i = 0; i < nums; i++) {
    int sum = 0;
    cout << students[i].name << endl;
    cout << "國文:" << students[i].chinese << " ";
    cout << ",英文:" << students[i].english << " ";
    cout << ",數學:" << students[i].math << "\n";
    sum = students[i].chinese + students[i].english + students[i].math;
    cout << "總分:" << sum << endl;
    printf("平均:%.2lf\n\n", sum / 3.0);
  }
}
