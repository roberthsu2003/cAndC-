#include <iostream>
using namespace std;

int n = 100;

//自訂的function
void sayHello(){
	
	cout << "歡迎光臨!" << endl;
}

int main() { 
	
	sayHello();
	return 0;
}
