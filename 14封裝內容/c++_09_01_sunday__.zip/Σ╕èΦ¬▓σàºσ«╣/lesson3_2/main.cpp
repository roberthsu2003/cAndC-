//輸入攝氏溫度，求華氏溫度
/*=============================

攝氏10度轉華氏溫度=50
==========================
請輸入攝氏溫度:19
華氏溫度=66.2

===============================*/

#include <iostream>
using namespace std;
//定義function
double temperature(int value){
	double fel = 1.8 * value + 32;
	return fel;
}

int main() {
	int cel;
	double result;
	cout << "請輸入攝氏溫度:";
	cin >> cel;
	result = temperature(cel); //呼叫function,傳一個引數值,建立變數,接收function傳出的值
	cout << "華氏溫度=" << result << endl;
	return 0;
}
