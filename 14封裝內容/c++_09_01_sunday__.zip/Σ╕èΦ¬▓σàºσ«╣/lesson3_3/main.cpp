#include <iostream>
#include <math.h>

using namespace std;

int fun1(int x){
	return pow(x,2) + 2 * x + 1;
}

int main() { 
	for(int x=0; x<=10; x++){
		int result = fun1(x);
		cout << "如果x=" << x << "得到的值是" << result << endl;
	}
}
