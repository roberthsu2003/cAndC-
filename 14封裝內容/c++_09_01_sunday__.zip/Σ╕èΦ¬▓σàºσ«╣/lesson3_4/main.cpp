#include <iostream>
#include <math.h>

using namespace std;

int fun1(int x, int y){
	return pow(x,2) + 2 * x + y;
}

int main() { 
	for(int x=0; x<=10; x++){
		int result = fun1(x,1);
		cout << "如果x=" << x << "得到的值是" << result << endl;
	}
}
