#include <iostream>
#include <math.h>

using namespace std;

int fun1(int x, int y){
	return pow(x,2) + 2 * x + y;
}

int main() {
	int nums[] = {5, 13, 26, 35, 49, 57, 65};	
	int n = sizeof(nums) / sizeof(nums[0]);
	
	for(int i=0; i<n; i++){
		int result = fun1(nums[i],1);
		cout << "如果x=" << nums[i] << "得到的值是" << result << endl;
	}
}
