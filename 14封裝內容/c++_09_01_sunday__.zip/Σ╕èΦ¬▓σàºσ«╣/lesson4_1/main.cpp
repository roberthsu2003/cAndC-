#include <iostream>

using namespace std;
//建立function原形
double factorial(double);


int main() {
	double n,total;
	cout << "請輸入數字 n:";
	cin >> n;
	total = factorial(n);
	cout << n << "!=" << total << endl;
}

//recoursive
double factorial(double n){
	if (n == 1){
		return 1;
	}else{
		return n * factorial(n-1);
	}

}
