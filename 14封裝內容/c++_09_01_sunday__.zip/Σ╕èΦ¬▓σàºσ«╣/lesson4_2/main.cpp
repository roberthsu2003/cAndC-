#include <iostream>
using namespace std;

int main() { 
	int array[] = {10, 20, 30};
	//使用取址運算子取得記憶體位址
	cout << "array陣列的記憶體位址:" << array << endl;
	cout << "元素0的記憶體位址:" << &array[0] << endl;
	cout << "元素1的記憶體位址:" << &array[1] << endl;
	cout << "元素2的記憶體位址:" << &array[2] << endl;
	//使用+和索引編號,取得元素的記憶體位址
	cout << "元素0的記憶體位址:" << array + 0 << endl;
	cout << "元素1的記憶體位址:" << array + 1 << endl;
	cout << "元素2的記憶體位址:" << array + 2 << endl; 
}
