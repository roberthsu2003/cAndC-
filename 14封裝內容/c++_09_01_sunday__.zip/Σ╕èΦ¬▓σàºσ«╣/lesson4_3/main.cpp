#include <iostream>
using namespace std;

int main() {
  int n = 10;
  cout << "變數n的值=" << n << endl;
  cout << "變數n的記憶體位址=" << &n << endl;
  int *ptr; //*代表建立一個指標變數
  ptr = &n;
  cout << "指標變數儲存的內容:" << ptr << endl;
  cout << "指標變數指向記憶體的值是" << *ptr << endl; //*取值運算子
}
