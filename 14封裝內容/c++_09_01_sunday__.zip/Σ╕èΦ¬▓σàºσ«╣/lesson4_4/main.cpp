#include <iostream>
using namespace std;

int main() { 
	//建立指標變數
	int *m = new int(10);
	cout << "值為" << *m << endl; //取值運算子
}
