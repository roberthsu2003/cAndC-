#include <iostream>
using namespace std;

int main() {
  int *nums = new int[3];
	*(nums + 0) = 10;
	*(nums + 1) = 20;
	*(nums + 2) = 30;
  
  cout << "nums[0]=" << nums[0] << endl;
  cout << "nums[1]=" << nums[1] << endl;
  cout << "nums[2]=" << nums[2] << endl;
  cout << "==================" << endl;
  cout << "*(nums + 0)=" << *(nums + 0) << endl;
  cout << "*(nums + 1)=" << *(nums + 1) << endl;
  cout << "*(nums + 2)=" << *(nums + 2) << endl;
}
