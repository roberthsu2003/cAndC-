#include <iostream>
using namespace std;

void swap(int *x, int *y){
	//2數對調
	int temp = *x;
	*x = *y;
	*y = temp;
}

int main() {
  int n = 666;
  int m = 888;
	cout << "對調前:";
	cout << "n=" << n << ",";
	cout << "m=" << m << endl;

	swap(&n, &m);

	cout << "對調後:";
	cout << "n=" << n << ",";
	cout << "m=" << m << endl;
		
}
