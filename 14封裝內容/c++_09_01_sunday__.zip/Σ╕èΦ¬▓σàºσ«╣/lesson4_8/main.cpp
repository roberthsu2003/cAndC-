#include <iostream>
using namespace std;

void multiple10(int *ptr, int m) {
  for (int i = 0; i < m; i++) {
    ptr[i] *= 10;
  }
}

int main() {
  int n = 3;
  int nums[n];
  nums[0] = 1;
  nums[1] = 2;
  nums[2] = 3;

  multiple10(nums, n);
  for (int i = 0; i < n; i++) {
    cout << "nums[" << i << "]=" << nums[i] << endl;
  }
}
