#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

void bubble(float *ptr,int m){
	float temp;
	for(int i=0; i<m-1; i++){
		for(int j=i+1; j<m; j++){
			if (ptr[i] < ptr[j]){
				//2數對調
				temp = ptr[i];
				ptr[i] = ptr[j];
				ptr[j] = temp;
			}
		}
	}
}

int main() {
	int nums;
	int min = 1;
	int max = 100;
	srand(time(NULL));
	cout << "請輸入要排序的數值個數:";
	cin >> nums;
	float array[nums];
	for (int i = 0; i < nums; i++) {
		array[i] = rand() % (max - min + 1) + min;
	}

	cout << "排序前:\n";
	for (int i = 0; i < nums; i++) {
		cout << array[i] << " ";
	}
	cout << endl;


	//泡沫排序法
	bubble(array,nums);
	
	cout << "排序後:\n";
	for (int i = 0; i < nums; i++) {
		cout << array[i] << " ";
	}
	cout << endl;
}
