#include "structure.h"

void bubble(Student *ptr, int n) {
	Student tmp;
	for (int i = 0; i < n - 1; i++) {
		for (int j = i + 1; j < n; j++) {
			if (ptr[i].average < ptr[j].average) {
				tmp = ptr[j];
				ptr[j] = ptr[i];
				ptr[i] = tmp;
			}
		}
	}
}
