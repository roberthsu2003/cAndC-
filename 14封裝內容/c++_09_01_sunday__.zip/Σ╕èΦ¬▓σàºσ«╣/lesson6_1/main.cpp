
#include "tools.h"
#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;

int main() {
  Student tmp;

  srand(time(NULL));

  Student students[N];

  for (int i = 0; i < N; i++) {
    string name_ori = "學生" + to_string(i + 1);
    students[i].name = name_ori;
    students[i].chinese = rand() % (MAX - MIN + 1) + MIN;
    students[i].english = rand() % (MAX - MIN + 1) + MIN;
    students[i].math = rand() % (MAX - MIN + 1) + MIN;
    students[i].sum =
        students[i].chinese + students[i].english + students[i].math;
    students[i].average = students[i].sum / 3.0;
  }

  bubble(students, N);

  for (int i = 0; i < N; i++) {
    cout << "名次:" << i + 1 << endl;
    cout << students[i].name << endl;
    cout << "中文:" << students[i].chinese << " ";
    cout << "英文:" << students[i].english << " ";
    cout << "數學:" << students[i].math << "\n";
    cout << "總分:" << students[i].sum << "\n";
    printf("平均:%.2lf\n\n", students[i].average);
  }
}
