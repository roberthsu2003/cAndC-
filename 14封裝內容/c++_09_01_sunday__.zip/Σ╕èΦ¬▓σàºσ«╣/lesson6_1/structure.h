#ifndef __STRUCTURE_H__
#define __STRUCTURE_H__

#include <iostream>
#include <string>
using namespace std;
//定義常數
const int N = 50;
const int MIN = 50;
const int MAX = 100;

// 定義結構
typedef struct student {
  string name;
  int chinese;
  int english;
  int math;
  int sum = 0;
  double average;
} Student;

#endif

