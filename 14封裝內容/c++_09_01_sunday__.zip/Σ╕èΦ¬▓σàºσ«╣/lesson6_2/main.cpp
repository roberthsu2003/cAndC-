#include <iostream>
#include <fstream>

using namespace std;

int main() { 
  fstream file;
  char buffer[500];
  file.open("readme.txt",ios::in);
  if(!file){
    cout << "檔案無法開啟!" << endl;
  }else{
    cout << "檔案已經開啟" << endl;
    file.read(buffer,sizeof(buffer));
    file.close();
  }
  cout << buffer << endl;
}
