#include <fstream>
#include <iostream>

using namespace std;

int main() {
  fstream file;
  char ch;
  file.open("readme.txt", ios::in);
  if (!file) {
    cout << "檔案無法開啟!" << endl;
  } else {
    cout << "檔案已經開啟" << endl;
    while(file.get(ch)){
      cout << ch;
    }
    cout << endl;
    file.close();
  }
  
}
