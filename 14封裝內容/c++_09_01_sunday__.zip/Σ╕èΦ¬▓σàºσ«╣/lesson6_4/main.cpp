#include <fstream>
#include <iostream>

using namespace std;

int main() {
  fstream file;
  char buffer[80];
  file.open("readme.txt", ios::in);
  if (!file) {
    cout << "檔案無法開啟!" << endl;
  } else {
    cout << "檔案已經開啟" << endl;
    while(true){
      file.getline(buffer,sizeof(buffer));
      cout<<buffer<<endl;
      if(file.eof()){
        break;

      }
    
    }
    file.close();
  }
}
