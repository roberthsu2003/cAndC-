#include <iostream>
#include <vector>

using namespace std;

int main() { 
  vector<int> vec_a;
  vector<int> vec_b(10);
  vector<int> vec_c(10,8);
  vector<int> vec_d{10, 20, 30, 40, 50};

  for (int elem: vec_d){
    cout << elem << endl;
  }
}
