#include <fstream>
#include <iostream>
#include <time.h>
#include <vector>

using namespace std;
int main() {
  int count;
  string filename;
  srand(time(NULL));
  cout << "亂數產生的數量:";
  cin >> count;
  vector<int> numbers(count);

  cout << "請輸入檔案名稱:";
  cin >> filename;

  for (int &elem : numbers) {
    elem = random() % (100 - 1 + 1) + 1;
  }

  for (int elem : numbers) {
    cout << elem << " ";
  }

  ofstream out;
  out.open(filename);
  if(out.good()){
    for (int elem : numbers) {
      out << elem << " ";
    }
    out << endl;
  }
  out.close();
}
