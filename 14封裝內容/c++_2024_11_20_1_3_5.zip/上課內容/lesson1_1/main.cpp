#include <iostream>

using namespace std;

int main() { 
  cout << "Hello World!\n";
  cout << "這是C++的第一堂課" << endl;
  cout << "我的名字叫徐國堂" << endl;
}
