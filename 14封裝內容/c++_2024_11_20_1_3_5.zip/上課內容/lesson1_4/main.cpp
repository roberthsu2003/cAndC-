#include <iostream>
using namespace std;

int main() { 
  int numbers[3];
  numbers[0] = 10;
  numbers[1] = 20;
  numbers[2] = 30;
  cout << numbers[0] <<",";
  cout << numbers[1] << ",";
  cout << numbers[2];
}
