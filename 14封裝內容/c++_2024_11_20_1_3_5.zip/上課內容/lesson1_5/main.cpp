#include <iostream>

using namespace std;

int main() {
  //利用array執行搜尋的功能
  string name;
  string fruits[] = {"香蕉","蘋果","鳳梨"};
  int nums = sizeof(fruits) / sizeof(fruits[0]);
  cout << "請輸入一個水果名稱:";
  cin >> name;
  bool is_found = false;
  for(int i=0; i<nums; i++){
    if(name == fruits[i]){
      cout << "有發現:" << name << endl;
      is_found = true;
      break;
    }
  }
  
  if(!is_found){
    //is_found是false的程式區塊
    cout << "沒有發現" << endl;
  }

  
}
