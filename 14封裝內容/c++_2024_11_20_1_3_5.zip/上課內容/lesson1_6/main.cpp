#include <iostream>
#include <time.h>

using namespace std;

int main() {
  srand(time(NULL));
  int min = 50;
  int max = 100;
  int nums = 10;
  int scores[nums];
  //給陣列值
  for (int i = 0; i < nums; i++) {
    scores[i] = rand() % (max - min + 1) + min;
  }
  //取出陣列值
  for (int i = 0; i < nums; i++) {
    cout << scores[i] << " ";
  }
  cout << endl;
}
