#include <iostream>

using namespace std;

int main() {
  int num;
  int qty = 0;
  int sum = 0;
  cout << "輸入:" << endl;
  cout << "請輸入正整數:";
  cin >> num;

  cout << "輸出:" << endl;
  cout << num << "因數有:";
  for (int i = 1; i <= num; i++) {
    if (num % i == 0) {
      cout << i << " ";
      qty += 1;
      sum += i;
    }
  }
  cout << endl;
  cout << num << "的因數共有" << qty << "個" << endl;
  cout << num << "的因數加總為:" << sum << endl;
}
