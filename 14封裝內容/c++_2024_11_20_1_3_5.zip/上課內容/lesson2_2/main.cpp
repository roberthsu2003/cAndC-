#include <iostream>
#include <time.h>

using namespace std;

int main() {
  srand(time(NULL));
  int min = 1;
  int max = 100;
  int nums = 10;
  int scores[nums];
  //給陣列值
  for (int i = 0; i < nums; i++) {
    scores[i] = rand() % (max - min + 1) + min;
  }
  //取出陣列值
  cout << "排序前:" << endl;
  for (int i = 0; i < nums; i++) {
    cout << scores[i] << " ";
  }
  cout << endl;

  //=======================

  //泡沫排序法
  for (int i = 0; i < nums - 1; i++) {
    for (int j = i + 1; j < nums; j++) {

      if (scores[i] > scores[j]) {
        int temp = scores[i];
        scores[i] = scores[j];
        scores[j] = temp;
      }
    }
  }

  cout << "排序後(由小到大):" << endl;
  for (int i = 0; i < nums; i++) {
    cout << scores[i] << " ";
  }
  cout << endl;
}
