#include <iostream>
using namespace std;

int main() {
  int nums[] = {13, 98, 65, 89};
  cout << "nums排序前:" << endl;
  for (int i = 0; i < 4; i++) {
    cout << nums[i] << " ";
  }
  cout << endl;
  //========排序===============
  //泡沫排序法
  for (int i = 0; i < 4 - 1; i++) {
    for (int j = i + 1; j < 4; j++) {
      //cout << nums[i] << "," << nums[j] << endl;
      if(nums[i] > nums[j]){
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
      }
    }
    //cout << "==============" << endl;
  }

  cout << "nums排序後:" << endl;
  for (int i = 0; i < 4; i++) {
    cout << nums[i] << " ";
  }
  cout << endl;
  
}
