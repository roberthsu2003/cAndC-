#include <iostream>
#include <time.h>
using namespace std;

void play_game() {
  srand(time(NULL));
  int min = 1;
  int max = 100;
  int count = 0;                              //計算已經猜幾次
  int keyin;                                  //使用者輸入的值
  int guess = rand() % (max - min + 1) + min; //要猜的值
  cout << guess << endl;
  printf("=========猜數字遊戲=============\n\n");
  while (true) {
    printf("猜數字的範圍%d~%d:", min, max);
    cin >> keyin;
    count += 1;
    if (keyin >= min && keyin <= max) {
      //輸入範圍正確的
      if (keyin == guess) {
        printf("賓果!猜對了,答案是%d\n", guess);
        printf("您猜了%d次\n\n", count);
        break;
      } else if (keyin > guess) {
        printf("再小一點\n");
        max = keyin - 1;
      } else if (keyin < guess) {
        printf("再大一點\n");
        min = keyin + 1;
      }
      printf("您已經猜了%d次\n\n", count);

    } else {
      //輸入的範圍不正確
      printf("請輸入提示範圍內的數字!\n");
    }
  }
}

int main() {
  //猜數字的遊戲
  while (true) {
    char answer;
    play_game();
    cout << "請問還要繼續嗎?(y,n):";
    cin >> answer;
    if (answer == 'n') {
      break;
    }
  }

  printf("猜數字應用程式結束");
}
