#include <iostream>
using namespace std;

int add(int a,int b){
  return a + b;
}

int main() { 
  int sum = add(567,925);
  cout << sum << endl;
}
