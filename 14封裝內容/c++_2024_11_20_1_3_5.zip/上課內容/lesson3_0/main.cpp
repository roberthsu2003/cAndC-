#include <iostream>

using namespace std;

int main() {
  int scores[] = {22, 7, 83, 77, 72, 1, 100, 70, 38, 61};

  cout << "排序前:" << endl;
  for (int i = 0; i < 10; i++) {
    cout << scores[i] << " ";
  }
  cout << endl;
//排序
  for (int i = 0; i < 10 - 1; i++) {
    for (int j = i + 1; j < 10; j++) {

      if (scores[i] > scores[j]) {
        int temp = scores[i];
        scores[i] = scores[j];
        scores[j] = temp;
      }
    }
  }

  cout << "排序後(由小到大):" << endl;
  for (int i = 0; i < 10; i++) {
    cout << scores[i] << " ";
  }
  cout << endl;

  for (int i = 0; i < 10 - 1; i++) {
    for (int j = i + 1; j < 10; j++) {

      if (scores[i] < scores[j]) {
        int temp = scores[i];
        scores[i] = scores[j];
        scores[j] = temp;
      }
    }
  }
  cout << "排序後(由大到小):" << endl;
  for (int i = 0; i < 10; i++) {
    cout << scores[i] << " ";
  }
  cout << endl;
}
