#include <iostream>
using namespace std;

double degree_to_radian(int degree) {
  double pi = 3.1415926;
  return pi / 180 * degree;
}

int main() {
  int degree;
  cout << "請輸入degree:";
  cin >> degree;
  double radian = degree_to_radian(degree);
  cout << "角度是:" << degree << ",";
  cout << "弳度是:" << radian << endl;
}
