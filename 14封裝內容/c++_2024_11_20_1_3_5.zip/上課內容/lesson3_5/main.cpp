#include <iostream>
using namespace std;
//&,取址運算子
int main() {
  double m = 5;
  int n = 10;
  double *m_ptr = &m;
  int *n_ptr = &n;
  cout << "使用變數取得值m=" << m << endl;
  cout << "使用變數取得值m=" << n << endl;
  //使用取值運算(*指標變數名稱)
  cout << "使用取值運算子取得值m=" << *m_ptr << endl;
  cout << "使用取值運算子取得值n=" << *n_ptr << endl;
}
