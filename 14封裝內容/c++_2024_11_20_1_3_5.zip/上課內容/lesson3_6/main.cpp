#include <iostream>
using namespace std;

void swap(int *x, int *y){
  int temp = *x;
  *x = *y;
  *y = temp;
}

int main() { 
  int a=666, b=888;
  swap(&a, &b);
  cout << "2數對調後:" << endl;
  cout << "a=" << a << endl;
  cout << "b=" << b << endl;
}
