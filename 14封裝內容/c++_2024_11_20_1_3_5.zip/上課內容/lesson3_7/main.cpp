#include <iostream>

using namespace std;

void multiply10(int *array, int num) {
  for (int i = 0; i < num; i++) {
    array[i] *= 10;
  }
}

int main() {
  int n[] = {10, 20, 30};
  multiply10(n, 3);
  for (int i = 0; i < 3; i++) {
    cout << n[i] << endl;
  }
}
