#include <iostream>
using namespace std;

//recursive(階層)
double factorial(int n){
  if(n == 1){
    return 1;
  }else{
    return n * factorial(n-1);
  }
}

int main() { 
  int n;
  double total;
  cout << "請輸入階層的數字:";
  cin >> n;
  total = factorial(n);
  cout << n << "!=" << total << endl;
  
}
