#include <iostream>
using namespace std;

typedef struct Rectangle{
  int width;
  int height;
}Rectangle;

int main() { 
  Rectangle rec1;
  rec1.width = 10;
  rec1.height = 20;
  cout << "rec1記憶體的大小是" << sizeof(rec1) << endl;
  cout << "成員width的值是:" << rec1.width << endl;
  cout << "成員height的值是:" << rec1.height << endl;
  cout << "面積是:" << rec1.width * rec1.height << endl;
}
