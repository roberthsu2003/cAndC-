#include <iostream>
using namespace std;

//結構放入至陣列內

typedef struct Rectangle {
  string name;
  int width;
  int height;
} Rectangle;

int main() {
  Rectangle rectangles[3];
  // cout << sizeof(rectangles);
  rectangles[0].name = "rec1";
  rectangles[0].width = 8;
  rectangles[0].height = 21;

  Rectangle rec = {"rec2", 9, 22};
  rectangles[1] = rec;

  rec = {"rec3", 10, 23};
  rectangles[2] = rec;

  for (int i = 0; i < 3; i++) {
    cout << rectangles[i].name << "記憶體的大小是" << sizeof(rectangles[i])
         << endl;
    cout << "成員name是:" << rectangles[i].name << endl;
    cout << "成員width的值是:" << rectangles[i].width << endl;
    cout << "成員height的值是:" << rectangles[i].height << endl;
    cout << "面積是:" << rectangles[i].width * rectangles[i].height << endl;
    cout << "=====================" << endl;
  }
}
