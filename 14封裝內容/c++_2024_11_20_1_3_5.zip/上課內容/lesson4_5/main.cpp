#include <iostream>
using namespace std;
//列舉的功能是限定變數的值

typedef enum direction {
  NORTH = 100,
  SOUTH = 200,
  EAST = 300,
  WEST = 400
} Direction;

int main() { 
  Direction dest = NORTH;
  Direction dest1 = EAST;

  cout << dest << endl;
  cout << dest1 << endl;
}
