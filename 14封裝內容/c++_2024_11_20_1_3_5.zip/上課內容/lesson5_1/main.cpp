#include <iostream>

using namespace std;
class Person {
public:
  int tall = 100; //欄位或是成員
  string name;
  void walk(int var){
    cout << name << "每小時可以跑:" << var << "公里" << endl; 
  }
};

int main() {
  Person david;
  david.name = "David";
  david.tall = 175;
  cout << david.name << endl;
  cout << david.tall << endl;
  david.walk(10);

  cout << "===============" << endl;

  Person robert;
  robert.name = "Robert";
  robert.tall = 183;
  cout << robert.name << endl;
  cout << robert.tall << endl;
  robert.walk(15);
}
