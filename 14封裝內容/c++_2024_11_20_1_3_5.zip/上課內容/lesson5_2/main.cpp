#include "student.h"
#include <iostream>

using namespace std;
int main() {
  Student stu1("David", 89, 90, 78);
  cout << "stu1的總分是:" << stu1.sum() << endl;
  printf("stu1的平均是:%.2lf\n", stu1.average());

  Student *stu2 = new Student("Robert", 75, 92, 84);
  cout << "stu2的name是:" << stu2->name << endl;
  cout << "stu2的總分:" << stu2->sum() << endl;
  cout << "stu2的平均:" << stu2->average() << endl;
}
