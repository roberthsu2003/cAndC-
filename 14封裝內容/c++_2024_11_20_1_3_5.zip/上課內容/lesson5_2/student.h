#include <iostream>
using namespace std;

class Student {
public:
  string name;
  int chinese;
  int english;
  int math;
  Student(string n, int c, int e, int m) { //建立建構式
    name = n;
    chinese = c;
    english = e;
    math = m;
  }
  int sum() { return chinese + english + math; }

  double average() { return sum() / 3.0; }
};
