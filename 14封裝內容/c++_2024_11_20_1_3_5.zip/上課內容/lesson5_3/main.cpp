#include <iostream>
#define __MAC__

#ifndef __MAC__

int main() { std::cout << "沒有__MAC__的macro\n"; }

#else

int main() { std::cout << "有__MAC__的macro\n"; }

#endif
