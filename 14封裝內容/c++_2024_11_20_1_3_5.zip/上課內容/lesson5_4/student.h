#ifndef __STUDENT_H__
#define __STUDENT_H__

#include <iostream>
using namespace std;

namespace Human {
class Student {
public:
  string name;
  int chinese;
  int english;
  int math;
  Student(string n, int c, int e, int m);
  int sum();
  double average();
};

Student::Student(string n, int c, int e, int m){
  name = n;
  chinese = c;
  english = e;
  math = m;
}

int Student::sum(){
  return chinese + english + math;
}

double Student::average(){
  return sum() / 3.0;
}




}// namespace Human

#endif
