#include <iostream>
#include <vector>

using namespace std;

int main() {
  // vector的操作方法
  vector<int> vec_a;
  vec_a.push_back(20);
  vec_a.push_back(45);
  vec_a.push_back(33);
  /*
  cout << "index:0=" << vec_a[0] << endl;
  cout << "index:1=" << vec_a[1] << endl;
  cout << "index:2=" << vec_a[2] << endl;
  */
  cout << "index:0=" << vec_a.at(0) << endl;
  cout << "index:1=" << vec_a.at(1) << endl;
  cout << "index:2=" << vec_a.at(2) << endl;
  cout << "元素數量:" << vec_a.size() << endl;
  cout << vec_a.at(0) << endl;

  cout << "================" << endl;
  for (int i = 0; i < vec_a.size(); i++) {
    cout << vec_a.at(i) << endl;
  }
  cout << "清空" << endl;
  vec_a.clear();
  cout << vec_a.size() << endl;
}
