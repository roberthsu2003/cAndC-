#include <iostream>
#include <vector>

using namespace std;

int main() {
  vector<int> list{2, 4, 6, 8};
  /*
  for(int i=0; i<list.size(); i++){
    cout << list.at(i) << endl;
  }
  */
  //一次讀出所有的元素
  for (int n : list) {
    cout << n << endl;
  }
  cout << "===========" << endl;
  vector<int> list1(10);
  //一次讀出所有的元素
  for (int n : list1) {
    cout << n << endl;
  }
  cout << "===========" << endl;
  vector<int> list2(10, 8);
  //一次讀出所有的元素
  for (int n : list2) {
    cout << n << endl;
  }
}
