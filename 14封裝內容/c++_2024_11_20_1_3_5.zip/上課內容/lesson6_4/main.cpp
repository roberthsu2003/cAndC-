#include <iostream>
#include <vector>

using namespace std;
void add_1(vector<int> *v) { // call by address
  for (int i = 0; i < v->size(); i++) {
    v->at(i) += 1;
  }
}

int main() {
  vector<int> list{2, 4, 6, 8};
  add_1(&list);
  for (int n : list) {
    cout << n << endl;
  }
}
