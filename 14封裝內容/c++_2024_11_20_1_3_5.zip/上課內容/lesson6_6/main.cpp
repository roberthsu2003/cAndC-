#include "student.h"
#include <iostream>
#include <time.h>
#include <vector>

using namespace std;

void add_student(vector<Student> &v, int nums) {
  for (int i = 1; i <= nums; i++) {
    int weight = rand() % (100 - 50 + 1) + 50;
    int height = rand() % (190 - 150 + 1) + 150;
    v.push_back(Student("stu" + to_string(i), height, weight));
  }
}

int main() {
  srand(time(NULL));
  vector<Student> students;
  int nums;
  cout << "請輸入學生數:";
  cin >> nums;
  add_student(students, nums);

  for (Student s : students) {
    cout << "姓名:" << s.name << endl;
    cout << "身高:" << s.height << endl;
    cout << "體重:" << s.weight << endl;
    printf("BMI:%.2f\n", s.bmi());
    cout << "狀態:" << s.status() << endl;
    cout << "===============" << endl;
  }
}
