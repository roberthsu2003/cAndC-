#ifndef __STUDENT_H__
#define __STUDENT_H__

#include <iostream>
#include <math.h>

using namespace std;
class Student {
public:
  string name;
  int height;
  int weight;
  Student(string name, int height, int weight);
  double bmi();
  string status();
};

Student::Student(string name, int height, int weight) {
  this->name = name;
  this->height = height;
  this->weight = weight;
}

double Student::bmi() {
  double BMI = (weight / pow(height / 100.0, 2));
  return BMI;
}

string Student::status() {
  double BMI = bmi();
  string status;
  if (BMI >= 35) {
    status = "重度肥胖";
  } else if (BMI >= 30) {
    status = "中度肥胖";
  } else if (BMI >= 27) {
    status = "輕度肥胖";
  } else if (BMI >= 24) {
    status = "過重";
  } else if (BMI >= 18.5) {
    status = "正常";
  } else {
    status = "過輕";
  }
  return status;
}

#endif
