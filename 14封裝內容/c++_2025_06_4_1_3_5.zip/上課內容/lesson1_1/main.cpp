#include <iostream>

int main() { 
  std::cout << "Hello World!\n";
  std::cout << "這是第1節的c++語言課程!\n";
  return 0;
}
