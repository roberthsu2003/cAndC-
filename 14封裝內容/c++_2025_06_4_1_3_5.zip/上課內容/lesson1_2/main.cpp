#include <iostream>
using namespace std;

int main() { 
  printf("這是c的輸出\n");
  std::cout << "這是c++的輸出" << std::endl;
  cout << "這是c++的輸出,省略std::" << endl;
}
