#include <iostream>
using namespace std;
//c++的輸入和輸出
int main() {
  string name;
  cout << "請輸入姓名:";
  cin >> name;
  cout << "您的姓名是" << name << endl;
}
