#include <iostream>
using namespace std;

//陣列1
int main() { 
  int scores[4];
  scores[0] = 78;
  scores[1] = 92;
  scores[2] = 65;
  scores[3] = 94;

  //輸出值
  cout << scores[0] << endl;
  cout << scores[1] << endl; 
  cout << scores[2] << endl;
  cout << scores[3] << endl;
  cout << "=============" << endl;
  for(int i=0; i<4; i++){
    cout << scores[i] << endl;
  }
}
