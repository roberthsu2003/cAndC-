#include <iostream>

using namespace std;

int main() {
  int win_number;    // 中獎的號碼
  int win_count = 0; // 計算中獎的人數
  srandom(time(NULL));
  int numbers[100];
  for (int i = 0; i < 100; i++) {
    numbers[i] = random() % 100 + 1;
    // cout << numbers[i] << endl;
  }

  cout << "請輸入中獎號碼(1~100):";
  cin >> win_number;
  //搜尋的動作
  for (int i = 0; i < 100; i++) {
    if (numbers[i] == win_number) {
      win_count += 1;
    }
  }

  cout << "中獎號碼:" << win_number << endl;
  cout << "中獎人數共有:" << win_count << "人" << endl;
}
