#include <iostream>
using namespace std;

int main() {
  int nums[] = {45, 78, 24, 69};
  cout << "排序前:";
  for (int i = 0; i < 4; i++) {
    cout << nums[i] << " ";
  }
  cout << endl;
  //泡沫排序由小到大的排序
  /*
  for (int i = 0; i < 4 - 1; i++) {
    for (int j = i + 1; j < 4; j++) {
      if (nums[i] > nums[j]) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
      }
    }
  }
  */
  //泡沫排序由大到小的排序
  for (int i = 0; i < 4 - 1; i++) {
    for (int j = i + 1; j < 4; j++) {
      if (nums[i] > nums[j]) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
      }
    }
  }
  cout << "排序後:";
  for (int i = 0; i < 4; i++) {
    cout << nums[i] << " ";
  }
}
