#include <iostream>
using namespace std;

int main() {
  srandom(456);
  int count;
  cout << "請輸入元素的數量:";
  cin >> count;
  int nums[count];
  for (int i = 0; i < count; i++) {
    nums[i] = random() % 100 + 1;
  }

  cout << "排序前:";
  for (int i = 0; i < count; i++) {
    cout << nums[i] << " ";
  }
  cout << endl;

  //泡沫排序由小到大的排序
  for (int i = 0; i < count - 1; i++) {
    for (int j = i + 1; j < count; j++) {
      if (nums[i] > nums[j]) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
      }
    }
  }

  cout << "由小到大的排序:";
  for (int i = 0; i < count; i++) {
    cout << nums[i] << " ";
  }
  cout << endl;

  //泡沫排序由大到小的排序
  for (int i = 0; i < count - 1; i++) {
    for (int j = i + 1; j < count; j++) {
      if (nums[i] < nums[j]) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
      }
    }
  }

  cout << "由大到小的排序:";
  for (int i = 0; i < count; i++) {
    cout << nums[i] << " ";
  }
  cout << endl;
}
