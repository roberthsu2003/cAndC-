#include <iostream>
using namespace std;

//自訂的function1
void function1(){
  cout << "第2行程式" << endl; 
  cout << "第3行程式" << endl; 
  cout << "第4行程式" << endl;
}

//自訂的function2
void function2(){
  cout << "第7行程式" << endl; 
  cout << "第8行程式" << endl; 
  cout << "第9行程式" << endl;
}

int main() { 
  cout << "第1行程式" << endl; 
  function1();  //呼叫function1
  cout << "第5行程式" << endl; 
  cout << "第6行程式" << endl; 
  function2(); //呼叫function2
  cout << "第10行程式" << endl; 
}
