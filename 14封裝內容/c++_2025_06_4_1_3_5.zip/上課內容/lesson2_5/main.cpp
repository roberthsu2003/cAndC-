#include <iostream>
using namespace std;

void sayHello(string n){
  cout << n << "您好:" << endl;
  cout << "最近好嗎?" << endl;
}

int main() {
  string name;
  cout << "請輸入姓名:";
  cin >> name;
  sayHello(name);
  cout << "應用程式結束" << endl;
}
