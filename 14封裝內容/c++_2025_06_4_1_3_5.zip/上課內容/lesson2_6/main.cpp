#include <iostream>
using namespace std;

//這function的功能是計算bmi
double bmi(int height, int weight){
  double my_bmi = weight / ((height / 100.0) * (height / 100.0));
  return my_bmi;
}

int main() {
  string name;
  int height,weight;
  double my_bmi;
  cout << "請輸入姓名:";
  cin >> name;
  cout << "請輸入身高(公分):";
  cin >> height;
  cout << "請輸入體重(公斤):";
  cin >> weight;
  my_bmi = bmi(height,weight);
  cout << name << "您好:" << endl;
  cout << "您的bmi是" << my_bmi << endl;
}
