#include <iostream>
using namespace std;

int main() {
  int scores[] = {10, 20, 30, 40};
  
  cout << "陣列變數儲存的記憶體位置:" << scores << endl;
  cout << "陣列索引0,所儲存的值:"<< scores[0] << endl; //取出值
  cout << "陣列索引0的記憶體位置:" << &scores[0] << endl;//取址運算子
  cout << "陣列索引1的記憶體位置:" << &scores[1] << endl;//取址運算子
  cout << "陣列索引0的記憶體位置:" << (scores+0) << endl;//+運算子
  cout << "陣列索引0的記憶體位置:" << (scores+1) << endl;//+運算子
  
}
