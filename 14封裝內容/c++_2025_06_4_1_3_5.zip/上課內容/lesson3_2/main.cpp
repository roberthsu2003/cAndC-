#include <iostream>
using namespace std;

int main() {
  int n = 666;
  int m = 888;
  
  cout << "2數交換前:" << endl;
  cout << "n=" << n << ",m=" << m << endl;
  
  //交換變數
  int temp = n;
  n = m;
  m = temp;

  cout << "2數交換後:" << endl;
  cout << "n=" << n << ",m=" << m << endl;
}
