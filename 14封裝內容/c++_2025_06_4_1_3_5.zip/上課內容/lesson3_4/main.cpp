#include <iostream>
using namespace std;

int main() { 
  int n = 666;
  cout << "&n:"<< &n << endl;
  int* n_ptr = &n;
  cout << "n_ptr:" << n_ptr << endl;
  *n_ptr = 888;
  cout << "*n_ptr:" << *n_ptr << endl;

}
