#include <iostream>
using namespace std;

void swap(int* x, int* y){
  //交換變數
  int temp = *x;
  *x = *y;
  *y = temp;
}


int main() {
  int n = 666;
  int m = 888;

  cout << "2數交換前:" << endl;
  cout << "n=" << n << ",m=" << m << endl;

  //呼叫function
  swap(&n,&m);

  cout << "2數交換後:" << endl;
  cout << "n=" << n << ",m=" << m << endl;
}
