#include <iostream>

using namespace std;

void multiply10(int *arr) {
  for(int i=0; i<5; i++){
    arr[i] *= 10;
  }
  
  
}

int main() { 
  int scores[5] = {10, 20, 30, 40, 50};
  multiply10(scores);
  for(int i=0; i<5; i++){
    cout << scores[i] << endl;
  }
}
