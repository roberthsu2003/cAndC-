#include <iostream>
#include "tools.h"
using namespace std;

int main() {
  srandom(456);
  int count;
  cout << "請輸入元素的數量:";
  cin >> count;
  int nums[count];
  add_random(nums, count);

  cout << "排序前:";
  print_value(nums, count);

  //泡沫排序由小到大的排序
  ascend_value(nums, count);

  cout << "由小到大的排序:";
  print_value(nums, count);

  //泡沫排序由大到小的排序
  descend_value(nums, count);

  cout << "由大到小的排序:";
  print_value(nums, count);
}
