#include <iostream>
using namespace std;

void add_random(int *arr, int count) {
  for (int i = 0; i < count; i++) {
    arr[i] = random() % 100 + 1;
  }
}

void print_value(int *arr, int count) {
  for (int i = 0; i < count; i++) {
    cout << arr[i] << " ";
  }
  cout << endl;
}

//由小到大排序
void ascend_value(int *arr, int count) {
  for (int i = 0; i < count - 1; i++) {
    for (int j = i + 1; j < count; j++) {
      if (arr[i] > arr[j]) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
      }
    }
  }
}

//由大到小排序
void descend_value(int *arr, int count) {
  for (int i = 0; i < count - 1; i++) {
    for (int j = i + 1; j < count; j++) {
      if (arr[i] < arr[j]) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
      }
    }
  }
}
