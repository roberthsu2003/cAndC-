#include <iostream>

using namespace std;

int fun1(int x){
  return x * x + 2 * x + 1;
}

int fun2(int x, int y){
  return x*x*x + 3*x*x*y + 3*x*y*y + y*y*y;
}

int main() { 
  for(int i=0; i<=10; i++){
    cout << "x=" << i << ",得到的值是:" << fun1(i) << endl;
  }
  cout << "===================" << endl;
  for(int i=1; i<=4; i++){
    for(int j=1; j<=4; j++){
      int result = fun2(i, j);
      cout << "x=" << i << ",y=" << j << ",得到的值是:" << result << endl;
    }
  }
}
