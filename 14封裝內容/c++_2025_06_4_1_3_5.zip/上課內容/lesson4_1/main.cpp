#include <iostream>
using namespace std;

typedef struct student {
  string name;
  int chinese;
  int math;
  int english;
} Student;

int main() { 
  Student stu1;
  //cout << sizeof(stu1) << endl;
  stu1.name="robert";
  stu1.chinese = 76;
  stu1.english = 92;
  stu1.math = 85;

  cout << stu1.name << endl;
  cout << stu1.chinese << endl;
  cout << stu1.english << endl;
  cout << stu1.math << endl;
  cout << "=========\n";
  Student stu2;
  stu2.name="jenny";
  stu2.chinese = 92;
  stu2.english = 79;
  stu2.math = 65;

  cout << stu2.name << endl;
  cout << stu2.chinese << endl;
  cout << stu2.english << endl;
  cout << stu2.math << endl;
}
