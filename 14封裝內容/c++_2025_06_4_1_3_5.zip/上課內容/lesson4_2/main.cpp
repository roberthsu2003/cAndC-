#include <iostream>
using namespace std;

typedef struct student {
  string name;
  int chinese;
  int math;
  int english;
} Student;

int main() {
  srandom(time(NULL));
  int count = 10;
  Student students[count];
  int max = 100;
  int min = 50;
  for (int i = 0; i < count; i++) {
    students[i].name = "stu" + to_string(i + 1);
    students[i].chinese = random() % (max - min + 1) + min;
    students[i].english = random() % (max - min + 1) + min;
    students[i].math = random() % (max - min + 1) + min;
  }
  for (int i = 0; i < count; i++) {
    cout << students[i].name << endl;
    cout << students[i].chinese << endl;
    cout << students[i].english << endl;
    cout << students[i].math << endl;
    cout << "=============" << endl;
  }
}
