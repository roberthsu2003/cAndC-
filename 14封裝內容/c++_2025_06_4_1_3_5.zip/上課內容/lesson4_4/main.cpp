#include <iostream>
using namespace std;
//全域常數
/*
const int NORTH = 1;
const int SOUTH = 2;
const int EAST = 3;
const int WEST = 4;
*/
typedef enum direction { 
  NORTH = 1,
  SOUTH,
  EAST,
  WEST 
}Direction;

int main() {
  Direction direc = SOUTH;
  cout << direc << endl;
}
