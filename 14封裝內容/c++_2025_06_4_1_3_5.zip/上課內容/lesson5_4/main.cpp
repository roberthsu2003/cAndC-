#include <iostream>
#define WINDOWS

#ifndef MAC

#define OS "Window12"

#else

#define OS "MAC_OS"

#endif

using namespace std;

int main() { cout << OS << endl; }
