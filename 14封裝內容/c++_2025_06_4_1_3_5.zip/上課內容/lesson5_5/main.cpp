#include "tools.h"
#include "tools1.h"
#include <iostream>

using namespace std;

int main() {
  srandom(time(NULL));
  int count = 50;
  Student students[count];
  created_student(students, count);

  //由大到小的排序
  sorted(students, count);
  // print_students(students, count);

  cout << "前3名是:" << endl;
  for (int i = 0; i < 3; i++) {
    cout << students[i].name << endl;
  }
  cout << "================\n";
  cout << "最後3名是:" << endl;
  for (int i = count - 3; i < count; i++) {
    cout << students[i].name << endl;
  }
}
