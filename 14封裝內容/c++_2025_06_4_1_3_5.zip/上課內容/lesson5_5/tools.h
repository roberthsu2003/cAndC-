
#ifndef _TOOLS_H_
#define _TOOLS_H_

#include <iostream>
using namespace std;

typedef struct student {
  string name;
  int chinese;
  int math;
  int english;
} Student;

void created_student(Student *stus, int count) {
  int max = 100;
  int min = 50;
  for (int i = 0; i < count; i++) {
    stus[i].name = "stu" + to_string(i + 1);
    stus[i].chinese = random() % (max - min + 1) + min;
    stus[i].english = random() % (max - min + 1) + min;
    stus[i].math = random() % (max - min + 1) + min;
  }
}

void print_students(Student *stus, int count) {
  for (int i = 0; i < count; i++) {
    cout << stus[i].name << endl;
    cout << stus[i].chinese << endl;
    cout << stus[i].english << endl;
    cout << stus[i].math << endl;
    cout << "總分=" << stus[i].chinese + stus[i].english + stus[i].math << endl;
    cout << "=============" << endl;
  }
}

void sorted(Student *stus, int count) {
  for (int i = 0; i < count - 1; i++) {
    for (int j = i + 1; j < count; j++) {
      int before_total = stus[i].chinese + stus[i].english + stus[i].math;
      int after_total = stus[j].chinese + stus[j].english + stus[j].math;
      if (before_total < after_total) {
        Student temp = stus[i];
        stus[i] = stus[j];
        stus[j] = temp;
      }
    }
  }
}

#endif
