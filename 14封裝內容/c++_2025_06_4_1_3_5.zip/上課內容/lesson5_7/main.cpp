#include <iostream>
#include <vector>

using namespace std;

int main() { 
  vector<int> list;
  cout << list.size() << endl;
  list.push_back(10);
  list.push_back(20);
  list.push_back(30);
  cout << list.size() << endl;

  for(int i=0; i<list.size(); i++){
    cout << list[i] << endl;
  }
  cout << "==========" << endl;
  for (int element : list){
    cout << element << endl;
  }
 }
