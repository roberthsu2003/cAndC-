#include <iostream>
#include <vector>

using namespace std;

void print_vector(vector<int>& l) { //call by reference
  for (int element : l) {
    cout << element << endl;
  }
  l.clear();
}

int main() {
  vector<int> list{10, 20, 30, 40, 50};
  print_vector(list);
  cout << "size:" << list.size() << endl;
}
