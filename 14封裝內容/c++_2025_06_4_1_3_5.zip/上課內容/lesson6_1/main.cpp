#include <iostream>
#include <vector>

using namespace std;

int main() {
  vector<int> vec_a;        //全空的元素
  vector<int> vec_b(10);    // 10個元素,每個元素儲存0
  vector<int> vec_c(10, 8); // 10個元素,每個元素儲存8
  vector<int> vec_d{10, 20, 30, 40, 50};
  int n = vec_d.size();

  //依據索引
  for (int i = 0; i < n; i++) {
    cout << vec_d[i] << endl;
  }
  cout << "=============" << endl;
  //依據元素的數量
  for (int element : vec_d) {
    cout << element << endl;
  }
}
