#include <iostream>
#include <vector>

using namespace std;

int main() {
  int count;
  float sum=0;
  
  cout << "請輸入元素數量:";
  cin >> count;
  vector<float> list(count);

  cout << "請輸入" << count << "元素:";
  //透過取得元素
  // call by reference
  for (float &element : list) {
    cin >> element;
  }

  // call by value
  for (float element : list) {
    sum += element;
  }
  cout << "加總後的值為:" << sum << endl;
}
