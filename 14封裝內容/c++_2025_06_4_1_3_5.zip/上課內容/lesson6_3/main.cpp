#include <iostream>
#include <vector>

using namespace std;

float sum(vector<float>& l){
  float total = 0;
  for(float element :l){
    total += element;
  }
  return total;
}

int main() {
  vector<float> list;
  float total;
  while (true) {
    float number;
    cout << "請輸入一個正數值(如果負數,就結束輸入):";    
    cin >> number;
    if (number < 0) {
      break;
    }
    list.push_back(number);
  }

  total = sum(list);
  cout << "所有數值的加總是:" << total << endl;
  
}
