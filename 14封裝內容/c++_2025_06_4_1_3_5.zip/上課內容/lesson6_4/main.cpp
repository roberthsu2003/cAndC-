#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

float sum(vector<float> &l) {
  float total = 0;
  for (float element : l) {
    total += element;
  }
  return total;
}

void save_vactor(vector<float> &l) {
  string filename;
  cout << "請輸入檔案名稱:";
  cin >> filename;
  cout << "存檔的檔案名稱是" << filename << endl;

  ofstream out;
  out.open(filename);
  if (out.good()) {
    for (float element : l) {
      out << element << " ";
    }
    out << endl;
    cout << "存檔完成" << endl;
  } else {
    cout << "存檔有問題發生" << endl;
  }
  out.close();
}

int main() {
  vector<float> list;
  float total;
  while (true) {
    float number;
    cout << "請輸入一個正數值(如果負數,就結束輸入):";
    cin >> number;
    if (number < 0) {
      break;
    }
    list.push_back(number);
  }
  save_vactor(list);
  total = sum(list);
  cout << "所有數值的加總是:" << total << endl;
}
