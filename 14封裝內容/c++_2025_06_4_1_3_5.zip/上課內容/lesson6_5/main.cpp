#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main() {
  vector<float> list;
  ifstream in;
  in.open("a1.txt");
  float value;
  if(in.good()){
    while(in >> value){
      list.push_back(value);
    }
    cout << "讀取成功" << endl;
  }else{
    cout << "讀取檔案有問題" << endl;
  }

  for(float element : list){
    cout << element << " ";
  }
  cout << endl;
}
