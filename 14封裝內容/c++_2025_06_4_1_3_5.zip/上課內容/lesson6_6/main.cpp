#include <iostream>
using namespace std;

class Student {
public:
  //欄位
  string name;
  int chinese;
  int english;
  int math;

  //自訂建構子
  Student(string n, int c, int e, int m){
    name = n;
    chinese = c;
    english = e;
    math = m;
  }

  //實體方法
  int sum() { return chinese + english + math; }

  float average() { return sum() / 3.0; }
};

int main() { 
  Student stu1("徐國堂",92,78,77);
  cout << "學生姓名:" << stu1.name << endl;
  cout << "國文:" << stu1.chinese << endl;
  cout << "英文:" << stu1.english << endl;
  cout << "數學:" << stu1.math << endl;
  cout << "總分:" << stu1.sum() << endl;
  cout << "平均:" << stu1.average() << endl;
  cout << "===============\n";

  Student stu2("張xx",78,65,92);
  cout << "學生姓名:" << stu2.name << endl;
  cout << "國文:" << stu2.chinese << endl;
  cout << "英文:" << stu2.english << endl;
  cout << "數學:" << stu2.math << endl;
  cout << "總分:" << stu2.sum() << endl;
  cout << "平均:" << stu2.average() << endl;
  
}
