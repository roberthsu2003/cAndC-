#include <iostream>
using namespace std;
int main() {
  printf("這是c語言的輸出\n");
  cout << "這是C++的輸出" << endl;
  cout << "這是c++的第一節課\n";
}
