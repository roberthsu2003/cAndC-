#include <iostream>
using namespace std;

int main() {
  string name;
  cout << "請輸入您的姓名:";
  cin >> name;
  cout << "您的姓名是" << name << endl;
}
