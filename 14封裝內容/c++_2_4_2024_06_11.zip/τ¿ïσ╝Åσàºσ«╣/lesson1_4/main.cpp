#include <iostream>
using namespace std;

int main() {
  int scores[] = {70, 80, 90};

  // cout << scores[0] << "," << scores[1] << "," << scores[2] << endl;
  // cout << scores[0] << ",";
  // cout << scores[1] << ",";
  // cout << scores[2] << endl;

  for (int i = 0; i < 3; i++) {
    cout << scores[i] << " ";
  }
}
