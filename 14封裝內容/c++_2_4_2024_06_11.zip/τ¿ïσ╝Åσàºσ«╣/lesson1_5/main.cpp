#include <iostream>
using namespace std;

int main() {
  srandom(time(NULL));
  int min = 10;
  int max = 15;
  int target = random() % (max - min + 1) + min;
  cout << target << endl;
}
