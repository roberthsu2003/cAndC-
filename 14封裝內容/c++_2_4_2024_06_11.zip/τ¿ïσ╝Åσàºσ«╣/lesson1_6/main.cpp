#include <iostream>
using namespace std;

int main() {
  srandom(time(NULL));
  int min = 60;
  int max = 100;
  int nums = 100;
  int scores[nums];
  int search_value;
  int count = 0;

  for (int i = 0; i < nums; i++) {
    scores[i] = random() % (max - min + 1) + min;
  }

  cout << "請搜尋" << min << "~" << max << "的數量:";
  cin >> search_value;

  for (int i = 0; i < nums; i++) {
    if (scores[i] == search_value) {
      count += 1;
    }
  }
  cout << search_value << "的數量有" << count << "個" << endl;
}
