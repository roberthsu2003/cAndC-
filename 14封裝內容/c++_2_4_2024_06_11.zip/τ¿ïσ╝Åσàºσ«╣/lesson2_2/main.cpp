#include <iostream>
using namespace std;

//自訂function
int add(int a, int b) { 
  return a + b; 
}

int main() {
  cout << add(101, 345) << endl;   //呼叫function
  cout << add(96, 78) << endl;     //呼叫function
  cout << add(1987, 6783) << endl; //呼叫function
}
