#include <iostream>
using namespace std;

void ascend(int a[], int n) {
  for (int i = 0; i < n - 1; i++) {

    for (int j = i + 1; j < n; j++) {

      if (a[i] > a[j]) {
        // 2數對調
        int temp;
        temp = a[i];
        a[i] = a[j];
        a[j] = temp;
      }
    }
  }
}

void descend(int a[], int n) {
  for (int i = 0; i < n - 1; i++) {

    for (int j = i + 1; j < n; j++) {

      if (a[i] < a[j]) {
        // 2數對調
        int temp;
        temp = a[i];
        a[i] = a[j];
        a[j] = temp;
      }
    }
  }
}

int main() {
  srandom(time(NULL));
  int min = 1;
  int max = 100;
  int nums;
  cout << "請輸入要排序的數值個數:";
  cin >> nums;
  int array[nums];
  cout << "排序前:\n";
  for (int i = 0; i < nums; i++) {
    array[i] = random() % (max - min + 1) + min;
    cout << array[i] << " ";
  }
  cout << endl;

  //開始泡沫排序(小到大)
  ascend(array, nums);
  cout << "排序(由小到大)後:\n";
  for (int i = 0; i < nums; i++) {
    cout << array[i] << " ";
  }
  cout << endl;

  //開始泡沫排序(大到小)
  descend(array, nums);
  cout << "排序(由大到小)後:\n";
  for (int i = 0; i < nums; i++) {
    cout << array[i] << " ";
  }
  cout << endl;
}
