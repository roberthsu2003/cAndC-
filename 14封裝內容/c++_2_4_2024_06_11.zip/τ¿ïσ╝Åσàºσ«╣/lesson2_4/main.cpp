#include <iostream>
using namespace std;
//遞迴recursive
double factorial(int n) {
  if (n == 1) {
    return 1;
  } else {
    return n * factorial(n - 1);
  }
}

int main() {
  int num;
  cout << "請輸入數字:";
  cin >> num;
  double total = factorial(num);
  cout << num << "!=" << total << endl;
}
