#include <iostream>
using namespace std;

int fun1(int x){
  return x * x + 2 * x + 1;
}

int main() {
  for(int x=0; x<=10; x++){
    cout << "x=" << x << ",value=" << fun1(x) << endl;
  }
}
