#include <iostream>
using namespace std;

void callByValue(int a){
  a = 20;
  cout << "在function內的a的值是" << a << endl;
}

int main() {
  int x = 10;
  cout << "呼叫function前,x的值是" << x << endl;
  callByValue(x);
  cout << "呼叫function後,x的值是" << x << endl;
  return 0;
}
