#include <iostream>
using namespace std;
int main() {
  int x = 10; //一般變數
  int *ptr_x; //指標變數
  ptr_x = &x; //&變數,取址運算子
  x = 20;
  cout << "目前x的值是" << x << endl;
  cout << "目前x的值是" << *ptr_x << endl;

  *ptr_x = 30;
  cout << "目前x的值是" << x << endl;
}
