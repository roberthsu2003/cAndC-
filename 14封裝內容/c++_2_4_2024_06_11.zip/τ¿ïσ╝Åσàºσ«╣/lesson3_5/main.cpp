#include <iostream>
using namespace std;

void swap(int *x, int *y) {
  // 2數對調
  cout << x << endl;
  cout << y << endl;  
  
  int temp = *x;
  *x = *y;
  *y = temp;
  
}

int main() {
  int a = 666, b = 777;
  swap(&a, &b);
  cout << "a=" << a << endl;
  cout << "b=" << b << endl;
}
