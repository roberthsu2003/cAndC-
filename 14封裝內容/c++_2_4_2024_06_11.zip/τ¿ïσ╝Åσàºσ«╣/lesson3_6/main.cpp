#include <iostream>
using namespace std;

void add_value_to_array(int a[],int n) {
  int max = 100;
  int min = 1;
  for(int i=0; i<n; i++){
    a[i] = random() % (max-min+1) + min;
  }
}

int main() {
  srandom(time(NULL));
  int num = 10;
  int n[num];

  add_value_to_array(n, num);

  for (int i = 0; i < num; i++) {
    cout << n[i] << endl;
  }
}
