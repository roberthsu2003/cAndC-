#include <iostream>
using namespace std;

void map_val_to_arr(int *p_arr, int elem, int val) {
  for (int i = 0; i < elem; i++) {
    *(p_arr + i) += val;
  }
}

void output_arr_to_console(int arr[], int elem) {
  cout << "array = { ";
  for (int i = 0; i < elem; i++) {
    cout << arr[i] << " ";
  }
  cout << "}" << endl;
}

int main() {
  int arr[] = {10, 20, 30, 40};
  int val_to_add;
  /*
  cout << sizeof(arr) << endl;
  cout << sizeof(arr[0]) << endl;
  cout << sizeof(arr) / sizeof(arr[0]) << endl;
  */
  int elements_of_arr = sizeof(arr) / sizeof(arr[0]);
  cout << elements_of_arr << endl;
  cout << "一開始: " << endl;
  output_arr_to_console(arr, elements_of_arr);
  /*
  cout << "arr[0]的記憶體位址" << arr+0 << endl;
  cout << "arr[0]的值:" << *(arr+0) << endl;
  */
  cout << "請輸入每個元素要增加的值: ";
  cin >> val_to_add;
  map_val_to_arr(arr, elements_of_arr, val_to_add);
  cout << "增加值後: " << endl;
  output_arr_to_console(arr, elements_of_arr);
}
