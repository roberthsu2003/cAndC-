#include <iostream>
using namespace std;
//宣告Rectangle結構，並建立結構變數Height,Width表示長和寬，輸入矩形的長和寬後計算面積

typedef struct rectangle {
  int width;
  double height;
} Rectangle;

int main() {
  Rectangle rec = {0,0.0};
  cout << "請輸入width(int):";
  cin >> rec.width;
  cout << "請輸入height(double):";
  cin >> rec.height;  
  cout << "寬:" << rec.width << endl;
  cout << "高:" << rec.height << endl;
  cout << "面積是:" << rec.width * rec.height << endl;
}
