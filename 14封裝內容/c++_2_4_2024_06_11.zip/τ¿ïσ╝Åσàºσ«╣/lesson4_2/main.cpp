#include <iostream>
using namespace std;

typedef struct point {
  double x;
  double y;
} Point;

typedef struct size {
  double width;
  double height;
} Size;

typedef struct rectangle {
  Point point;
  Size size;
} Rectangle;

int main() {
  Rectangle rec1;
  rec1.point = {0.0, 0.0};
  rec1.size.width = 10.0;
  rec1.size.height = 20.0;
  cout << "rec1的x點:" << rec1.point.x << endl;
  cout << "rec1的y點:" << rec1.point.y << endl;
  cout << "rec1的width:" << rec1.size.width << endl;
  cout << "rec1的height:" << rec1.size.height << endl;

  Rectangle rec2 = {{10.0, 10.0}, {23.5, 45.7}};
  cout << "rec2的x點:" << rec2.point.x << endl;
  cout << "rec2的y點:" << rec2.point.y << endl;
  cout << "rec2的width:" << rec2.size.width << endl;
  cout << "rec2的height:" << rec2.size.height << endl;
}
