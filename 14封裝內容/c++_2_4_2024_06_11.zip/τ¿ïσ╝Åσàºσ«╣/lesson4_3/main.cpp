#include <iostream>
using namespace std;

typedef struct student {
  string name;
  int chinese;
  int english;
  int math;
} Student;

void random_student(Student s[], int elems) {
  int min = 50;
  int max = 100;
  for (int i = 0; i < elems; i++) {
    s[i].name = "第" + to_string(i + 1) + "號學生";
    s[i].chinese = random() % (max - min + 1) + min;
    s[i].english = random() % (max - min + 1) + min;
    s[i].math = random() % (max - min + 1) + min;
    cout << s[i].name << " ";
    cout << s[i].chinese << " ";
    cout << s[i].english << " ";
    cout << s[i].math << " ";
    cout << s[i].chinese + s[i].english + s[i].math << endl;
  }
}

int main() {
  srandom(time(NULL));
  int nums;
  cout << "請輸入學生數量:";
  cin >> nums;
  Student students[nums];
  random_student(students, nums);
}
