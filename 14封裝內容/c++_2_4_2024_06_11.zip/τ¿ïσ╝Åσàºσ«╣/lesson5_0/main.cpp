#include <iostream>
#include "tools.h"

using namespace std;
int main() {
  srandom(time(NULL));
  int nums;
  cout << "請輸入學生數量:";
  cin >> nums;
  Student students[nums];
  random_student(students, nums);
  //======================
  //由大到小排序
  bobbles(students, nums);
  //列印所有元素
  print_students(students, nums);
  cout << "\n\n";
  //列印前5名
  top5(students);
  next5(students, nums);
}
