#include <iostream>
using namespace std;

typedef struct student {
	string name;
	int chinese;
	int english;
	int math;
} Student;

void random_student(Student s[], int elems) {
	int min = 50;
	int max = 100;
	for (int i = 0; i < elems; i++) {
		s[i].name = "第" + to_string(i + 1) + "號學生";
		s[i].chinese = random() % (max - min + 1) + min;
		s[i].english = random() % (max - min + 1) + min;
		s[i].math = random() % (max - min + 1) + min;
	}
}

void bobbles(Student *s, int elems) {
	for (int i = 0; i < elems - 1; i++) {
		for (int j = i + 1; j < elems; j++) {
			int first = s[i].chinese + s[i].english + s[i].math;
			int last = s[j].chinese + s[j].english + s[j].math;
			if (first < last) {
				Student temp = s[i];
				s[i] = s[j];
				s[j] = temp;
			}
		}
	}
}

void print_students(Student *s, int elems) {
	for (int i = 0; i < elems; i++) {
		cout << s[i].name << " ";
		cout << s[i].chinese << " ";
		cout << s[i].english << " ";
		cout << s[i].math << " ";
		cout << s[i].chinese + s[i].english + s[i].math << endl;
	}
}

void top5(Student *s) {
	cout << "前5名:" << endl;
	for (int i = 0; i < 5; i++) {
		cout << s[i].name << " ";
		cout << s[i].chinese << " ";
		cout << s[i].english << " ";
		cout << s[i].math << " ";
		cout << s[i].chinese + s[i].english + s[i].math << endl;
	}
}

void next5(Student *s, int elems) {
	cout << "後5名:" << endl;
	for (int i = elems-5; i < elems ; i++) {
		cout << s[i].name << " ";
		cout << s[i].chinese << " ";
		cout << s[i].english << " ";
		cout << s[i].math << " ";
		cout << s[i].chinese + s[i].english + s[i].math << endl;
	}
}
