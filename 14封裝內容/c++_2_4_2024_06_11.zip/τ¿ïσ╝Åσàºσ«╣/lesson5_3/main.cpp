#include <iostream>
using namespace std;

class Person {
public:
  //建立4個欄位
  string name;
  int chinese;
  int english;
  int math;

  Person(string n, int ch, int en, int ma) { //建構式
    name = n;
    chinese = ch;
    english = en;
    math = ma;
  }

  //建立實體方法(instance method)
  int total() { 
    return chinese + english + math; 
  }
};

int main() {
  string name;
  int chinese,english,math;
  cout << "請輸入姓名 國文 英文 數學:";
  cin >> name >> chinese >> english >> math;
  
  Person p1(name, chinese, english, math);
  cout << p1.name << endl;
  cout << "國文:" << p1.chinese << endl;
  cout << "英文:" << p1.english << endl;
  cout << "數學:" << p1.math << endl;
  cout << "總分:" << p1.total() << endl;
}
