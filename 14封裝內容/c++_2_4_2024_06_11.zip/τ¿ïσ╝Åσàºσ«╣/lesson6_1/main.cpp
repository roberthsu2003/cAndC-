#include <iostream>
using namespace std;

class PersonData {
private:
  float height;
  float weight;

public:
  string name;

  //建構式
  PersonData(string n, float h, float w) {
    name = n;
    height = h;
    weight = w;
  }

  float get_bmi() { return weight / ((height / 100) * (height / 100)); }

  string status() {
    float bmi = get_bmi();
    if (bmi < 18.5) {
      return "體重過輕";
    } else if (bmi < 24)
      return "正常範圍";
    else if (bmi < 27)
      return "過重";
    else if (bmi < 30)
      return "輕度肥胖";
    else if (bmi < 35)
      return "中度肥胖";
    else
      return "重度肥胖";
  }
};

int main() {
  string name;
  float height, weight;
  cout << "請輸入姓名：";
  cin >> name;
  cout << "請輸入身高(cm)：";
  cin >> height;
  cout << "請輸入體重(kg)：";
  cin >> weight;

  PersonData *pointP = new PersonData(name, height, weight);
  cout << pointP->name << "的BMI是：" << pointP->get_bmi() << endl;
  cout << pointP->name << "的體重：" << pointP->status() << endl;
}
