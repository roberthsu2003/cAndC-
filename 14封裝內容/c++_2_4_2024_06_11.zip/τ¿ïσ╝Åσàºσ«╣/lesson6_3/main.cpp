#include <iostream>
#include <vector>

using namespace std;

int main() {
  vector<int> vec_a;
  vec_a.push_back(10);
  vec_a.push_back(-3);
  vec_a.push_back(12);

  for(int i=0; i<vec_a.size(); i++){
    cout << vec_a[i] << endl;
  }
  cout << "==========" << endl;
  vec_a.pop_back();
  for(int i=0; i<vec_a.size(); i++){
    cout << vec_a[i] << endl;
  }

  cout << "==========" << endl;
  vec_a.pop_back();
  for(int i=0; i<vec_a.size(); i++){
    cout << vec_a[i] << endl;
  }
  
}
