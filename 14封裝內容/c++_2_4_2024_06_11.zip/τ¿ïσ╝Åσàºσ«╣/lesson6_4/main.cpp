#include <iostream>
#include <vector>
using namespace std;

void multi_10(vector<int> arr) { //call by value
  for (int i = 0; i < arr.size(); i++) {
    arr[i] *= 10;
  }
}

void multi_11(vector<int> &arr) { //call by reference
  for (int i = 0; i < arr.size(); i++) {
    arr[i] *= 10;
  }
}

int main() {
  vector<int> vec_c{10, 20, 30, 40, 50};

  for (int item : vec_c) {
    cout << item << endl;
  }

  cout << "==================" << endl;

  multi_11(vec_c);  

  for (int item : vec_c) {
    cout << item << endl;
  }
}
