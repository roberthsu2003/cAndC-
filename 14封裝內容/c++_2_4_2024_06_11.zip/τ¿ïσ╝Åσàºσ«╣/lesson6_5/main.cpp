#include <iostream>
using namespace std;

void swap(int x, int y){ //call by value
  int temp = x;
  x = y;
  y = temp;
}

void swap1(int &x, int &y){ //call by reference
  int temp = x;
  x = y;
  y = temp;
}

int main() {
  int n = 666;
  int m = 888;
  swap1(n, m);
  cout << "n=" << n << endl;
  cout << "m=" << m << endl;
}
