#include <iostream>
#include "tools.h"
using namespace std;

void all100(Student &s){
  s.chinese = 100;
  s.english = 100;
  s.math = 100;
}

int main() {
  Student s1("徐國堂",89,76,92);
  cout << "name:" << s1.name << endl;
  cout << "總分:" << s1.total() << endl;
  cout << "平均:" << s1.average() << endl;
  cout << "==================" << endl;
  
  all100(s1);
  
  cout << "name:" << s1.name << endl;
  cout << "總分:" << s1.total() << endl;
  cout << "平均:" << s1.average() << endl;
  cout << "==================" << endl;
}
