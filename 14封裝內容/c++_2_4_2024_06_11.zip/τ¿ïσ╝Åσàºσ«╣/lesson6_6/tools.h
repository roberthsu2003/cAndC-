#include <iostream>
using namespace std;

class Student{
	public:
	string name;
	int chinese;
	int english;
	int math;

	Student(string name, int chinese, int english, int math){
		this->name = name;
		this->chinese = chinese;
		this->english = english;
		this->math = math;
	}

	int total(){
		return chinese + english + math;
	}

	double average(){
		return total() / 3.0;
	}
};
