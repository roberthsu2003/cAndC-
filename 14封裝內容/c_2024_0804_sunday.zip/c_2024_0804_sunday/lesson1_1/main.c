#include <stdio.h>

int main(void) {
  printf("Hello World\n");
  printf("這是c語言第一節上課\n");
  printf("這是一個線上課程\n");
  return 0;
}
