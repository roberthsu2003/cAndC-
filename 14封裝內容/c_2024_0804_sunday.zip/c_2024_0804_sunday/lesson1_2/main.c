#include <stdio.h>

int main(void) {
  printf("國文分數:%d\n",10);
  printf("英文分數:%.2lf\n",10.0);
  printf("2個數值的相加:%i\n", 10 + 20);
  printf("1239*5的值是:%d\n", 1239 * 5);
  printf("%d*%d的值是:%d\n", 1239, 5, 1239 * 5);
  return 0;
}
