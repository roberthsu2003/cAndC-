#include <stdio.h>

int main(void) {
  printf("矩形寬:%d\n",9);
  printf("矩形高:%d\n",18);
  printf("矩形面積是:%d\n",9 * 18);
  return 0;
}
