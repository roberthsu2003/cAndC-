#include <stdio.h>

int main(void) {
  //建立width變數
  int width = 9;
  
  //建立height變數
  int height = 18;

  //建立area變數
  int area = width * height;

  printf("矩形寬是:%d\n",width);
  printf("矩形高是:%d\n",height);
  printf("矩形面積是:%d\n",area);
  
  return 0;
}
