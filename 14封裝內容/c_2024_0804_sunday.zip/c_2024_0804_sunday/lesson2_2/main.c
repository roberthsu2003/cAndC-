#include <stdio.h>

int main(void) {
  //建立width變數
  double width = 9.0;

  //建立height變數
  int height = 18;

  //建立area變數,自動將height轉換為double
  double area = width * height;

  printf("矩形寬是:%.0lf\n",width);
  printf("矩形高是:%d\n",height);
  printf("矩形面積是:%.0lf\n",area);

  return 0;
}
