#include <stdio.h>

int main(void) {
  //=,指定運算子,會將右邊的值轉換為和變數一樣的型別(int)
  int n = 15.6;
  printf("n的值是%d\n",n);

  int m = 18.9 * 5;
  printf("m的值是%d\n",m);

  double x = 18.9 * 5;
  printf("x的值是%.2f\n",x);
  return 0;
}
