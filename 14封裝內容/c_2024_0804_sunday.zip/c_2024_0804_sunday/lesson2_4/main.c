#include <stdio.h>

int main(void) {
  int value1 = 7;
  int value2 = 3;
  //強制轉換
  double value3 = value1 / (double)value2;
  printf("value3:%.2lf",value3);
  return 0;
}
