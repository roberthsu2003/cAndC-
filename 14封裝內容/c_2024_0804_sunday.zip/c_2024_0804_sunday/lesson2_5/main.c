#include <stdio.h>
//單行註解
/*================
多行註解
求梯型面積公式
(上底 + 下底) * 高 / 2
===================*/

int main(void) {
  int top = 2;
  int bottom = 3;
  int height = 3;
  //double area = (top + bottom) * height / 2.0; //使用自動轉換
  double area = (top + bottom) * (double)height / 2; //強制轉換
  printf("梯型面積是:%.2lf\n",area);
  return 0;
}
