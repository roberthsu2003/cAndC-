#include <stdio.h>
//使用取址運算子(&)取得變數的記憶體位址
int main(void) {
  int n;
  int m;

  printf("n的記憶體位址是:%p\n",&n);
  printf("m的記憶體位址是:%p\n",&m);
  return 0;
}
