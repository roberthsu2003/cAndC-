#include <stdio.h>

int main(void) {
  //建立變數
  int chinese,math;
  /*===================
  輸入資料
  ====================*/
  printf("請輸入中文成績:");
  scanf("%d",&chinese);
  printf("請輸入數學成績:");
  scanf("%d",&math);

  //輸出變數內容
  printf("\n國文成績:%d,數學成績:%d\n",chinese,math);
  return 0;
}
