#include <stdio.h>

int main(void) {
  printf("double數值:%.10lf\n",2.567123456);
  printf("float數值:%.10f\n",200.567123456789f);
  printf("double數值:%.10lf\n",2567123456e-9);
  return 0;
}
