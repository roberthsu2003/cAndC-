#include <stdio.h>
/*===================
同步登錄「國文、英文、數學」學測成績， 進行三科「總分、平均」計算報告。
提示．將「總分、平均」求取項目結果值後，輸出。
=====================*/

int main(void) {
  int chinese,english,math;
  int sum;
  float average;
  printf("請輸入國文,英文,數學分數(國文,英文,數學):");
  scanf("%d,%d,%d",&chinese,&english,&math);
  sum = chinese + english + math;
  average = sum / 3.0f;
  printf("---計算學測分數-------\n");
  printf("3科總分:%d\n",sum);
  printf("3科平均:%.2f\n",average);
  return 0;
}
