#include <stdio.h>

int main(void) {
  unsigned char myChar = 255;
  printf("myChar:%u\n",myChar);

  //超過數值,溢位
  unsigned char myChar1 = 5000;
  printf("myChar:%u\n",myChar1);

  unsigned short myShort = 60000;
  printf("myShort:%u\n",myShort);

  long long myLong = 2100000000000000000;
  printf("myLong:%lld\n",myLong);
  return 0;
}
