#include <stdio.h>

int main(void) {
  char myChar = 'A';
  printf("myChar的字元:%c\n", myChar);
  printf("myChar儲存的值是%d\n", myChar);

  char myChar1 = 'a';
  printf("myChar1的字元:%c\n", myChar1);
  printf("myChar1儲存的值是%d\n", myChar1);
  return 0;
}
