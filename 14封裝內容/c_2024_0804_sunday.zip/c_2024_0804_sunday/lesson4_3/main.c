#include <stdio.h>

int main(void) {
  char name[100];
  printf("請輸入您的姓名:");
  scanf("%s",name);
  printf("您的姓名是%s\n",name);
  return 0;
}
