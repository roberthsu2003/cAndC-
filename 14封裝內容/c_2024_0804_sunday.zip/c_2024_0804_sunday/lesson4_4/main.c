#include <stdio.h>
/*=========
使用fgets(),輸入有空白鍵的字串
=============*/

int main(void) {
  char name[100];
  printf("請輸入您的姓名:");
  fgets(name,100,stdin);
  printf("您的姓名是%s\n",name);
  return 0;
}
