#include <stdio.h>
//輸入半徑,計算出圓面積

int main(void) {
  float radius;
  //建立常數PI
  const float PI = 3.14;
  double area;
  printf("請輸入半徑:");
  scanf("%f", &radius);
  area = PI * radius * radius;
  printf("半徑:%.2f,面積是:%.4lf\n", radius, area);
  return 0;
}
