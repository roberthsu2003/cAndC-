#include <stdio.h>
#include <math.h>
//輸入半徑,計算出圓面積
/*=============
c語言的標準函式庫
==============*/

int main(void) {
  double radius;
  double area;
  printf("請輸入半徑:");
  scanf("%lf", &radius);
  area = M_PI * pow(radius, 2);
  printf("半徑:%.2f,面積是:%.4lf\n", radius, area);
  return 0;
}
