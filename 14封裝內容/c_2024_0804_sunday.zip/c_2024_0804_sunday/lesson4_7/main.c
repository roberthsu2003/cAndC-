#include <stdio.h>
#include <math.h>
/*===============
求直角3角形的角度
===================*/

int main(void) {
  double opposite_site, hypotenuse;
  double radian,degree;
  printf("請輸入直角三角形的對邊:");
  scanf("%lf", &opposite_site);
  printf("請輸入直角三角形的斜邊:");
  scanf("%lf", &hypotenuse);
  radian = asin(opposite_site / hypotenuse);
  degree = radian * 180 / M_PI;

  printf("直角三角形對邊:%.2lf\n",opposite_site);
  printf("直角三角形斜邊:%.2lf\n",hypotenuse);
  printf("直角三角形的角度是%.2lf\n",degree);  

  return 0;
}
