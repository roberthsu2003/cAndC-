#include <stdio.h>
//使用複合指定運算子
int main(void) {
  int n = 5;
  n += 5;
  printf("%d", n);
  return 0;
}
