#include <stdio.h>

int main(void) {
  int n = 5;
  printf("n原本的值%d\n", n);
  n++;
  printf("n++後的值%d\n", n);
  ++n;
  printf("++n後的值%d\n", n);
  n--;
  printf("n--後的值%d\n", n);
  --n;
  printf("--n後的值%d\n", n);
  return 0;
}
