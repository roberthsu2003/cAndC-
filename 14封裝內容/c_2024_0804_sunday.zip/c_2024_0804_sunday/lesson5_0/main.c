#include <math.h>
#include <stdio.h>

int main(void) {
  int a, b, c, d;
  printf("請輸入直角三角形對邊:");
  scanf("%d", &a);
  printf("請輸入直角三角形鄰邊:");
  scanf("%d", &b);
  c = sqrt(pow(a,2) + pow(b,2));
  printf("直角三角形的斜邊:%d\n", c);
  d = a + b + c;
  printf("直角三角形的周長:%d\n", d);

  return 0;
}
