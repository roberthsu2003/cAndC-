//學生符合加分條件就加5%分,如果超過300分,就以300為主。
#include <stdio.h>

int main(void) {
  int score;
  int add;
  printf("請輸入學生的分數:");
  scanf("%d", &score);
  if(score<=300){
    if(score>=0){
      printf("學生符合加分條件嗎? yes請輸入1,no請輸入0:");
      scanf("%d", &add);
      if (add) {
        printf("加分\n");
        score *= 1.05;
        if(score > 300){
          score = 300;
        }
      }
      printf("學生分數是:%d\n", score);
    }else{
      printf("不可以低於0分");
    }    
  }else{
    printf("最高分數只可以300分");
  }
  printf("應用程式結束");

  return 0;
}
