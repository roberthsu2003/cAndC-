/*===================
讓使用者輸入成績, 若成績在90分以上就顯示「優等」, 80-89分顯示「甲等」，70-79分顯示「乙等」，60-69分顯示「丙等」，60分以下顯示「丁等」。
====================*/
#include <stdio.h>

int main(void) {
  int score;
  printf("請輸入成績(0-100):");
  scanf("%d",&score);
  if(score >= 90){
    printf("優等\n");
  }else if(score >= 80){
    printf("甲等\n");
  }else if(score >= 70){
    printf("乙等\n");
  }else if(score >= 60){
    printf("丙等\n");
  }else{
    printf("丁等\n");
  }
  return 0;
}
