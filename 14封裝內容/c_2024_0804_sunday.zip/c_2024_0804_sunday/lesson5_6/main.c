/*==================
讓使用者輸入三個任意數，程式會顯示三數中的最大數。
==================*/
#include <stdio.h>

int main(void) {
  double in1, in2,in3,max;
  printf("請輸入第1個數:");
  scanf("%lf",&in1);

  printf("請輸入第2個數:");
  scanf("%lf",&in2);

  max = in1 > in2 ? in1 : in2;

  printf("請輸入第3個數:");
  scanf("%lf",&in3);

  max = max > in3 ? max : in3;

  printf("輸入三個數中最大的數為:%lf\n",max);
  return 0;
}
