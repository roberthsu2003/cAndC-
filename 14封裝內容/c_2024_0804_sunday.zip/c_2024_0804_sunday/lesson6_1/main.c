/*
1加至10的總合為?
*/
#include <stdio.h>

int main(void) {
  int total=0;
  for(int i=1;i<=100;i++){
    total += i;
  }
  printf("1加至100:%d\n",total);
  
  return 0;
}
