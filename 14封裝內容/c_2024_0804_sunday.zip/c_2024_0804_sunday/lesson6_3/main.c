#include <stdio.h>

int main(void) {
  int value;
  printf("請輸入一個數值,並求因數:");
  scanf("%d",&value);
  printf("以下為%d的因數:\n",value);
  for(int i=1;i<=value;i++){
    if(value % i == 0){
      printf("%d ",i);
    }
  }
  printf("\n");
  
  return 0;
}
