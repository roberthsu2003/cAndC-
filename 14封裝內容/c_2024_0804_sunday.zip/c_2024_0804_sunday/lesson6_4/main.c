//1加到10
#include <stdio.h>

int main(void) {
  int total=0;
  int i=1;
  while(i<=10){
    total += i;
    i++;
  }
  printf("1~10的加總為:%d\n",total);
  return 0;
}
