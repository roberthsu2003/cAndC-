//小明想要存錢買一輛機車,機車每輛30000元，他將每月存的錢輸入，當存款足夠買機車時，就顯示提示訊息告知。

#include <stdio.h>

int main(void) {
  int deposit = 0;
  int money;
  int month = 0;
  while(1){
    month += 1;
    printf("請輸入第%d月份的存款:",month);
    scanf("%d",&money);
    deposit += money;
    if(deposit >= 30000){
      break;
    }
  }
  printf("共存了%d個月,您共存了%d元\n",month,deposit);
  return 0;
}
