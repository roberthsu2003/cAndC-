//建立亂數
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  int min = 1;
  int max = 100;
  srand(time(NULL));
  int target = rand() % (max-min+1) + min;
  printf("%d\n",target);
  return 0;
}
