//建立猜數字
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  int min = 1;
  int max = 100;
  int count = 0;
  int keyin;
  srand(time(NULL));
  int target = rand() % (max-min+1) + min;
  printf("===========猜數字遊戲=============\n\n");
  while(1){
    printf("猜數字範圍%d~%d:",min,max);
    scanf("%d",&keyin);
    count += 1;
    if(keyin >= min && keyin <= max){
      if(keyin == target){
        printf("賓果!猜對了,答案是%d\n",target);
        printf("您猜了%d次\n",count);
        break;
      }else if (keyin > target){
        printf("再小一點!\n");
        max = keyin-1;        
      }else if (keyin < target){
        printf("再大一點!\n");
        min = keyin + 1;        
      }
      printf("您已經猜了%d次\n",count);
      
    }else{
      printf("請輸入提示範圍內的數字!\n");
    }
  }
  return 0;
}
